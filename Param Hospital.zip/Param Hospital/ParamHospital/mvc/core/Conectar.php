<?php
class Conectar{
    private $driver;
    private $host, $user, $pass, $database, $charset;
  
    public function __construct() {
        $db_cfg = require_once 'config/database.php';
        $this->driver=DB_DRIVER;
        $this->host=DB_HOST;
        $this->user=DB_USER;
        $this->pass=DB_PASS;
        $this->database=DB_DATABASE;
        $this->charset=DB_CHARSET;
    }
    
    public function Connection(){
    	
    			mysqli_report(MYSQLI_REPORT_STRICT);
			
					try{
									
				$connection = new mysqli($this->host,$this->user,$this->pass,$this->database);
							// echo "connection successfully";	
								
						}catch(Exception $ex){
							echo "connection Failed".$ex->getMessage();
							
						}
    	return $connection;
    	
    
    }

}
?>
