  </div>
    <script src="../assets/js/jquery-3.2.1.min.js"></script>
    <script src="../assets/js/popper.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/jquery.slimscroll.js"></script>
    <script src="../assets/js/select2.min.js"></script>
    <script src="../assets/js/moment.min.js"></script>
     <script src="../assets/js/dataTables.bootstrap4.min.js"></script>
    <script src="../assets/js/bootstrap-datetimepicker.min.js"></script>
    <script src="../assets/js/app.js"></script>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script type = "text/JavaScript" src = " https://MomentJS.com/downloads/moment.js"></script>
    
<!--     <script src="../assets/js/jquery-3.2.1.min.js"></script>-->
<!--    <script src="../assets/js/popper.min.js"></script>-->
<!--    <script src="../assets/js/bootstrap.min.js"></script>-->
<!--    <script src="../assets/js/jquery.slimscroll.js"></script>-->
<!--    <script src="../assets/js/jquery.slimscroll.js"></script>-->
<!--    <script src="../assets/js/select2.min.js"></script>-->
<!--    <script src="../assets/js/moment.min.js"></script>-->
<!--     <script src="../assets/js/dataTables.bootstrap4.min.js"></script>-->
<!--    <script src="../assets/js/bootstrap-datetimepicker.min.js"></script>-->
<!--    <script src="../assets/js/app.js"></script>-->
<!--<script>-->
<script>

     	   $(document).ready(function() {
		        var today = new Date();
		       //var id = document.getElementById("#pdelete").value
		       //console.log(id);
		        $('#dob').datepicker({
				            dateFormat: 'dd-mm-yy ',
				            autoclose:true,
				            changeMonth: true,
				            changeYear: true,
				            endDate: "today",
				            maxDate: today
				          }).on('changeDate', function (ev) {
				                $(this).datepicker('hide');
				      });
				            
		        $('#dob').keyup(function () {
		          if (this.value.match(/[^0-9]/g)) {
		            this.value = this.value.replace(/[^0-9^-]/g, '');
		            }
		          });  
		          $(document).on("click","button.deleterec",function(){
		          	console.log("del");
		          })
		         
		       //     $(document).on("click","a.deletedata",function(){
			 	 	  // 	$('#delete_patient').modal('show');
			 	 	  // delete_id = $(this).data('dataid');
			 	 	  // 	// console.log(deleteid);
			 	 	  // })
		          
		          
		            $('#deleterec').click(function(){
		            	alert("del");
		            console.log($(this).data("id"));
		            		var selectdate = document.getElementById("deleterec").value; 
		            		console.log('val'.selectdate)
			 	 	  	// $.ajax({
			 	 	  	// 	 type :'POST',
			 	 	  	// 	 url :'delete_pending_cases/',
			 	 	  	// 	 cache : false,
			 	 	  	// 	 dataType : "json",
			 	 	  	// 	 data :{deleteid:delete_id},
			 	 	  	// }).done(function (dataResult){
			 	 	  	// 	 (dataResult == true) ?
			 	 	  	// 	  showAlert('Success! ','Data delete successfully','success') :
			 	 	  	// 	  showAlert('Somthing went! ','please try again later','danger')
			 	 	  	// 	 console.log(dataResult);
			 	 	  	// }).fail(function (dataResult){
			 	 	  	// 	 console.log(dataResult);
			 	 	  	// 	  showAlert('Somthing went!','please try again later','danger')
			 	 	  	// }).always(function (){
			 	 	  	// 	Loadtable();
			 	 	  	// 		$("#delete_patient").modal('hide');
			 	 	  	// });
			 	 	  	
			 	 	  })
		          
		         
     	   });
         function mydatepicker(){
            	var selectdate = document.getElementById("dob").value;  
            	//setAge function assets/js/app.js
		          var age = setAge(selectdate);
							  $('#age').val(age);
              }
              
               function deletefun(){
		          	
		          }
</script>

</body>


<!-- login23:12-->
</html>

