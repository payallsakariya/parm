<?php session_start();?>
<html>
<!-- login23:11-->
<?php include 'views/css.php'; ?>  
    <div class="main-wrapper account-wrapper">
        <div class="account-page">
			<div class="account-center">
				<div class="account-box">
                  <form method="post" class="form-signin">
						<div class="account-logo">
                            <a href=""><img src="../assets/img/logo-dark.png" alt=""></a>
                        </div>
                        <div class="form-group">
                            <label for="email">Username or Email</label>
                            <input type="text" autofocus="" class="form-control" name="email" id="email">
                        </div>
                        <div class="form-group">
                            <label for="pass">Password</label>
                            <input type="password" class="form-control" name="pass",name="pass">
                        </div>
                        <span class="error" style="color:red"> <?php print_r($_SESSION['login_err']); ?></span>
                        <div class="form-group text-right">
                            <a href="../login/forgot_password">Forgot your password?</a>
                        </div>
                        <div class="form-group text-center">
                        	<input type="submit" name="login" id="login"  value="login" class="btn btn-primary account-btn">
                            <!--<a href="index.html"><button type="submit" class="btn btn-primary account-btn">Login</button></a>-->
                        </div>
                        <!--<div class="text-center register-link">-->
                        <!--    Don’t have an account? <a href="register.html">Register Now</a>-->
                        <!--</div>-->
                    </form>
                </div>
			</div>
        </div>
    </div>

   <?php include 'views/footer.php'; ?>  
</body>


<!-- login23:12-->
</html>