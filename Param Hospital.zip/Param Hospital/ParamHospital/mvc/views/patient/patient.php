<?php 
       $add_use = $_SESSION['add_user'];
       include 'views/header.php';
?>
 <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Add Patient</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">

                        <form  method="post">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="pmhid">PMH Card ID</label>
                                        <input class="form-control" type="text" id="pmhid" name="pmhid" value="<?php echo $add_use['pmhid']; ?>">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="phone">Phone </label><span class="text-danger pl-2">*</span>
                                        <input class="form-control" type="text" id="phone" name="phone" value="<?php echo $add_use['phone']; ?>">
                                         <span class="text-danger"><?php echo $Errphone; ?></span>
                                    </div>
                                </div>

                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="fname">First Name </label><span class="text-danger pl-2">*</span>
                                        <input class="form-control" type="text" id="fname" name="fname" value="<?php echo $add_use['fname']; ?>">
                                         <span class="text-danger"><?php echo $Errfname; ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="mname">Middle Name</label><span class="text-danger pl-2">*</span>
                                        <input class="form-control" type="text" id="mname" name="mname" value="<?php echo $add_use['mname']; ?>">
                                         <span class="text-danger"><?php echo $Errmname; ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="lname">Last Name </label><span class="text-danger pl-2">*</span>
                                        <input class="form-control" type="text" id="lname" name="lname" value="<?php echo $add_use['lname']; ?>">
                                         <span class="text-danger"><?php echo $Errlname; ?></span>
                                    </div>
                                </div>
                                
                                 <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="dob">Date of Birth</label><span class="text-danger pl-2">*</span>
                                        <div class="cal-icon">
                                       <input type="text" class="form-control " value="<?php echo $add_use['dob']; ?>" 
                                       id="dob" name="dob" onchange="mydatepicker()" >																			
                                        </div>
                                         <span class="text-danger"><?php echo $Errbirthdate; ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="age">Age</label>
                                        <input class="form-control" type="number" id="age" name="age" readonly=""
                                          value="<?php echo $add_use['age']; ?>">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="bloodgroup">Blood Group</label><span class="text-danger pl-2">*</span>
                                        <select class="form-control" id="bloodgroup" name="bloodgroup">
                                            <option value="">Plase Select</option>
                                            <option value="A+"  <?php if($add_use['bloodgroup'] == 'A+'){echo 'Selected'; } ?> >A+</option>
                                            <option value="A-" <?php if($add_use['bloodgroup'] == 'A-'){echo 'Selected'; } ?>>A-</option>
                                            <option value="B+" <?php if($add_use['bloodgroup'] == 'B+'){echo 'Selected'; } ?>>B+</option>
                                            <option value="B_" <?php if($add_use['bloodgroup'] == 'B-'){echo 'Selected'; } ?>>B-</option>
                                            <option value="AB+" <?php if($add_use['bloodgroup'] == 'AB+'){echo 'Selected'; } ?>>AB+</option>
                                            <option value="AB-" <?php if($add_use['bloodgroup'] == 'AB-'){echo 'Selected'; } ?>>AB-</option>
                                            <option value="O+" <?php if($add_use['bloodgroup'] == 'O+'){echo 'Selected'; } ?>>O+</option>
                                            <option value="O-" <?php if($add_use['bloodgroup'] == 'O-'){echo 'Selected'; } ?>>O-</option>
                                        </select>
                                         <span class="text-danger"><?php echo $Errbloodgroup; ?></span>
                                    </div>
                                </div>
                               
                                <div class="col-sm-4">
                                    <div class="form-group gender-select">
                                        <label class="gen-label" for="gender">Gender: <span class="text-danger pl-2">*</span></label>
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                          <input type="radio" name="gender" id="gender" class="form-check-input" value="male" 
                                          <?php if($add_use['gender'] == 'male'){echo 'checked';}  ?> >Male
                                            </label>
                                        </div>
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                                <input type="radio" name="gender" id="gender" class="form-check-input"  value="female"
                                                <?php if($add_use['gender'] == 'female'){echo 'checked';}  ?>>Female
                                            </label>
                                             <span class="text-danger"><?php echo $Errgender; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="religion">Religion</label><span class="text-danger pl-2">*</span>
                                        <input class="form-control" type="text" id="religion" name="religion" value="<?php echo $add_use['religion']; ?>">
                                        <span class="text-danger"><?php echo $Errreligion; ?></span>
                                    </div>
                                </div>


                                
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="postalcode">Postal Code</label><span class="text-danger pl-2">*</span>
                                     <input type="text" class="form-control" id="postalcode" name="postalcode" value="<?php echo $add_use['postalcode']; ?>">
                                        <span class="text-danger"><?php echo $Errpostalcode; ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="address">Address</label><span class="text-danger pl-2">*</span>
                                        <textarea class="form-control" id="address" name="address" value=""
                                        rows="3"><?php echo $add_use['address']; ?></textarea>
                                        <span class="text-danger"><?php echo $Erraddress; ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label for="mhistory">Medical History</label><span class="text-danger pl-2">*</span>
                                                <textarea class="form-control" id="mhistory" name="mhistory"  value=""
                                    rows="3"><?php echo $add_use['mhistory']; ?></textarea>
                                    <span class="text-danger"><?php echo $Errmhistory; ?></span>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>



              

                <div class="m-t-20 text-center">
                    <!--<button class="btn btn-primary submit-btn mx-auto" id="" name="">Create Patient</button>-->
                     <input type="submit" name="Submit" id="Submit"  value="Create Patient" class="btn btn-primary submit-btn mx-auto">
                </div>

                </form>
                      </div>
                </div>
            </div>
        </div>
<?php include 'views/footer.php'; ?>