<?php
$getURL =$_SERVER['PATH_INFO'];
// print_r($_SERVER['PATH_INFO']);


$arrpath =(explode("/",$getURL));
$objname = $arrpath[1];
$funname = $arrpath[2];
// echo $funname."...";
// echo 'controller/'.$objname.'.php';
// exit;
$cfg = require_once 'config/config.php';
require_once 'controller/'.$objname.'.php';


$obj = new $objname();

return $obj->$funname();


// ALTER TABLE `user` ADD `role` TINYINT NOT NULL DEFAULT '0' COMMENT '0: User, 1: Admin' AFTER `id`;

?>
