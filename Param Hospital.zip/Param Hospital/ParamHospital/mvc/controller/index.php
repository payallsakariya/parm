<?php
class index {
	 private $conectar;
   private $Connection;

	function __construct() {
		   
    require_once  __DIR__ . "/../core/Conectar.php";
    require_once  __DIR__ . "/../model/index_model.php";
    
    $this->conectar=new Conectar();
    $this->model=new index_model();
    $this->Connection=$this->conectar->Connection();
	}
	
	function index() {
			include 'views/index/index.php';
		
	}
}
	?>
