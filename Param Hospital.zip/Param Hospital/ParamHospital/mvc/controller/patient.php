<?php
date_default_timezone_set('Asa/Kolkata');
session_start();
class patient {

     public $table = "patients";
		 private $conectar;
     private $Connection;
     private $base_url;
		
							    function __construct() {
							        require_once  __DIR__ . "/../core/Conectar.php";
                      require_once  __DIR__ . "/../model/patient_model.php";
                      $this->conectar=new Conectar();
									    $this->model=new patient_model();
									    $this->base_url = base_url;
									    $this->Connection=$this->conectar->Connection();
						       }

	 function patient(){
	 	       if(isset($_SERVER['PATH_INFO'])){
						 $Errphone = $Errfname =$Errmname =$Errlname =$Errreligion =$Errpostalcode = 
						 $Erraddress = $Errmhistory =$Errgender =$Errbloodgroup =$Errbirthdate ="";
						 
						$phone = $fname = $mname =  $lname =$religion = $postalcode = $address= $mhistory= $gender = $bloodgroup = $birthdate ="";	
						   try{
						   		if($_SERVER['REQUEST_METHOD'] == 'POST') {
						   		
						   			$from =$_POST['birthdate'];
						   			$to   = new DateTime('today');
						   				if(empty($_POST['pmhid'])) {
			   			             $_SESSION['pmhid'] = "";
						   			     } else {
													 $_SESSION['add_user']['pmhid'] = $phone =$this->model->htmlValidation($_POST["pmhid"]);
											}
											if(empty($_POST['age'])) {
				   			             $_SESSION['age'] = "";
							   			   } else {
														 $_SESSION['add_user']['age'] = $phone =$this->model->htmlValidation($_POST["age"]);
											}
						   			if(empty($_POST['phone']) || !preg_match("/[0-9]{10}$/", $_POST['phone']) ) {
			   			             $Errphone= "Phone Number Is Required and Only Number are Allowed";
			   			             $_SESSION['phone'] = "";
						   			  } else {
													 $_SESSION['add_user']['phone'] = $phone =$this->model->htmlValidation($_POST["phone"]);
												}
						   	   	if(empty($_POST['fname']) || !preg_match("/[a-z A-Z]$/", $_POST["fname"]) ) {
						   			            $Errfname = "First Name Is Required and Only Text are Allowed";
						   			            $_SESSION['fname'] = "";
						   			  }else {
													 $_SESSION['add_user']['fname'] = $fname = $this->model->htmlValidation($_POST["fname"]);
												}
						   			if(empty($_POST['mname']) || !preg_match("/[a-z A-Z]$/", $_POST["mname"]) ) {
						   			            $Errmname = "Middle Name Is Required and Only Text are Allowed";
						   			            $_SESSION['mname'] = "";
						   			  }else {
													 $_SESSION['add_user']['mname'] = $fname = $this->model->htmlValidation($_POST["mname"]);
												}
						   			  
						   			 if (empty($_POST["lname"]) || !preg_match("/[a-z A-Z]$/", $_POST["lname"]) ) {
						   			            $Errlname = "Last Name Is Required and Only Text are Allowed.";
						   			            $_SESSION['lname'] = "";  
						   			   }else {
													 $_SESSION['add_user']['lname'] = $lname = $this->model->htmlValidation($_POST["lname"]);
												}
					   			   
					  			    if (empty($_POST["religion"]))  {
					  			          $Errreligion= "Religion Is Required. ";
			   			          	  $_SESSION['religion'] = "";
					  			  }else {
													 $_SESSION['add_user']['religion'] = $religion = $this->model->htmlValidation($_POST["religion"]);
												}
					  			  if (empty($_POST["postalcode"]) || !preg_match("/[0-9]{6}$/", $_POST["postalcode"]) ) {
					  			            $Errpostalcode = "Postal Code Is Required and Only Number are Allowed.";
					  			            $_SESSION['postalcode'] = "";
						   			  }else {
													 $_SESSION['add_user']['postalcode'] = $postalcode = $this->model->htmlValidation($_POST["postalcode"]);
												}
						   			  if (empty($_POST["address"])) {
				   			            $Erraddress = "Address Is Required.";
				   			            $_SESSION['address'] = "";  
						   			  }else {
													 $_SESSION['add_user']['address'] = $address = $this->model->htmlValidation($_POST["address"]);
												}
						   			  if (empty($_POST["mhistory"])) {
					  			            $Errmhistory = "Medical History Is Required. ";
					  			            $_SESSION['mhistory'] = "";           
					   			 
						   			  }else {
													 $_SESSION['add_user']['mhistory'] = $mhistory = $this->model->htmlValidation($_POST["mhistory"]);
												}
						   			  
						   			  if (empty($_POST["gender"])) {
						   			          $Errgender = "Gender Is Required.";
						   			            $_SESSION['gender'] = "";
						   			  }else {
													 $_SESSION['add_user']['gender'] = $gender = $this->model->htmlValidation($_POST["gender"]);
												}
						   			  if (empty($_POST["bloodgroup"]))  {
						   			          $Errbloodgroup = "Bloodgroup Is Required. ";
						   			            $_SESSION['bloodgroup'] = "";
						   			  }else {
													 $_SESSION['add_user']['bloodgroup'] = $bloodgroup =$this->model->htmlValidation($_POST["bloodgroup"]);
												}
						   			  if (empty($_POST["dob"])) {
						   			            $Errbirthdate = "Birthdate Is Required.";
						   			            $_SESSION['dob'] = "";  
						   			  }else {
													 $_SESSION['add_user']['dob'] = $birthdate = $this->model->htmlValidation($_POST["dob"]);
												}
						   	   }
						   	  
								   }catch (\Exception $ex){
								   	throw $ex;
								   }
					}
					
											
			if($Errphone == "" && $Errfname == "" && $Errmname == "" && $Errlname == "" && $Errreligion == "" && $Errpostalcode == "" &&                    $Erraddress == ""  && $Errmhistory == "" && $Errgender == "" && $Errbloodgroup == "" && $Errbirthdate ==""){
				
	  	  if(isset($_POST['Submit'])){
	  	  	  //pmshid makeing code
	  	       $this->mselEx= $this->model->selectmaxid();
	  	       
	              if($this->mselEx['Code'] == 1){
	                $lastid =	$row = $this->mselEx['Data'];
                  $lastid=$lastid+1;
									$lastid = str_pad($lastid,5, '0', STR_PAD_LEFT);
									$currentyear=  date("y");
									$pmshid='PMSH'.$currentyear.$lastid;
	              }else{
	                $lastid=1;
									$lastid = str_pad($lastid,5, '0', STR_PAD_LEFT);
									$currentyear=  date("y");
									$pmshid='PMSH'.$currentyear.$lastid;
	              }
	  	  	
						//date format change DD/MM/YYYY To YYYY/MM/DD
						$orgDate = $_POST['dob'];
						$date = str_replace('-"', '/', $orgDate);
						$newDate = date("Y/m/d", strtotime($date));

          //creat array for insert data in database
	  			$insert_data = [
	                'pmshid' => $pmshid,
	                'pmhid' => $_POST['pmhid'],
	                'contact' => $_POST['phone'],
	                'pfname' => $_POST['fname'],
	                'pmname' => $_POST['mname'],
	                'plname' => $_POST['lname'],
	                'age' => $_POST['age'],
	                'bloodgroup' => $_POST['bloodgroup'],
	                'pbirth_date ' => $newDate,
	                'gender	' => $_POST['gender'],
	                'religion	' => $_POST['religion'],
	                'postal_code' => $_POST['postalcode'],
	                'address	' => $_POST['address'],
	                'medical_history	' => $_POST['mhistory']
	              ];
	              
	  	 $this->insertEx= $this->model->InsertData($this->table,$insert_data);
	  	 
		     if($this->insertEx['Code'] == 1){
		     	  $url = $this->base_url.'index/index';
		     	  unset($_SESSION['add_user']);
		 		  	header("Location: $url");
		     }else{
		     	  $url = $this->base_url.'patient/patient';
		 			header("Location: $url");
		     }
	  	}
	  }					
include 'views/patient/patient.php';		
 }
   
   function pending_cases(){
   	// echo "pending_cases";
   		 $this->pcasesEx= $this->model->get_pending_cases();
   		 if($this->pcasesEx['Code'] == 1){
	               	$_SESSION['panddinuserData'] = $this->pcasesEx['Data'];
	               	// echo "<pre>";
	               	// print_r($_SESSION['panddinuserData']);exit;
	               	
   		 }else{
   		 	
   		 }
   	include 'views/patient/pending_cases.php';
   	
   }
   function edit_pending_cases(){
   	
   	echo "edit_pending_cases";
   	exit;
   }
 
   function delete_pending_cases(){
   	
   	echo "delete_pending_cases";
   	exit;
   	 try{
						   //echo "<pre>";
						   	$delete_data = $this->model->DeleteData($this->table,['id'=>$this->model->htmlValidation($_GET['id'])]);
						   	// print_r($Alldata);
						   	echo json_encode($delete_data);
						   }catch (\Exception $ex){
						   	throw $ex;
						   }
   	exit;
   }
}

?>
