<?php

class login_model
{
	public $table = "users";
	private $Connection;


	function __construct() {
		$this->conectar = new Conectar();
		$this->Connection = $this->conectar->Connection();
	}
	function LogingData($email, $password) {
// echo $email;
// 			    echo $pass;
// echo"modle";exit;
		$response = array();
		// select * from user where email = '' and password = '';
	  $loginsql = "SELECT * FROM ".$this->table." WHERE email = '".$email."'";

		$loginEx = $this->Connection->query($loginsql);
	
		$loginData = $loginEx->fetch_object();

		if ($loginEx->num_rows > 0 && $password == $loginData->password) {
			$response['Data'] = $loginData;
			$response['Code'] = true;
			$response['Message'] = 'Login successfully.';

		} else {
			$response['Data'] = null;
			$response['Code'] = false;
			$response['Message'] = 'Email ro password  is incorrect.';

		}
		// echo "<pre>";
		// print_r($response);
		// exit;
		return $response;
	}


}
?>