<?php

class index_model
{
	public $table = "users";
	private $Connection;
	private $id;
	private $Name;
	private $Surname;
	private $email;
	private $phone;

	function __construct() {
		$this->conectar = new Conectar();
		$this->Connection = $this->conectar->Connection();
	}
}
?>