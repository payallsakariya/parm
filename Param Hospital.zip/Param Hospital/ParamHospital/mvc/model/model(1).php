<?php

class model{
	
			
			public $servername = 'localhost';
      public $username = 'chinmay';
      public $password = "Ecs@2021";
      public  $dbname = "medprack";
 
			 	           
			function __construct(){
						 	
			mysqli_report(MYSQLI_REPORT_STRICT);
			
					try{
									
			      	$this->$connection = new mysqli($this->servername,$this->username,$this->password,$this->dbname);
							// echo "connection successfully";	
								
				 }catch(Exception $ex){
							echo "connection Failed".$ex->getMessage();
							
						}
				}		
	 }
	
	function mmm(){
		 
						   			  // if(empty($_POST['fname']) ) {
						   			  // 	echo 'in';
						   			  //           $_SESSION['padderrmgs']['fname'] = "First Name Is Required and Only Text are Allowed";
						   			  //           $_SESSION['fname'] = "";
						   			  // }elseif (empty($_POST["mname"]) || !preg_match("/[a-z A-Z]$/", $_POST["mname"]) ) {
						   			  // 	echo 'in';
						   			  //           $_SESSION['padderrmgs']['mname'] = "Middle Name Is Required and Only Text are Allowed";
						   			  //           $_SESSION['mname'] = "";
						   			  // }elseif (empty($_POST["lname"]) || !preg_match("/[a-z A-Z]$/", $_POST["lname"]) ) {
						   			  //           $_SESSION['padderrmgs']['lname'] = "Last Name Is Required and Only Text are Allowed";
						   			  //           $_SESSION['lname'] = "";  
						   			   //}//elseif (empty($_POST["birthdate"])) {
						   			  //           $_SESSION['padderrmgs']['birthdate'] = "Birthdate Is Required.";
						   			  //           $_SESSION['birthdate'] = "";  
						   			  // }elseif (empty($_POST["bloodgroup"]))  {
						   			  //         $_SESSION['padderrmgs']['bloodgroup']= "Bloodgroup Is Required. ";
						   			  //           $_SESSION['bloodgroup'] = "";
						   			  // }elseif (empty($_POST["religion"]) || !preg_match("/[a-z A-Z]$/", $_POST["religion"]) ) {
						   			  //           $_SESSION['padderrmgs']['religion']= "Religion Is Required and Only Text are Allowed.";
						   			  //           $_SESSION['religion'] = "";
						   			  // }elseif (empty($_POST["postalcode"]) || !preg_match("/[0-9]{6}$/", $_POST["postalcode"]) ) {
						   			  //           $_SESSION['padderrmgs']['postalcode'] = "Postal Code Is Required and Only Number are Allowed.";
						   			  //           $_SESSION['designetion'] = "";
						   			  // }elseif (empty($_POST["address"])) {
						   			  //           $_SESSION['padderrmgs']['address'] = "Address Is Required.";
						   			  //           $_SESSION['address'] = "";  
						   			  // }elseif (empty($_POST["mhistory"])) {
						   			  //           $_SESSION['padderrmgs']['mhistory'] = "Medical History Is Required. ";
						   			  //           $_SESSION['mhistory'] = "";           
						   			 
						   			  // }elseif (empty($_POST["gender"]) || $_POST["gender"] != 'M'|| $_POST["gender"] != 'F') {
						   			  //         $_SESSION['padderrmgs']['gender'] = "Gender Is Required and this formated like M or F";
						   			  //           $_SESSION['gender'] = "";
						   			  // }
									
				             //print_r($_SESSION['padderrmgs']);exit;
				              
						   	 //if(!isset($Err)){
						   	  
						   	  	
						   	 // 	  $ins_data = [
											//     	'emp_id' => $this->htmlValidation($_POST['emp_id']),
											//     	'name' => $this->htmlValidation($_SESSION['name']),
											//     	'email' => $this->htmlValidation($_POST['email']),
											//     	'department' =>$this->htmlValidation($_POST['department']),
											//     	'designetion' => $this->htmlValidation($_POST['designetion']),
											//     	'joining_date' => $this->htmlValidation($_POST['joining_date']),
											//     	'Gender' => $this->htmlValidation($_POST['Gender'])
											//     	];
											//     	$insdata = $this->InsertData('employee',$ins_data);
											// echo "<pre>";
											// print_r($ins_data);
											//     	echo json_encode($insdata);
						   	  	
						   	 //          }else{
						   	 //          		$Response =['Data' => null,
						   	 // 		                   'Message' => $Err.'.',
						   	 // 		                    'Code' => 0
						   	 // 	           	];
											//     		echo json_encode($Response);
											//     	}
						   	 // }else {
						   	 // 	$Response =['Data' => null,
						   	 // 		 'Message' => 'Method must be post.',
						   	 // 		 'Code' => 0
						   	 // 		];
						   	  			
						   	 // 	// $Response = ["Data"] = null;
						   	 // 	// $Response = ["Message"] = 'Metho must be post.';
						   	 //  // $Response = ["Code"] = 0;
						   	 // 		echo json_encode($Response);
						   	  	
	}	


?>