<?php

class patient_model {
	public $table = "users";
	public $table1 = "patients";
	private $Connection;

	public function __construct() {
		$this->conectar = new Conectar();
		$this->Connection = $this->conectar->Connection();
	}

	function htmlValidation($form_data) {
		$form_data = trim(stripcslashes(htmlspecialchars($form_data)));
		$form_data = mysqli_real_escape_string($this->Connection, $form_data);
		return $form_data;
	}


	function selectmaxid() {
		$midsql = "SELECT Max(pid) as lastid FROM ".$this->table1;
		$midsqlEx = $this->Connection->query($midsql);
		$midData = $midsqlEx->fetch_object();
		if ($midsqlEx->num_rows > 0) {
			$response['Data'] = $midData->lastid;
			$response['Code'] = true;
		} else {
			$response['Data'] = null;
			$response['Code'] = false;
		}
		return $response;
	}


	function InsertData($tbl, $data) {
		$response = array();
		// insert into tblName (clms) values (values);
		$clms = implode(',', array_keys($data));
		$vals = implode("','", $data);
		$sql = "insert into $tbl ($clms) values ('$vals')";
		$insertEx = $this->Connection->query($sql);
		if ($insertEx) {
			$response['Data'] = null;
			$response['Code'] = true;
			$response['Message'] = 'Data inserted successfully.';
		} else {
			$response['Data'] = null;
			$response['Code'] = false;
			$response['Message'] = 'Data insertion failed.';

		}
		return $response;
	}
	
	function get_pending_cases(){
		// echo "get_pending_cases";
		// exit;
		$pcassql="SELECT patients.pid,patients.pmshid,patients.contact,upper(concat (patients.pfname,' ',patients.pmname,' ',patients.plname)) as Name,patients.age,patients.gender,patients.date FROM ".$this->table1." ORDER BY patients.date DESC";
		// echo $pcassql;
		// exit;
		
			$pcassqlEx = $this->Connection->query($pcassql);
					if($pcassqlEx->num_rows > 0){
												  while($FetchData = $pcassqlEx->fetch_object()){
												  	$allData[] = $FetchData;
												  	
												  }
												  	$response['Code'] = true;
							              	$response['Message'] = 'Data retrivded successfully.';
							              	$response['Data'] = $allData;
							              	// $response['Pageno'] =$total_pages;
						               	
						              }else {
								            	$response['Code'] = false;
								            	$response['Message'] = 'Data not retrivded .';
								            	$response['Data'] = [];
						               	
						              }
			// 			              	echo"<pre>";
			// print_r($response);
			// exit;
						              return $response;	
			// $pcassqlData = $pcassqlEx->fetch_object();
		
		
	}
	
 function DeleteData($tbl,$where){
			  		$sql="DELETE FROM ".$this->table1."  WHERE ";
			  		// DELETE FROM `employee` WHERE 0
									foreach ($where as $key => $value){
										$sql.="$key = $value";
									}
									// echo $sql;
												$delsqlafter =rtrim($sql);
												// echo "rtrim after".$delsqlafter;
             return $updEx =$this->Connection->query($delsqlafter);
			  }
	
	
	
}




?>