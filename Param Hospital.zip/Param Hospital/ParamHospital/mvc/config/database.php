<?php

define("DB_DRIVER", "mysql");
define("DB_HOST", "localhost");
define("DB_USER", "chinmay");
define("DB_PASS", "Ecs@2021");
define("DB_DATABASE", "medprack");
define("DB_CHARSET", "utf8");

/*
return array(
    "driver"    =>"mysql",
    "host"      =>"localhost",
    "user"      =>"root",
    "pass"      =>"",
    "database"  =>"mvc1",
    "charset"   =>"utf8"
);
*/

?>