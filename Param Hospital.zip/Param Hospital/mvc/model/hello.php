<?php
class hello {

    public function __construct() {
		
    }
}