<?php
class login_model extends Model
{
	public function __construct()
	{
		parent::__construct();
	}
		function LogingData($email, $password) {
									$response = array();
									    // select * from user where email = '' and password = '';
									    $loginsql= "SELECT * FROM users WHERE email = '$email'";
									    // echo $password;
									    $loginEx = $this->$connection->query($loginsql);
									    $loginData = $loginEx->fetch_object();
									  
				              if($loginEx->num_rows > 0 && $password == $loginData->password){
					              	$response['Data'] = $loginData;
					              	$response['Code'] = true;
					              	$response['Message'] = 'Login successfully.';
				               	
				              }else {
				              	  $response['Data'] = null;
						            	$response['Code'] = false;
						            	$response['Message'] = 'Email ro password  is incorrect.';
				               	
				              }
				              // print_r($response);
				              // exit;
				              return $response;
				 }

	}
	?>