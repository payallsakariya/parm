<?php

class model{
	
			
			public $servername = 'localhost';
      public $username = 'chinmay';
      public $password = "Ecs@2021";
      public  $dbname = "medprack";
 
			 	           
			function __construct(){
						 	
			mysqli_report(MYSQLI_REPORT_STRICT);
			
			}	
	}
	
	



?>