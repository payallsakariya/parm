<?php

class model{
	
			
			public $servername = 'localhost';
      public $username = 'chinmay';
      public $password = "Ecs@2021";
      public  $dbname = "medprack";
 
			 	           
			function __construct(){
						 	
			mysqli_report(MYSQLI_REPORT_STRICT);
			
					try{
									
				$this->$connection = new mysqli($this->servername,$this->username,$this->password,$this->dbname);
							// echo "connection successfully";	
								
						}catch(Exception $ex){
							echo "connection Failed".$ex->getMessage();
							
						}
				}		
					
	}
	


?>