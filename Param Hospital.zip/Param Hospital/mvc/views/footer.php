  </div>
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.slimscroll.js"></script>
    <script src="assets/js/select2.min.js"></script>
    <script src="assets/js/moment.min.js"></script>
    <script src="assets/js/bootstrap-datetimepicker.min.js"></script>
    <script src="assets/js/app.js"></script>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script type = "text/JavaScript" src = " https://MomentJS.com/downloads/moment.js"></script>
<footer>
</footer>
<script>

     	   $(document).ready(function() {
		        var today = new Date();
		       
		        $('#dob').datepicker({
				            dateFormat: 'dd-mm-yy',
				            autoclose:true,
				            changeMonth: true,
				            changeYear: true,
				            endDate: "today",
				            maxDate: today
				          }).on('changeDate', function (ev) {
				                $(this).datepicker('hide');
				      });
				            
		        $('#dob').keyup(function () {
		          if (this.value.match(/[^0-9]/g)) {
		            this.value = this.value.replace(/[^0-9^-]/g, '');
		            }
		          });
		          
		              
		         
     	   });
     	   
      
       
         function mydatepicker(){
            	var selectdate = document.getElementById("dob").value;  
		          var age = setAge(selectdate);
		        // var format =  format: 'dd-mm-yyyy';
		           //$('#dob').val(format.selectdate);
		           
		          // var age = moment().diff(selectdate, 'years', true);
		          // console.log(age);
		          // setAge(selectdate);
							 //var age = setAge(selectdate);
							  $('#age').val(age);
              }
        
         

     
			 	 

</script>

</body>


<!-- login23:12-->
</html>

