<html>
	<body>
		<head>
			 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registration user</title>
         <!--bootstrap css-->
         <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
         <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">  
	
	<style>
		.card{
			margin: 0 auto;
			float: none;
			margin-bottom:10px;
			margin-top: 20px;
		}
		
		p{
			display: inline;
		}
		#tbl{
			margin-top: 1%;
		}
		h2{
			background-color: lightgrey;
		}
		

	</style>
		</head>	
		  <div class="card" style="margin :1%;">
		 <h2>Employee List</h2>
	 <div class="card-boby">	 

		  	<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Add new Record</button>

	<div id="myAlert" role="alert" class="alert alert-dismissible fade" style="display:none;">
		<strong>Note</strong><p>example of  ajax</p>
		<button type="button" class="close" data-dismiss="alert">&times;</button>
	</div>
	</div>
	   <table class="table table-bordered teble-sm" id="tbl">
	    <thead>
               <tr>
                  <th scope="col">#</th>
                  <th scope="col">Emp id</th>
                  <th scope="col">Name</th>
                  <th scope="col">Email</th>
                  <th scope="col">Department</th>
                  <th scope="col">Designetion</th>
                  <th scope="col">Joining date</th>
                  <th scope="col">Gender</th>
                  <th scope="col">Action</th>
               </tr>
        </thead>
        <tbody id="tbody">
		     </tbody>
	</table>
	</div>

  <!--modal start-->
     <div class="modal fade" id="myModal" role="dialog">
     <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
        	 <h4 class="modal-title">Add new Record</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
         <form method="post" id="insert_data">
      			<div class="modal-body">
      				<div class="form-group row">
      					<label class="col-4"><b>Employee Id</b></label>
      					<input type="text" name="emp_id" class="form-group" placeholder="Enter employee id">
      				</div>
      				<div class="form-group row">
      					<label class="col-4 "><b>Name</b></label>
      					<input type="text" name="name" class="form-group" placeholder="Enter Neme">
      				</div>
      				<div class="form-group row">
      					<label class="col-4"><b>Email</b></label>
      					<input type="email" name="email" class="form-group" placeholder="Enter Email">
      				</div>
      				<div class="form-group row">
      					<label class="col-4"><b>Department</b></label>
      					<!--aria-label="Default select example" -->
      					<select class="custom-select" name="department" id="department">
 	                <option value="" selected>Choose..</option>
      						<option value="IT">IT</option>
      						<option value="HR">HR</option>
      						<option value="R&D">R&D</option>
      						<option value="sales">sales</option>
      						<option value="Quality">Quality</option>
      						<option value="Marketing">Marketing</option>
                </select>
      				</div>
      				<div class="form-group row">
      					<label class="col-4"><b>Designetion</b></label>
      					<input type="text" name="designetion" class="form-group">
      				</div>
      				<div class="form-group row">
      					<label class="col-4"><b>Joining Date</b></label>
      					<input type="date" name="joining_date" class="form-group" placeholder="Enter Email">
      				</div>
      				<div class="form-group row">
      					<label class="mr-3 col-4"><b>Gender</b></label>
      					 <div class="form-check-inline">
      						  <input class="form-check-input" type="radio" name="gender" value="1" checked>
      					  	 <label class="form-check-lable ml-2">Male</label>
      					  </div>
      						<div class="form-check-inline">
      						  <input class="form-check-input ml-1" type="radio" name="gender" value="0" checked>
      						  <label class="form-check-lable ml-4">Female</label>
      					  </div>
      				</div>
      				<div class="form-group" >

      			    <img height="100" width="80" id="1" data-toggle="modal" data-target="#imagemodalpopup" src='assets/images/crm.png' alt='Text dollar code part one.' />
      					 
      				</div>
      				
      				<!-- The Modal -->

      				<div class="form-group">
      					<span class="success-msg" id="success-msg"></span>
      				</div>
      			</div>
      			<div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" id="close_click">Close</button>
      		    <button type="submit" class="btn btn-primary">Add Record</button>
      			</div>
      		</form>
        </div>
      </div>
      
    </div>
  </div>
    <!--modal end-->
    
    <!--modal Update-->
     <div class="modal fade" id="UpdateModalcenter" role="dialog" tabindex="-1" 
          aria-labeldby="UpdateModalcentertitle" aria-hidden="true">
     <div class="modal-dialog modal-dialog-centered" role="document">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
        	 <h4 class="modal-title" id="UpdateModalcentertitle">Update Record</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="close">
          	<span aria-hidden="true">&times;</span></button>
         
        </div>
        <div class="modal-body">
         <form method="post" id="update_data">
      			<div class="modal-body">
      				<input type="hidden" name="id"  id="id" class="form-group">
      				<div class="form-group row">
      					<label class="col-4"><b>Employee Id</b></label>
      					<input type="text" name="emp_id"  id="emp_id" class="form-group" placeholder="Enter employee id">
      				</div>
      				<div class="form-group row">
      					<label class="col-4 "><b>Name</b></label>
      					<input type="text" name="name" id="name" class="form-group" placeholder="Enter Neme">
      				</div>
      				<div class="form-group row">
      					<label class="col-4"><b>Email</b></label>
      					<input type="email" name="email" id="email" class="form-group" placeholder="Enter Email">
      				</div>
      				<div class="form-group row">
      					<label class="col-4"><b>Department</b></label>
      					<!--aria-label="Default select example" -->
      					<select class="custom-select" name="department" id="department">
 	                <option value="" selected>Choose..</option>
      						<option value="IT">IT</option>
      						<option value="HR">HR</option>
      						<option value="R&D">R&D</option>
      						<option value="sales">sales</option>
      						<option value="Quality">Quality</option>
      						<option value="Marketing">Marketing</option>
                        </select>
      				</div>
      				<div class="form-group row">
      					<label class="col-4"><b>Designetion</b></label>
      					<input type="text" name="designetion" id="designetion" class="form-group" placeholder="Enter Email">
      				</div>
      				<div class="form-group row">
      					<label class="col-4"><b>Joining Date</b></label>
      					<input type="date" name="joining_date" id="joining_date" class="form-group">
      				</div>
      				<div class="form-group row">
      					<label class="mr-3 col-4"><b>Gender</b></label>
      					 <div class="form-check-inline">
      						  <input class="form-check-input" type="radio" name="gender" id="male" value="1" checked>
      					  	 <label class="form-check-lable ml-2">Male</label>
      					  </div>
      						<div class="form-check-inline">
      						  <input class="form-check-input ml-1" type="radio" name="gender" id="female" value="0">
      						  <label class="form-check-lable ml-4">Female</label>
      					  </div>
      				</div>
      				<div class="form-group">
      					<span class="success-msg" id="success-msg"></span>
      				</div>
      			</div>
      			<div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" id="close_click">Close</button>
      		    <button type="submit" class="btn btn-primary">Update Record</button>
      				
      			</div>
      			
      		</form>
        </div>
        
      </div>
      
    </div>
  </div>
   <!--End update modal-->
     
     <!--modal start Delete-->
     <div class="modal fade" id="DeleteModalcenter" role="dialog" tabindex="-1" 
          aria-labeldby="DeleteModalcentertitle" aria-hidden="true">
     <div class="modal-dialog modal-dialog-centered" role="document">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
        	 <h4 class="modal-title" id="DeleteModalcentertitle">Delete Record</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="close">
          	<span aria-hidden="true">&times;</span></button>
         
        </div>
        <div class="modal-body">
        <p>Are you sure</p>
        </div>
        	<div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" id="close_click">Close</button>
      		    <button type="button" class="btn btn-danger" id="deleterec">delete Record</button>
      				
      			</div>
      </div>
      
    </div>
  </div>
   <!--End delete modal-->   
   
   
     <!--start imagepoup modal-->
     <div id="imagemodalpopup" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
               <img class="showimage img-responsive" id="pirview" src="" />
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<!--End modal-->
        
    
        	<script src="https://code.jquery.com/jquery-3.2.1.min.js" type="text/javascript"></script>
        	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
        	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" type="text/javascript"></script>
			<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"></script>
			<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>
			 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

			 
			 <script>
			 	
			 	 $( function(){
			 	 	  Loadtable();
			 	 	  
			 	 	  // insert_data ajax call
			 	 	  $('#insert_data').on("submit", function(e){
			 	 	  	e.preventDefault();
			 	 	  	$.ajax({
			 	 	  		 type :'POST',
			 	 	  		 url :'inst_emp_Data',
			 	 	  		 cache : false,
			 	 	  		 dataType : "json",
			 	 	  		 data :$(this).serialize(),
			 	 	  	}).done(function (dataResult){
			 	 	  		 (dataResult.Code == 1) ?
			 	 	  		  showAlert('Success! ',dataResult.Message,'success') :
			 	 	  		  showAlert('Somthing went! ',dataResult.Message,' danger')
			 	 	  		 console.log(dataResult);
			 	 	  	}).fail(function (dataResult){
			 	 	  		 console.log(dataResult);
			 	 	  		  showAlert('Somthing went! ','please try again later','danger')
			 	 	  	}).always(function (){
			 	 	  		Loadtable();
			 	 	  		$('#insert_data').trigger('reset');
			 	 	  		$('#close_click').trigger('click');
			 	 	  	});
			 	 	  	
			 	 	  })
			 	 	  
			 	 	  // get va in db viwe modal
	 	 	       $(document).on("click","button.editdata",function(){
	 	 	 	       var check_id = $(this).data('dataid');
	 	 	 	       //console.log(check_id);
	 	 	 	       $.getJSON("get_edit_Data",{checkid: check_id}, function(json){
	 	 	 	       	// console.log(json);
	 	 	 	       	$("#UpdateModalcenter").modal('show');
	 	 	 	       	var jasonData = json.Data[0];
	 	 	 	       	// console.log(jasonData);
	 	 	 	       	if(json.Code == 1){
	 	 	 	       	  $('#id').val(jasonData.id);
	 	 	 	       		$('#emp_id').val(jasonData.emp_id);
	 	 	 	       		$('#name').val(jasonData.name);
	 	 	 	       		$('#email').val(jasonData.email);
	 	 	 	       		$('#designetion').val(jasonData.designetion);
	 	 	 	       		$('#joining_date').val(jasonData.joining_date);
	 	 	 	       		$("#department option[value='"+ jasonData.department +"']").prop("selected","selected");
	 	 	 	       		if(jasonData.gender == 1){
	 	 	 	       			$('#male').prop("checked",true);
	 	 	 	       		}else{
	 	 	 	       				$('#female').prop("checked",true);
	 	 	 	       		}
	 	 	 	       	}
	 	 	 	       	
	 	 	 	       }).fail(function(){
	 	 	 	       		Loadtable();
	 	 	 	       	showAlert('Somthing went wrong! ','please try again later','danger')
	 	 	 	       })
			 	 	  })
			 	 	  
			 	 	  // update ajax call
			 	 	  $('#update_data').on("submit", function(e){
			 	 	  	e.preventDefault();
			 	 	  	$.ajax({
			 	 	  		 type :'POST',
			 	 	  		 url :'upd_emp_Data',
			 	 	  		 cache : false,
			 	 	  		 dataType : "json",
			 	 	  		 data :$(this).serialize(),
			 	 	  	}).done(function (dataResult){
			 	 	  		 (dataResult == true) ?
			 	 	  		  showAlert('Success! ','Data updated successfully','success') :
			 	 	  		  showAlert('Somthing went! ','please try again later',' danger')
			 	 	  		 //console.log(dataResult);
			 	 	  	}).fail(function (dataResult){
			 	 	  		 //console.log(dataResult);
			 	 	  		  showAlert('Somthing went! ','please try again later','danger')
			 	 	  	}).always(function (){
			 	 	  		Loadtable();
			 	 	  			$("#UpdateModalcenter").modal('hide');
			 	 	  	});
			 	 	  	
			 	 	  })
			 	 	  
			 	 	  $(document).on("click","button.deletedata",function(){
			 	 	  	$('#DeleteModalcenter').modal('show');
			 	 	  delete_id = $(this).data('dataid');
			 	 	  	// console.log(deleteid);
			 	 	  })
			 	 	  
			 	 	   $('#deleterec').click(function(){
			 	 	  	$.ajax({
			 	 	  		 type :'POST',
			 	 	  		 url :'delete_emp_Data',
			 	 	  		 cache : false,
			 	 	  		 dataType : "json",
			 	 	  		 data :{deleteid:delete_id},
			 	 	  	}).done(function (dataResult){
			 	 	  		 (dataResult == true) ?
			 	 	  		  showAlert('Success! ','Data delete successfully','success') :
			 	 	  		  showAlert('Somthing went! ','please try again later','danger')
			 	 	  		 console.log(dataResult);
			 	 	  	}).fail(function (dataResult){
			 	 	  		 console.log(dataResult);
			 	 	  		  showAlert('Somthing went!','please try again later','danger')
			 	 	  	}).always(function (){
			 	 	  		Loadtable();
			 	 	  			$("#DeleteModalcenter").modal('hide');
			 	 	  	});
			 	 	  	
			 	 	  })
			 
									//image popup modal opne jquery	 	  
			 	 	  
										$(document).ready(function () {
									    $('img').on('click', function () {
									        var imagepath = $(this).attr('src');
									        alert(imagepath);
									              $('#imagemodalpopup').show();
									        document.getElementById('pirview').src = imagepath;
									
									    });
										});
			 	 	  
			});
			 	 
		function showAlert(msg_title,msg_body,msg_type){
			  var alert = $('div[role="alert"]');
			  $(alert).css('display','inline-block')
			   $(alert).css('margin-left','2%')
			  $(alert).find('strong').html(msg_title);
			  $(alert).find('p').html(msg_body);
			  $(alert).removeAttr('class');
			  $(alert).addClass('alert alert-'+ msg_type);
			  $(alert).show();
		}
			 
			 
	 function Loadtable(){
	 	
 	 $.ajax({
			 	 	 url :"get_emp_Data",
			 	   type : "GET",
			 	   data :{
			 	  	 		
			 	 	 	},
			 	 	 	catch :false,
			 	 	 	dataType : 'json',
			 	 	 	success : function(dataResult){
			 	 	 		$('#tbody').empty();
			 	 	 	var	resultdata = dataResult.Data;
			 	 	 		// console.log(resultdata);
			 	 	 		var bodydata = '';
			 	 	 		var i =1;
			 	 	 		if(resultdata != null){
			 	 	 			$.each(resultdata,function(index,row){
			 	 	 				// console.log(row);
			 	 	 				var bodydata = `<tr>
			 	 	 				               <td>${ i++ }</td>
			 	 	 				               <td>${ row.emp_id}</td>
			 	 	 				               <td>${ row.name }</td>
			 	 	 				               <td>${ row.email }</td>
			 	 	 				               <td>${ row.department }</td>
			 	 	 				               <td>${ row.designetion }</td>
			 	 	 				               <td>${ row.joining_date }</td>
			 	 	 				               <td>${ row.Gender == 1 ? 'male':'female' }</td>
			 	 	 				               <td>
          							<button type="button" class="btn btn-info editdata"  data-dataid="${ row.id}">Update</button>			 	 	 	
			 	 	 				     <button type="button" class="btn btn-danger deletedata" data-dataid="${ row.id}">delete</button> 
			 	 	 				               </td>
			 	 	 				               </tr>`;
			 	 	 				               $("#tbl").append(bodydata);
			 	 	 				
			 	 	 			})
			 	 	 		}else{
			 	 	    bodydata ="<tr><td colspan=8 style='text-align:center'> No Data Found!</td></tr>"                  
			 	 	      $("#tbl").append(bodydata);
			 	 	 		}
			 	 	 	}
			 	 	 })
			 	 }
			 	 
			 	 
			 	
			 </script>
	</body>
</html>


