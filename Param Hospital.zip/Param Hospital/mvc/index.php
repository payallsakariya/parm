<?php
$getURL =$_SERVER['PATH_INFO'];
echo 'test';
echo $getURL;

// require 'controller/controller.php';
require_once 'controller/hello.php';
echo 'infr';

$obj = new hello();
print_r($obj);
return $obj->index();

// require 'controller/admission.php';

// ALTER TABLE `user` ADD `role` TINYINT NOT NULL DEFAULT '0' COMMENT '0: User, 1: Admin' AFTER `id`;
?>
