<?php
date_default_timezone_set('Asa/Kolkata');
require_once("model/model.php");
session_start();

class admission extends model{

	public function admission(){
				   	
			    	echo "admission";
				}
}
$obj =new admission;
$obj->admission();
