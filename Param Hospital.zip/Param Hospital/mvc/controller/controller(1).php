<?php

date_default_timezone_set('Asa/Kolkata');
require_once("model/model.php");
session_start();

class controller extends model{
  function __construct(){
				parent::__construct();
				// if(isset($_SERVER['PATH_INFO'])){
				//   switch ($_SERVER['PATH_INFO']) {
				 
				// 	 case '/login':
				// 		   if(isset($_POST['login'])){
				// 			    $email= mysqli_real_escape_string($this->$connection, $_POST['email']);
				// 			    $pass= mysqli_real_escape_string($this->$connection, $_POST['pass']);
				// 			    // echo "email".$_POST['email'];
				// 			    // echo $pass;
				// 			    // echo $email;
				// 			    // exit;
							    
				// 			    $loginEx= $this->LogingData($email, $pass);
							   
							    
				// 			       if($loginEx['Code'] == 1){
				// 					      $_SESSION['user_data'] = $loginEx['Data'];
				// 							      	 ?>
				// 								        <script type="text/javascript">
				// 								        	 window.location.href = 'index';
				// 								        </script>
												        
				// 								        <?php
											      
				// 					      }else {
				// 						          $_SESSION['user_data'] = $loginEx['Message'];
										        	
				// 						        }
				// 			       }			
				// 									include 'views/header.php';
				// 									include 'views/login.php';
				// 									include 'views/footer.php';
										
				// 	break;
			  	
			 // 	case '/forgot-password':
				// 		    include 'views/header.php';
				// 				include 'views/forgot-password.php';
				// 	      include 'views/footer.php';
			 // 	break;
			 // 	case '/index':
				// 		    include 'views/header.php';
				// 				include 'views/index.php';
				// 	      include 'views/footer.php';
			 // 	break;
			 // 	 case '/logout':
				// 		    unset($_SESSION['user_data']);
		  //     session_destroy();
		  //     	?>
		  //       <script type="text/javascript">
		  //       	 alert("User data logged out successfully.");
		  //       	 window.location.href = 'login';
		  //       </script>
		        
		  //       <?php
			 // 	break;
			 // 	// 	case '/add-patient':
			 // 	// 	$Err="";
			  	 	
			 //  //			// $nameErr = $emailErr = $empidErr = $departmentErr =  $designetionErr ="";
				// 		//   try{
				// 		//   		if($_SERVER['REQUEST_METHOD'] == 'POST') {
				// 		//   			$from =$_POST['birthdate'];
				// 		//   			$to   = new DateTime('today');
				// 		//   		// 	echo $to;
    //   //     //              echo $from->diff($to)->y;
				// 		//   		// exit;
						   
				// 		//   			if(empty($_POST['phone']) || !preg_match("/[0-9]{10}$/", $_POST['phone']) ) {
			 //  //			             $Errphone= "Phone Number Is Required and Only Number are Allowed";
			 //  //			             $_SESSION['phone'] = "";
				// 		//   			  } else {
				// 		// 							 $_SESSION['phone'] = $this->htmlValidation($_POST["phone"]);
				// 		// 						}
				// 		//   	   	if(empty($_POST['fname']) ) {
				// 		//   			            $Errfname = "First Name Is Required and Only Text are Allowed";
				// 		//   			            $_SESSION['fname'] = "";
				// 		//   			  }else {
				// 		// 							 $_SESSION['fname'] = $this->htmlValidation($_POST["fname"]);
				// 		// 						}
				// 		//   			if (empty($_POST["mname"]) || !preg_match("/[a-z A-Z]$/", $_POST["mname"]) ) {
			 //  //			            $Errmname = "Middle Name Is Required and Only Text are Allowed";
			 //  //			            $_SESSION['mname'] = "";
				// 		//   			  } else {
				// 		// 							 $_SESSION['mname'] = $this->htmlValidation($_POST["mname"]);
				// 		// 						}
						   			  
				// 		//   			 if (empty($_POST["lname"]) || !preg_match("/[a-z A-Z]$/", $_POST["lname"]) ) {
				// 		//   			            $Errlname = "Last Name Is Required and Only Text are Allowed.";
				// 		//   			            $_SESSION['lname'] = "";  
				// 		//   			   }else {
				// 		// 							 $_SESSION['lname'] = $this->htmlValidation($_POST["lname"]);
				// 		// 						}
					   			   
				// 	 //  			    if (empty($_POST["religion"]))  {
				// 	 //  			          $Errreligion= "Religion Is Required. ";
			 //  //			          	  $_SESSION['religion'] = "";
				// 	 //  			  }else {
				// 		// 							 $_SESSION['religion'] = $this->htmlValidation($_POST["religion"]);
				// 		// 						}
				// 	 //  			  if (empty($_POST["postalcode"]) || !preg_match("/[0-9]{6}$/", $_POST["postalcode"]) ) {
				// 	 //  			            $Errpostalcode = "Postal Code Is Required and Only Number are Allowed.";
				// 	 //  			            $_SESSION['postalcode'] = "";
				// 		//   			  }else {
				// 		// 							 $_SESSION['postalcode'] = $this->htmlValidation($_POST["postalcode"]);
				// 		// 						}
				// 		//   			  if (empty($_POST["address"])) {
				//   // 			            $Erraddress = "Address Is Required.";
				//   // 			            $_SESSION['address'] = "";  
				// 		//   			  }else {
				// 		// 							 $_SESSION['address'] = $this->htmlValidation($_POST["address"]);
				// 		// 						}
				// 		//   			  if (empty($_POST["mhistory"])) {
				// 	 //  			            $Errmhistory = "Medical History Is Required. ";
				// 	 //  			            $_SESSION['mhistory'] = "";           
					   			 
				// 		//   			  }else {
				// 		// 							 $_SESSION['mhistory'] = $this->htmlValidation($_POST["mhistory"]);
				// 		// 						}
						   			  
				// 		//   			  if (empty($_POST["gender"])) {
				// 		//   			          $Errgender = "Gender Is Required.";
				// 		//   			            $_SESSION['gender'] = "";
				// 		//   			  }else {
				// 		// 							 $_SESSION['gender'] = $this->htmlValidation($_POST["gender"]);
				// 		// 						}
				// 		//   			  if (empty($_POST["bloodgroup"]))  {
				// 		//   			          $Errbloodgroup = "Bloodgroup Is Required. ";
				// 		//   			            $_SESSION['bloodgroup'] = "";
				// 		//   			  }else {
				// 		// 							 $_SESSION['bloodgroup'] = $this->htmlValidation($_POST["bloodgroup"]);
				// 		// 						}
				// 		//   			  if (empty($_POST["birthdate"])) {
				// 		//   			            $Errbirthdate = "Birthdate Is Required.";
				// 		//   			            $_SESSION['birthdate'] = "";  
				// 		//   			  }else {
				// 		// 							 $_SESSION['birthdate'] = $this->htmlValidation($_POST["birthdate"]);
				// 		// 						}
						   			 
						   			   
				// 		//   	  }
				// 		//   	  if(isset($_POST['Submit'])){
				// 		//   	  	if($Errbirthdate ="" && $Errbloodgroup =""){
						   			  	
				// 		//   			  }
				// 		//   	  }
						   	   
						    
				// 		//   }catch (\Exception $ex){
				// 		//   	throw $ex;
				// 		//   }
						   
				// 		//   //$date =$this->calculate_age($_POST)
				// 		//     include 'views/header.php';
				// 		// 		include 'views/add-patient.php';
				// 	 //     include 'views/footer.php';
			 // 	// break;
				// 	default:
				// 		// code...
				// 		break;
				// 		}
			 //   }
				}
}
$obj =new controller;

?>
