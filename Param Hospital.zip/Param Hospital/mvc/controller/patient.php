<?php
class patient extends controller{
		
							    function __construct() {
							         parent::__construct();
						       }
				   	
				   	     function patient() {
	
											$this->view->allrecords = $this->model->getAllrecords();
											$this->view->render('index/index');
											
								  }
								  function insert(){
								  	     	if(isset($_SERVER['PATH_INFO'])){
						 	          $Err="";
			  	 	
							   			// $nameErr = $emailErr = $empidErr = $departmentErr =  $designetionErr ="";
										   try{
										   		if($_SERVER['REQUEST_METHOD'] == 'POST') {
										   			$from =$_POST['birthdate'];
										   			$to   = new DateTime('today');
										   		// 	echo $to;
				                    //   echo $from->diff($to)->y;
										   		// exit;
										   
										   			if(empty($_POST['phone']) || !preg_match("/[0-9]{10}$/", $_POST['phone']) ) {
							   			             $Errphone= "Phone Number Is Required and Only Number are Allowed";
							   			             $_SESSION['phone'] = "";
										   			  } else {
																	 $_SESSION['phone'] = $this->htmlValidation($_POST["phone"]);
																}
										   	   	if(empty($_POST['fname']) ) {
										   			            $Errfname = "First Name Is Required and Only Text are Allowed";
										   			            $_SESSION['fname'] = "";
										   			  }else {
																	 $_SESSION['fname'] = $this->htmlValidation($_POST["fname"]);
																}
										   			if (empty($_POST["mname"]) || !preg_match("/[a-z A-Z]$/", $_POST["mname"]) ) {
							   			            $Errmname = "Middle Name Is Required and Only Text are Allowed";
							   			            $_SESSION['mname'] = "";
										   			  } else {
																	 $_SESSION['mname'] = $this->htmlValidation($_POST["mname"]);
																}
										   			  
										   			 if (empty($_POST["lname"]) || !preg_match("/[a-z A-Z]$/", $_POST["lname"]) ) {
										   			            $Errlname = "Last Name Is Required and Only Text are Allowed.";
										   			            $_SESSION['lname'] = "";  
										   			   }else {
																	 $_SESSION['lname'] = $this->htmlValidation($_POST["lname"]);
																}
									   			   
									   			    if (empty($_POST["religion"]))  {
									   			          $Errreligion= "Religion Is Required. ";
							   			          	  $_SESSION['religion'] = "";
									   			  }else {
																	 $_SESSION['religion'] = $this->htmlValidation($_POST["religion"]);
																}
									   			  if (empty($_POST["postalcode"]) || !preg_match("/[0-9]{6}$/", $_POST["postalcode"]) ) {
									   			            $Errpostalcode = "Postal Code Is Required and Only Number are Allowed.";
									   			            $_SESSION['postalcode'] = "";
										   			  }else {
																	 $_SESSION['postalcode'] = $this->htmlValidation($_POST["postalcode"]);
																}
										   			  if (empty($_POST["address"])) {
								   			            $Erraddress = "Address Is Required.";
								   			            $_SESSION['address'] = "";  
										   			  }else {
																	 $_SESSION['address'] = $this->htmlValidation($_POST["address"]);
																}
										   			  if (empty($_POST["mhistory"])) {
									   			            $Errmhistory = "Medical History Is Required. ";
									   			            $_SESSION['mhistory'] = "";           
									   			 
										   			  }else {
																	 $_SESSION['mhistory'] = $this->htmlValidation($_POST["mhistory"]);
																}
										   			  
										   			  if (empty($_POST["gender"])) {
										   			          $Errgender = "Gender Is Required.";
										   			            $_SESSION['gender'] = "";
										   			  }else {
																	 $_SESSION['gender'] = $this->htmlValidation($_POST["gender"]);
																}
										   			  if (empty($_POST["bloodgroup"]))  {
										   			          $Errbloodgroup = "Bloodgroup Is Required. ";
										   			            $_SESSION['bloodgroup'] = "";
										   			  }else {
																	 $_SESSION['bloodgroup'] = $this->htmlValidation($_POST["bloodgroup"]);
																}
										   			  if (empty($_POST["dob"])) {
										   			            $Errbirthdate = "Birthdate Is Required.";
										   			            $_SESSION['dob'] = "";  
										   			  }else {
																	 $_SESSION['dob'] = $this->htmlValidation($_POST["dob"]);
																}
										   	   }
												   }catch (\Exception $ex){
												   	throw $ex;
												   }
											}
											
											
											$action=$_POST['submit']; 
											if ($action=='submit')
											{
												echo'$action';
											$arg=$_POST['id'];
											$data = array(
											'id' =>null,
											'name' =>$_POST['name'],
											'email' =>$_POST['email'],
											'contact' => $_POST['contact']
											);
											$this->model->submit_index($data);
											
											}
											header('location: index');
											
						  // //$date =$this->calculate_age($_POST)
						  //   include 'views/header.php';
								// include 'views/add-patient.php';
					   //   include 'views/footer.php';
					
 }
				   	
				  		
			
			    
				
				
				public function edit(){
				   		parent::__construct();
				  			if(isset($_SERVER['PATH_INFO'])){
						 	// $Err="";
			  	 	echo "editpatient";
			   			// $nameErr = $emailErr = $empidErr = $departmentErr =  $designetionErr ="";
						   try{
						   		if($_SERVER['REQUEST_METHOD'] == 'POST') {
						   			$from =$_POST['birthdate'];
						   			$to   = new DateTime('today');
						   		// 	echo $to;
                    //   echo $from->diff($to)->y;
						   		// exit;
						   
						   			if(empty($_POST['phone']) || !preg_match("/[0-9]{10}$/", $_POST['phone']) ) {
			   			            $Errphone= "Phone Number Is Required and Only Number are Allowed";
			   			            $_SESSION['phone'] = "";
						   			  } else {
													 $_SESSION['phone'] = $this->htmlValidation($_POST["phone"]);
												}
						   	   	if(empty($_POST['fname']) ) {
						   			            $Errfname = "First Name Is Required and Only Text are Allowed";
						   			            $_SESSION['fname'] = "";
						   			  }else {
													 $_SESSION['fname'] = $this->htmlValidation($_POST["fname"]);
												}
						   			if (empty($_POST["mname"]) || !preg_match("/[a-z A-Z]$/", $_POST["mname"]) ) {
			   			            $Errmname = "Middle Name Is Required and Only Text are Allowed";
			   			            $_SESSION['mname'] = "";
						   			  } else {
													 $_SESSION['mname'] = $this->htmlValidation($_POST["mname"]);
												}
						   			  
						   			 if (empty($_POST["lname"]) || !preg_match("/[a-z A-Z]$/", $_POST["lname"]) ) {
						   			            $Errlname = "Last Name Is Required and Only Text are Allowed.";
						   			            $_SESSION['lname'] = "";  
						   			   }else {
													 $_SESSION['lname'] = $this->htmlValidation($_POST["lname"]);
												}
					   			   
					   			    if (empty($_POST["religion"]))  {
					   			          $Errreligion= "Religion Is Required. ";
			   			          	  $_SESSION['religion'] = "";
					   			  }else {
													 $_SESSION['religion'] = $this->htmlValidation($_POST["religion"]);
												}
					   			  if (empty($_POST["postalcode"]) || !preg_match("/[0-9]{6}$/", $_POST["postalcode"]) ) {
					   			            $Errpostalcode = "Postal Code Is Required and Only Number are Allowed.";
					   			            $_SESSION['postalcode'] = "";
						   			  }else {
													 $_SESSION['postalcode'] = $this->htmlValidation($_POST["postalcode"]);
												}
						   			  if (empty($_POST["address"])) {
				   			            $Erraddress = "Address Is Required.";
				   			            $_SESSION['address'] = "";  
						   			  }else {
													 $_SESSION['address'] = $this->htmlValidation($_POST["address"]);
												}
						   			  if (empty($_POST["mhistory"])) {
					   			            $Errmhistory = "Medical History Is Required. ";
					   			            $_SESSION['mhistory'] = "";           
					   			 
						   			  }else {
													 $_SESSION['mhistory'] = $this->htmlValidation($_POST["mhistory"]);
												}
						   			  
						   			  if (empty($_POST["gender"])) {
						   			          $Errgender = "Gender Is Required.";
						   			            $_SESSION['gender'] = "";
						   			  }else {
													 $_SESSION['gender'] = $this->htmlValidation($_POST["gender"]);
												}
						   			  if (empty($_POST["bloodgroup"]))  {
						   			          $Errbloodgroup = "Bloodgroup Is Required. ";
						   			            $_SESSION['bloodgroup'] = "";
						   			  }else {
													 $_SESSION['bloodgroup'] = $this->htmlValidation($_POST["bloodgroup"]);
												}
						   			  if (empty($_POST["dob"])) {
						   			            $Errbirthdate = "Birthdate Is Required.";
						   			            $_SESSION['dob'] = "";  
						   			  }else {
													 $_SESSION['dob'] = $this->htmlValidation($_POST["dob"]);
												}
						   	  }
						   
						   	   
						    
						   }catch (\Exception $ex){
						   	throw $ex;
						   }
						   
						   //$date =$this->calculate_age($_POST)
						    include 'views/header.php';
								include 'views/pending-cases.php';
					      include 'views/footer.php';
					}
			
			    
				}
}
// 
// $obj =new patient;
// $obj->add();

?>
