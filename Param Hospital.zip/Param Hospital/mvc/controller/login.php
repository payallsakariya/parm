<?php
class Index extends Controller {
    function __construct() {
		parent::__construct();
	}
	
	function login() {
	
		// $this->view->allrecords = $this->model->LogingData();
		$this->view->render('login/header');
		$this->view->render('login/login');
		$this->view->render('login/footer');
			  //   include 'views/header.php';
					// include 'views/login.php';
					// include 'views/footer.php';
		
	}
}
?>