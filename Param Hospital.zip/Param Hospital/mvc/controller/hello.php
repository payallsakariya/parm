<?php

class hello {

	function __construct() {
		
		//parent::__construct();
	}
	
	function index() {
	
		//echo 'in controller';exit;
			//header('location: ../../hello/index');
			
			include 'views/header.php';
			include 'views/hello/index.php';
			include 'views/footer.php';
		//$this->view->render('hello/index');
		
	}
}
	?>
