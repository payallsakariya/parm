<!-- 4. Write a  program to input and print the age which should be greater than 18 and less than 30, 
           age check should be there and input  the age recursively until the age value is not valid 

-->



<html>
  <body>
  <form  method="post">
    <table>
      <tr>
        <td>
          <label for="">Enter Age</label>
        </td>
        <td>
          <input type="text" id="age" name="age" onblur="myfunction()">
        </td>
      </tr>
     
    </table>
  </form>
  <p id="demo"></p>
  <br>
  <p id="demo1"></p>
  <script>
    function myfunction(){
      var age=document.getElementById("age").value;
      document.getElementById("demo").innerHTML=age;
      let ans;
      if(18<= age &&  age <=30){
        ans="yes";
      }
     else {
        ans="no";
    }
    document.getElementById("demo1").innerHTML=ans;
    }
  </script>
  </body>
</html>
<?php
