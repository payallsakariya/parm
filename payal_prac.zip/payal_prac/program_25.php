<html>
  <body>
    <form method="post" target="_top">
      <table>
        <tr>
          <td>
            <label for="e_number">enter number</label>
          </td>
          <td>
            <input type="text" id="e_number" name="e_number">
          </td>
        </tr>
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
        
      </table>
    </form>
    <?php 
    $number =$_POST["e_number"];
    if($number>0){
      if($number%2==0){
        echo "Positive Even";
      }else {
        echo  "Positive Odd";
      }
    }
    
    ?>
  </body>
</html>
