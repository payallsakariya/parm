<html>
  <body>
    <form method='post'>
      <label for='num'> Enter Number : </label>
      <input type='text' id='num' name='num'>
      <input type='submit' name='Submit'>
    </form>
    <?php
    $number=$_POST['num'];
    for($i=1;$i<=100;$i++){
       if($i%$number==3){
         echo "<br>".$i;
       }
    }
    ?>
  </body>
</html>