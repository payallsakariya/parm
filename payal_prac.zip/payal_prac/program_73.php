<!--
73. Write a  Program to count blanks, tabs, and newlines in an input text.  
Sample Output:
Number of blanks, tabs, and newlines:
Input few words/tab/newlines
The quick		
brown fox jumps
over the lazy dog
^Z
blank=7,tab=2, newline=3

-->
 <html>
      <body>
        
        <form method='post'>
          <table>
            <tr>
              <td>
                <label for='str'> Enter string: </label>
              </td>
              <td>
                <textarea id="str" name="str" rows="3" cols="50"></textarea>
              </td>
            </tr>
            
            <tr>
              <td></td>
              <td>
                <br>
                <input type="submit" name="Submit1">
              </td>
            </tr>
          </table>
        </form>
      </body>
    </html>
    <?php
    
    $str1=$_POST['str'];
  $str="The quick brown fox jumps over the lazy dog";
        echo $str."<br>";
        echo ord("a");
        echo "<br>Number of words = ".str_word_count($str);
        echo "<br>Number of Characters = ".strlen($str);
        echo "<br>";
        echo nl2br($str1);
        
        
    ?>