<!--
124. Write a  Program that reads an array of integers (length 7), replace every negative or null element by 1 and print the array elements.  
Sample Output:
Input 7 array elements:
15
12
-7
25
0
27
53

Array elements:
array_nums[0] = 15
array_nums[1] = 12
array_nums[2] = 1
array_nums[3] = 25
array_nums[4] = 1
array_nums[5] = 27
array_nums[6] = 53


-->
<html>
      <body>
        <form method='post'>
          <table>
            <tr>
              <td>
                 <label for='no1'> Enter number 1 : </label>
              </td>
              <td>
                <input type='text' id='no1' name='no1'>
              </td>
            </tr>
            
             <tr>
              <td>
                 <label for='no2'> Enter number 2 : </label>
              </td>
              <td>
                <input type='text' id='no2' name='no2'>
              </td>
            </tr>
            
             <tr>
              <td>
                 <label for='no3'> Enter number 3 : </label>
              </td>
              <td>
                <input type='text' id='no3' name='no3'>
              </td>
            </tr>
            
            <tr>
              <td>
                 <label for='no4'> Enter number 4  : </label>
              </td>
              <td>
                <input type='text' id='no4' name='no4'>
              </td>
            </tr>
            
            <tr>
              <td>
                 <label for='no5'> Enter number 5  : </label>
              </td>
              <td>
                <input type='text' id='no5' name='no5'>
              </td>
            </tr>
            
            
            <tr>
              <td>
                 <label for='num_6'> Enter number 6  : </label>
              </td>
              <td>
                <input type='text' id='num_6' name='num_6'>
              </td>
            </tr>
            
            <tr>
              <td>
                 <label for='num_7'> Enter number 7 : </label>
              </td>
              <td>
                <input type='text' id='num_7' name='num_7'>
              </td>
            </tr>
            
            <tr>
              <td>
                 <input type='submit' name='Submit'>
              </td>
            </tr>
            
          </table>
             
        </form>
      </body>
    </html>
    
    
    <?php 
    
        $number1 = $_POST['no1'];
        $number2 = $_POST['no2'];
        $number3 = $_POST['no3'];
        $number4 = $_POST['no4'];
        $number5 = $_POST['no5'];
        $number6 = $_POST['num_6'];
        $number7 = $_POST['num_7'];
        
        $num_array=array($number1 ,$number2 ,$number3 ,$number4 ,$number5,$number6,$number7);
      // print_r($num_array);
        for($i=0;$i<7;$i++){
          if($num_array[$i]<=0){
            // $num_array[$i] == 1;
             echo "<br>array_nums[$i] = ".'1';
          }else {
              echo "<br>array_nums[$i] = ".$num_array[$i];
             }   
        }     
    ?>    