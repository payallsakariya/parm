<!-- 
34. Write a  Program to print 3 numbers in a line, starting from 1 and print n lines. Accept number of lines (n, integer) from the user.  
Test Data :
Input number of lines: 5

-->

<html>
  <body>
    <form method="post">
      <label for="no1"> Enter value 1</label>
      <input type="text" id='no1' name='no1'>
      <br><br>
       <label for="no2"> Enter value 2</label>
      <input type="text" id='no2' name='no2'>
      <br><br>
      <input type="submit" name="Submit">
    </form>
             
      <?php 
        $a=$_POST['no1'];
        $b=$_POST["no2"];
       // echo $x;
        ?>
        
        <table>
          <tr>
            <td>
               <?php
               echo "<br><br>PROGRAM 34<br><br> ";
               $k=1;  
             for($i=0;$i<$a;$i++){  
               for($j=0;$j<3;$j++){  
                    echo $k." ";  
                     $k++;  
                   }  
                 echo "<br>";  
               } 
               ?>      
              
            </td>
          </tr>
          
          <tr>
            <td>
              <?php
              echo "<br><br>progrem 35<br><br>";
             // $k=1;
              //$q=1;
               for($i=1;$i<=$a;$i++){  
               for($j=1;$j<4;$j++){  
                   echo  pow($i,$j)." ";
                   }  
                  
                 echo "<br>";  
               } 
              
              ?>
              
            </td>
          </tr>
          
          
          
          <tr>
            <td>
               <?php
               echo "<br><br>PROGRAM 36 <br><br> ";
               $k=1;  
             for($i=0;$i<$a;$i++){  
               for($j=0;$j<$b;$j++){  
                    echo $k." ";  
                     $k++;  
                   }  
                 echo "<br>";  
               } 
               ?>      
              
            </td>
          </tr>
          
          <tr>
            <td>
              
              
               <?php
               echo "<br><br>PROGRAM 35<br><br> ";
               $k=1;  
             for($i=1;$i<5;$i++){  
               echo $i." ";
               for($j=1;$j<2;$j++){  
                   $s=$i*$i;
                    echo $s." ";  
                       
                   } 
                   echo $f=$s*$i." ";
                 echo "<br>";  
               } 
               ?>      
            </td>
          </tr>
        </table>
        
          
  </body>
</html>

