<!-- 
10. Write a  Program that accepts three integers and find the maximum of three.  
Test Data:
Input the first integer: 25
Input the second integer: 35
Input the third integer: 15
Expected Output:
Maximum value of three integers: 35

-->

<html>
  <body>
     <form  method="post">
      <table>
        <tr>
          <td>
            <label for="no1">Input the first integer:</label>
          </td>
          <td>
            <input type="text" id="no1" name="no1" onblur="myfunction()">
          </td>
        </tr>
        <tr>
          <td>
            <label for="no2">Input the second integer:</label>
          </td>
          <td>
            <input type="text" id="no2" name="no2" onblur="myfunction()">
          </td>
        </tr>
        
        <tr>
          <td>
            <label for="no3">Input the third integer:</label>
          </td>
          <td>
            <input type="text" id="no3" name="no3" onblur="myfunction()">
          </td>
        </tr>
      </table>
      
    </form>
     <p id="demo1"></p>
      <p id="demo2"></p>  
      <p id="demo3"></p> 
      <p id="demo"></p>
      <P id="demo4"></P>
   <script>
     function myfunction(){
       var num_1 = document.getElementById("no1").value;
       // document.getElementById('demo1').innerHTML = num_1;
        
        var num_2 = document.getElementById("no2").value;
        // document.getElementById('demo2').innerHTML = num_2;
        
         var num_3 = document.getElementById("no3").value;
        // document.getElementById('demo3').innerHTML = num_3;
        const num_array =[num_1,num_2,num_3];
        
        document.getElementById("demo").innerHTML = num_array;
        let text=" ";
        if(num_1 > num_2 && num_1>num_3){
          text = num_1;
        }else if(num_2>num_3){
          text =num_2;
        }else{
          text= num_3;
        }
         document.getElementById("demo4").innerHTML ="Maximum value of three integers : "+ text;
     }
   </script>
  </body>
</html>