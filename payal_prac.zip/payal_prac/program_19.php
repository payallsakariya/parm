<!-- 19. Write a  Program that reads an integer between 1 and 12 and print the month of the year in English.  
      Test Data :
      Input a number between 1 to 12 to get the month name: 8
      Expected Output:
      August
      January, February, March, April, May, June, July, and August. September, October, November, and December.
-->
<html>
  <body>
    <form method="post" target="_top" >
      <table>
        <tr>
          <td>
            <label for="e_name">Enter number :</label>
          </td>
          <td>
            <input type="text" id="e_name" name="e_name">
          </td>
        </tr>
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
      </table>
      
    </form>
    
  <?php 
            $number= $_POST["e_name"];
         $year=array("1"=>"January","2"=>"February",
                       "3"=>"March","4"=>"April",
                       "5"=>"May","6"=>"June",
                       "7"=>"July","8"=>"August",
                       "9" =>"September","10"=>"October",
                       "11"=>"November","12"=>"December");
                  //print_r(array_values($year));
                  echo $year[$number];
  ?>
  </body>
</html>