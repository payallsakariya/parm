<!-- phph -> PHP Numbers ->PHP Casting Strings and Floats to Integers  like (int)value.
 -->


<html>
  <body>
       <?php $a=$_POST["dgt"];
             echo " Test Data :<br>";
            echo " Number of days :".$a ."<br>";
            
            $y= $a / 365;
            $y1=(int)$y;
            $Y=365*$y1;
            $w1=$a-$Y;
            $w2=$w1/7;
            $w3=(int)$w2;
            $W=$w3*7;
            $d1=$a-$Y-$W;
           
            echo "Years : ".$y1."<br>";
            echo "Weeks : ".$w3."<br>"; 
            echo "Days :".$d1;
          
            
         ?>
  </body>
</html>
