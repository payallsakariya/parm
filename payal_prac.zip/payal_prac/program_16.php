<html>
  <body>
    <form method="post" target="_top">
      <table>
        <tr>
          <td>
            <label for="first_no">Enter the first number :</label>
          </td>
          <td>
            <input type="text" id="first_no" name="first_no">
          </td>
        </tr>
        
        <tr>
        <td>
            <label for="second_no">Enter the second number :</label>
          </td>
          <td>
            <input type="text" id="second_no" name="second_no">
          </td>
        </tr>
        
        <tr>
         <td>
            <label for="third_no">Enter the third number :</label>
          </td>
          <td>
            <input type="text" id="third_no" name="third_no">
          </td>
        </tr>
         
         <tr>
         <td>
            <label for="fourth_no">Enter the fourth number :</label>
          </td>
          <td>
            <input type="text" id="fourth_no" name="fourth_no">
          </td>
        </tr>

         <tr>
         <td>
            <label for="fifth_no">Enter the  fifth number :</label>
          </td>
          <td>
            <input type="text" id="fifth_no" name="fifth_no">
          </td>
        </tr>
        
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
      </table>
    </form>
    
    <?php 
    
       $first_no = $_POST["first_no"];
       $second_no = $_POST["second_no"];
       $third_no = $_POST["third_no"];
       $fourth_no = $_POST["fourth_no"];
       $fifth_no = $_POST["fifth_no"];
       $number=array($first_no,$second_no,$third_no,$fourth_no,$fifth_no);
       $evenarr=array();
       $oddarr=array();
       //print_r($number);
       $count=count($number);
      //print_r($count);
      for($x=0;$x<$count;$x++){
        //echo $number[$x]."<br>";
        //$value=$number[$x];
        //echo $value."<br>";
        if($number[$x]%2==0){
          //echo $number[$x];
          array_push($evenarr,$number[$x]);
         // echo "<br>";
        // print_r array_sum($number[$x]);
          }
        else {
           array_push($oddarr,$number[$x]);
        }
      }
       print_r("Even number sum : ".array_sum($evenarr));
      
       print_r("<br>Odd number sum : ".array_sum($oddarr));
    ?>
    
  </body>
</html>
