   <html>
      <body>
        
        <form method='post'>
          <table>
            <tr>
              <td>
                <label for='num'> Enter mathematics marks : </label>
              </td>
              <td>
                <input type='text' id='num' name='num'>
              </td>
            </tr>
            
            <tr>
              <td></td>
              <td>
                <br>
                <input type="submit" name="Submit1">
              </td>
            </tr>
          </table>
        </form>
      </body>
    </html>
    
    
     <?php 
    // echo $_POST['num'];
          session_start();
          
          if(!empty($_SESSION['num_get'])){
            
          }else {
            
            $_SESSION['num_get']=array();
          }
          if($_POST['num']>0){
            array_push($_SESSION['num_get'],$_POST['num']);
           
              print_r($_SESSION);
               
          }else{
            
            $count=count($_SESSION['num_get']);
            echo "<br>Number of positive values entered is ".$count;
            $sum_array=array_sum($_SESSION['num_get']);
            echo "<br>Maximum value entered is ".max($_SESSION['num_get']);
            echo "<br>Minimum value entered is ".min($_SESSION['num_get']);
            echo "<br>Average value is ".$sum_array/$count;
           
            // echo "<br>".$sum_array;
            session_destroy();
          }
             
          
             
    ?>  
