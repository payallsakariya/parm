
    
    
    
    <html>
      <body>
        <form method='post'>
          <label for='num'> Enter value : </label>
          <input type='text' id='num' name='num'>
          <input type='submit' name='Submit'>
        </form>
      </body>
    </html>
    
    
    <?php 
    
        
        $number = $_POST['num'];
        
        $flag = true;
        $number1=array();
        while($number!=0){
          echo "jklll";
          //$_POST['number']="";
          // $num_id = number_.$number;
  
          
        
        
        // echo($_POST[$num_id]);
        // $number = $_POST[$num_id];
        // $number = isset($_POST[$num_id]) ? $_POST[$num_id] : '';
       array_push($number1,$number);
           //$_POST['number']="";  
           echo $number;
            
          }
       print_r($number1);
       /* $count=count($number1);
        for($i=0;$i<=$count;$i++){
          echo  $number1[$i];
          echo "<br>";
        }*/
        ?>