<!--
54. Write a  Program that accepts a positive integer n less than 100 from the user and prints out the sum 14 + 24 + 44 + 74 + 114 + • • • + m4 , where m is less than or equal to n. Print appropriate message.  
Input a positive number less than 100: 68
Sum of the series is 37361622

-->


<html>
  <body>
    <form method="post">
      <label for="no1"> Enter password : </label>
      <input type="text" id='no1' name='no1'>
      <br><br>
      <input type="submit" name="Submit">
    </form>
    
    
      <?php
           $num=$_POST['no1'];
           $num_array=array();
           $k=1;
           $j=1;
           if($num<100){
           for($i=1;$i<=$num;$i++){
            // echo "<br>".$j;
                $a=pow($j,4);
                array_push($num_array,$a);
                $j+=$k;
                $k++;
           }
          // print_r($num_array);
           $sum=array_sum($num_array);
           echo("Sum of the series is ".$sum);
           }else {
             echo "plesa Enter no is < 100";
           }
      ?>

</body>
</html>