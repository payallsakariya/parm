<!--
146. Write a  Program to extract words of 3 to 6 characters length from a given sentence not more than 1024 characters.  
Input:
English sentences consisting of delimiters and alphanumeric characters are given on one line.
Sample Output:
English sentences consisting of delimiters and alphanumeric characters on one line:
w3resource.com

Extract words of 3 to 6 characters in length from the said sentence:
com

-->
<html>
  <body>
    <form method='post'>
      <label for='str'> Enter Number : </label>
      <input type='text' id='str' name='str'>
      <input type='submit' name='Submit'>
    </form>
    <?php
    
      $str=$_POST['str'];
      $count=strlen($str);
      $sub_array=array();
      // echo $count;
      $k=0;
      for($i=0;$i<$count;$i++){
        
        if(ord($str[$i])==46){
           // echo $str[$i]."<br>";
           $k++;
           array_push($sub_array,$str[$i]);
        }else {
          if($k>0){
            array_push($sub_array,$str[$i]);
          }
        }
      }
      $len=count($sub_array);
      // print($len);
     for($j=0;$j<$len;$j++){
        echo $sub_array[$j];
     }
  
      
    ?>
  </body>
</html>