<html>
  <body>
   <form method='post'>
          <label for='num'> enter number : </label>
          <input type='text' id='num' name='num'>
          <input type='submit' name='Submit'>
   </form>
   <?php
       $number=$_POST['num'];
     echo "The number of 3 :-".substr_count("$number","3");
     echo "<br>";
     
          $strlen=strlen($number);
        $num_array=array();
        for($i=0;$i<=$strlen;$i++){
       
            array_push($num_array,$number[$i]);
          }
      
        print_r(array_count_values($num_array));
        echo "<br>";
         
        $List = implode('  ', $num_array);
          print_r($List);
              echo "<br>";
       echo substr_count("$List","3");
     
    ?>
    
    
  </body>
  </html>
    
