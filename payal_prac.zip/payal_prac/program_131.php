<!--
131. Write a  Program that accepts two strings and check whether the second string present in the last part of the first string.  
Sample Output:
Input the first string:
abcdef
Input the second string:
ef
Is second string present in the last part of the first string?
Present!


-->
<html>
  <body>
     <form method="post" target="_slef">
        <table>
          <tr>
            <td>
              <label for="str1">Enter The String 1 : </label>
            </td>
            <td>
              <input type="text" id="str1" name="str1">
            </td>
          </tr>
          <tr>
            <td>
              <label for="str2">Enter The String 2 : </label>
            </td>
            <td>
              <input type="text" id="str2" name="str2">
            </td>
          </tr>          
          <tr>
            <td>
              <input type="submit" value="Submit">
            </td>
          </tr>
        </table>
    </form>
    
    <?php
       $str1=$_POST["str1"];
       $str2=$_POST["str2"];
       
        $strlen1=strlen($str1);
        $strlen2=strlen($str2);
        
        echo $str1."<br>";
        echo $str2."<br>";
         $len=$strlen1-$strlen2;
         $str3=substr($str1,$len);
         if($str2==$str3){
           echo "Present!";
           
         }
        
    ?>  
  </body>
</html>