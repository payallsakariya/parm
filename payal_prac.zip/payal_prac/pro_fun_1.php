<html>
  <body>
    <p id="add"></p>
    <p id="sub"></p>
    <p id="mul"></p>
    <p id="div"></p>
    <p id="mod"></p>
    <script>
      function myFunction(p1, p2) {
  return p1 * p2;
}
   document.getElementById("add").innerHTML = myFunction(10,20)
    </script>
  </body>
</html>
