<!--
75. Write a  Program which accepts some text from the user and prints each word of that text in separate line.  
Sample Output:
Input some text:
The quick brown fox jumps over the lazy dog
The
quick
brown
fox
jumps
over
the
lazy
dog
-->
<?php
$str="The quick brown fox jumps over the lazy dog";
$my_strarray=explode(" ",$str);
$lisi=implode("<br>",$my_strarray);
print_r($lisi);

?>