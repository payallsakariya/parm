<html>
  <body>
   <!--
   //<?php
    $k=0;
    //$evenarr=array();
    for($i=1;$i<=4;$i++){
      //echo($i);
      if ($i%2==0) {
        $k++;
       // array_push($evenarr,$i);
        // code...
      }
      print_r($evenarr);
    }
    
    ?>
    -->
    
    
    <?php
      echo("2^2 = ".pow(2,2) . "<br>");
      echo("4^2 =".pow(4,2) . "<br>");
    ?>
  </body>
</html>
