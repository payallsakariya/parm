<?php
   
    echo "Age is :- ".$_POST["age"]."<br><br>";
    
    if(18<=$_POST["age"] and  $_POST["age"]<=30){
      echo " yes";
    }
    else {
      echo "no";
    }
  
    ?>
    
