   <html>
      <body>
        
        <form method='post'>
          <table>
            <tr>
              <td>
                <label for='num'> Enter mathematics marks : </label>
              </td>
              <td>
                <input type='text' id='num' name='num'>
              </td>
            </tr>
            
            <tr>
              <td>
               
              </td>
              <td>
                <br>
                <input type="submit" name="Submit1">
               
              </td>
            </tr>
        
          </table>
        </form>
      </body>
    </html>
    
    
     <?php 
            session_start();
            if(!empty($_SESSION['num_get'])){
              
            }else{
              $_SESSION['num_get'] = array();
            }
            
            // $number=$_POST['num'];
           if($_POST['num']>0){
              array_push($_SESSION['num_get'],$_POST['num']);
              print_r($_SESSION);
           }
           else{
          // / print_r($_SESSION['num_get']);
            // print_r($_SESSION);
            $array_sum=array_sum($_SESSION['num_get']);
            echo "<br>".$array_sum;
             echo "<br>".$count_array=count($_SESSION['num_get']);
            echo "<br>Average marks in Mathematics :".$array_sum/$count_array;
              session_destroy();
             
           }
           
              
               
             
    ?>  