<!-- 9. Write a  Program that accepts an employee's ID, total worked hours of a month and the amount he received per hour. Print                   the employee's ID and salary (with two decimal places) of a particular month.  
        Test Data :
        Input the Employees ID(Max. 10 chars): 0342
        Input the working hrs: 8
        Salary amount/hr: 15000
        Expected Output:
        Employees ID = 0342
        Salary = U$ 120000.00
-->
<html>
  <body>
     <form  id="my" class=".no-copy-paste">
      <table >
        <tr>
          <td>
            <label for="idname">Input the Employees ID(Max. 10 chars):</label>
          </td>
          <td>
    <input type="text" id="idname" name="idname"  max="10" onblur="myfunction()">
          </td>
        </tr>
        <tr>
          <td>
            <label for="hes"> Input the working hrs:</label>
          </td>
          <td>
            <input type="text" id="hes" name="hes" onblur="myfunction()">
          </td>
        </tr>
        
        <tr>
          <td>
            <label for="sal">   Salary amount/hr :</label>
          </td>
          <td>
            <input type="text" id="sal" name="sal" onblur="myfunction()">
          </td>
        </tr>
       </table>
      <p id="demo"></p>
      <p id="demo1"></p>
      <p id="demo2"></p>  
      <p id="demo3"></p> 
    </form>
   
   
  
    <script>
      function myfunction(){
        var num = document.getElementById("idname").value;
        document.getElementById('demo').innerHTML = num;
        
        var h = document.getElementById("hes").value;
        document.getElementById('demo1').innerHTML = h;
        

       var s = document.getElementById("sal").value;0
        document.getElementById('demo2').innerHTML = s;
        
        var us= h*s;
         document.getElementById('demo3').innerHTML = us;
           
      }
      const div = document.getElementById("my");
      div.addEventListener("contextmenu", (e) => {e.preventDefault()});
     
     const h = document.getElementById("my");
      h.addEventListener("copy", (e) => {e.preventDefault()});
     
      // $(if(e.keycode == 91 ){ return false});
    
      const p = document.getElementById("my");
      p.addEventListener("14", (e) => {e.preventDefault()});
      
      const a = document.getElementById("my");
      a.addEventListener("cmd", (e) => {e.preventDefault()});
      
      const h1 = document.getElementById("my");
      hi.addEventListener(51, (e) => {e.preventDefault()});
    </script>
  
</body>
</html>