<html>
  <body>
    <center>
    <table>
   
    
  <?php $d=$_POST["brith"]; 
      $a= date("M m ,Y",$d);
   ?>
   
   <tr>
     <td>
       <label>Name </label>
     </td>
     <td><?php echo ': '.$_POST["fname"]; ?> <br></td>
   </tr>
   
   <td>
       <label>DOB  </label>
     </td>
     <td><?php echo ': ' .$a; ?> <br></td>
   </tr>
   
   <tr>
     <td>
       <label>Mobile   </label>
     </td>
     <td><?php echo ': '.$_POST["phone"]; ?> <br></td>
   </tr>
  
 </table>
  </center>
  </body>
</html>
