<!--
61. Write a  Program that reads in two integers and check whether the first integer is a multiple of the second integer.  
Sample Input: 9 3
Sample Output:
Input the first integer : Input the second integer:
9 is a multiple of 3.

-->

<html>
      <body>
        
        <form method='post'>
          <table>
            <tr>
              <td>
                <label for='number1'> Enter fist number : </label>
              </td>
              <td>
                <input type='text' id='number1' name='number1'>
              </td>
            </tr>
            
             <tr>
              <td>
                <label for='number2'> Enter second number : </label>
              </td>
              <td>
                <input type='text' id='number2' name='number2'>
              </td>
            </tr>
            
            <tr>
              <td>
                <br>
                <input type="submit" name="Submit">
              </td>
            </tr>
          </table>
        </form>
      </body>
    </html>
    
    
    
    <?php
    
      $no1=$_POST['number1'];
      $no2=$_POST['number2'];
     
       if($no2*$no2==$no1){
        // echo $no1;
         
         echo $no1." is a multiple of ".$no2;
       }else {
         echo "no multiple";
       }
       
       
    ?>