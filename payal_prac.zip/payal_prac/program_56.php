<!-- 
56. Write a  Program that prints out the prime numbers between 1 and 200. The output should be such that each row contains a maximum of 20 prime numbers.  
Expected output:
The prime numbers between 1 and 199 are:
2 3 5 7 11 13 17 19 23 29
31 37 41 43 47 53 59 61 67 71

--> 
 
 
 <html>
      <body>
        
        <form method='post'>
          <table>
            <tr>
              <td>
                <label for='no1'> Enter fist number : </label>
              </td>
              <td>
                <input type='text' id='no1' name='no1'>
              </td>
            </tr>
            
             <tr>
              <td>
                <label for='no2'> Enter second number : </label>
              </td>
              <td>
                <input type='text' id='no2' name='no2'>
              </td>
            </tr>
            
            <tr>
              <td></td>
              <td>
                <br>
                <input type="submit" name="Submit1">
              </td>
            </tr>
          </table>
        </form>
      </body>
    </html>
    <?php
    $prim=array();
       $no1=$_POST['no1'];
       $no2=$_POST['no2'];
       
       for($j=$no1;$j<=$no2;$j++){
     
      $flga=0;
      for($i=1;$i<$j;$i++){
          if($j%$i==0){
            $flga++;
         
      }
      
      }
      if($flga==1)
      {
         $array_prim=array_push($prim,$i);
      }
      else {
        // echo "no prim";
      }
     
  }
  $List = implode(',', $prim);
   print_r($List);
  // print_r($prim)
    ?>
    