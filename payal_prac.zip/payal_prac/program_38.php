<html>
  <body>
    <?php 
   // $k=1;
    $sum=0;
     for($i=1;$i<=50;$i++){
       //$sum=$sum+(1/$i)."<br>";
       $sum+=(1/$i)."<br>";
       //echo $sum."<br>";
       // $sum=$sum+$sum;
       
     }
    echo "<br><br><br>".$sum;
    ?>
  </body>
</html>
