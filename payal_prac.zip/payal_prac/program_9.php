<!-- 9. Write a  Program that accepts an employee's ID, total worked hours of a month and the amount he received per hour. Print                   the employee's ID and salary (with two decimal places) of a particular month.  
        Test Data :
        Input the Employees ID(Max. 10 chars): 0342
        Input the working hrs: 8
        Salary amount/hr: 15000
        Expected Output:
        Employees ID = 0342
        Salary = U$ 120000.00
-->
<html>
  <body>
     <form  method="post" target="_top">
      <table>
        <tr>
          <td>
            <label for="idname">Input the Employees ID(Max. 10 chars):</label>
          </td>
          <td>
            <input type="text" id="idname" name="idname"  max="10" >
          </td>
        </tr>
        <tr>
          <td>
            <label for="hes"> Input the working hrs:</label>
          </td>
          <td>
            <input type="time" id="hes" name="hes">
          </td>
        </tr>
        
        <tr>
          <td>
            <label for="sal">   Salary amount/hr :</label>
          </td>
          <td>
            <input type="text" id="sal" name="sal">
          </td>
        </tr>
        
        
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
      </table>
    </form>
    <?php
    
    echo "Employees ID = ".$_POST["idname"];
   $h=$_POST["hes"];
    $s=$_POST["sal"];
    $us=$h*$s;
    echo "<br><br>Salary = U$ ".$us;
    ?>
</body>
</html>