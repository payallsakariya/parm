<!-- 
59. Write a  Program to copy a given string into another and count the number of characters copied.  
Input a string
Original string: w3resource
Number of characters = 10

-->

<?php
$string="w3resource";
$string1=strlen("w3resource");

echo "Original string :  ".$string;
echo "<br><br>Number of characters =".$string1;
?>
