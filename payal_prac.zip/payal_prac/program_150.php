<?php
$a=array(6,4,3,7,1);
$temp=0;
for($i=0;$i<5;$i++){
  for($j=$i+1;$j<5;$j++){
    if($a[$i]<$a[$j]){
      $temp=$a[$i];
      $a[$i]=$a[$j];
      $a[$j]=$temp;
    }
  }
  // print_r($a);
  echo "<br>";
}
print_r($a);

?>
