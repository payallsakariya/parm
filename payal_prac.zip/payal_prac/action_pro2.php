<html>
  <body>
  <?php

   $x=$_POST["no1"]."<br>";
   $y=$_POST["no2"];
    $sum=$x+$y;
    $ans= $sum * $sum;
    ?>
    <tr>
      <td><?php echo "<br>Sum is :-"; ?></td>
      <td><?php  echo $sum; ?></td>
    </tr>
    
     <tr>
      <td><?php echo "<br>squares :-"; ?></td>
      <td><?php echo $ans; ?></td>
    </tr>
  
  
 
  
  </body>
</html>