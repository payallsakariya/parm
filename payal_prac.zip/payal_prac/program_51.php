<!--
51. Write a  Program that accepts 4 real numbers from the keyboard and print out the difference of the maximum and minimum values of these four numbers.  
Input four numbers: 1.54 1.236 1.3625 1.002
Difference is 0.5380


-->


 <html>
    <body>
      <form method='post'>
        <table>
          <tr>
            <td>
              <label for='num'> Enter 5 numbers of array value : </label>
            </td>
            <td>
             <input type='text' id='num' name='no1'>
             </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <input type='text' id='num' name='no2'>
            </td>
          </tr>
          
          <tr>
            <td></td>
            <td>
              <input type='text' id='num' name='no3'>
            </td>
          </tr>
          
          <tr>
            <td></td>
            <td>
              <input type='text' id='num' name='no4'>
            </td>
          </tr>

        <tr>
          <td>
            <input type='submit' name='Submit'>
          </td>
        </tr>
        
        
        </table>
      </form>
    </body>
  </html>
<?php
  
        $number1=$_POST['no1'];
        $number2=$_POST['no2'];
        $number3=$_POST['no3'];
        $number4=$_POST['no4'];
        
        
        $number_array=array($number1,$number2,$number3,$number4);
        
      // echo "<br>".$min_array=min($number_array);
      
       print($min_array=min($number_array));
       
      echo "<br>".$max_array=max($number_array);
      echo "<br>Difference is : ".($max_array-$min_array);

?>

