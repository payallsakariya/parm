<html>
  <body>
    <form method='post'>
      <label for='num'> Enter Number : </label>
      <input type='text' id='num' name='num'>
      <input type='submit' name='Submit'>
    </form>
    <?php
    $number=$_POST['num'];
    $len=strlen($number);
    // echo $len."<br>";

    $b=array();
    $a=array();
    // print_r($a);
    for($i=0;$i<$len;$i++){
       array_push($b,$number[$i]);
    }
    // print_r($b);
    // echo "<br>";
 
    for($i=0;$i<$len;$i++){
       array_push($a,$number[$i]);
    }
    
          for($i=0;$i<$len;$i++){
            for($j=$i+1;$j<$len;$j++){
              if($a[$i]>$a[$j]){
                $temp=$a[$i];
                $a[$i]=$a[$j];
                $a[$j]=$temp;
              }
            }
          }
         
              
    for($i=0;$i<$len;$i++){
      for($j=$i+1;$j<$len;$j++){
            
           if($b[$i]<$b[$j]){
            // echo "hi";
              $k=$b[$i];
              $b[$i]=$b[$j];
              $b[$j]=$k;
            }
            
        }
    }
    // print_r($a);
    //   echo "<br>";
    // print_r($b);
    
     $min=implode("",$a);
    // echo "<br>".$min;
     
     $max=implode("",$b);
    // echo "<br>".$max;
    $mid=$max-$min;
  echo "The difference between the largest integer and the smallest integer : ".$max."-".$min."=".$mid;
    
    ?>
  </body>
</html>