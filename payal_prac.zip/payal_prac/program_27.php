<!-- 
27. Write a  Program that accepts some integers from the user and find the highest value and the input position.  
Test Data :
Input 5 integers:
5
7
15
23
45
Expected Output:
Highest value: 45
Position: 5


-->

<html>
  <body>
     <form  method="post">
      <table>
        <tr>
          <td>
            <label for="no">enter 5 integer number : </label>
          </td>
          <td>
            <input type="text" id="no" name="no1">
          </td>
        </tr>
        <tr>
          <td></td>
           <td>
            <input type="text" id="no2" name="no2">
          </td>
        </tr>
        <tr>
          <td></td>
          <td>
            <input type="text" id="no2" name="no3">
          </td>
        </tr>
         <tr>
          <td></td>
          <td>
            <input type="text" id="no2" name="no4">
          </td>
        </tr>
        
         <tr>
          <td></td>
          <td>
            <input type="text" id="no2" name="no5">
          </td>
        </tr>
        
         <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
        
      </table>
    </form>
    <?php 
      echo "Maximum value of five integers : ".max($_POST["no1"],$_POST["no2"],$_POST["no3"],$_POST["no4"],$_POST["no5"]);
      echo "<br>Minimum value of five integers : ".min($_POST["no1"],$_POST["no2"],$_POST["no3"],$_POST["no4"],$_POST["no5"]);
    ?>
  </body>
</html>
