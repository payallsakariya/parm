<!--
26. Write a  Program to print all numbers between 1 to 100 which divided by a specified number and the remainder will be 3.  
Test Data :
Input an integer: 25
Expected Output:
3
28
53
78

-->

<html>
  <body>
    <form method="post">
      <label for="no1"> Enter value </label>
      <input type="text" id='no1' name='no1'>
      <br><br>
      <input type="submit" name="Submit">
    </form>
             
      <?php 
        $no=$_POST['no1'];
        $num_array=array();
        for($i=1;$i<=100;$i++){
          if($i%$no==3){
            array_push($num_array,$i);
            
          }
        }
        $list=implode(',',$num_array);
        print_r($list);
        ?>
  </body>
  </html>