<html>
  <body>
    <head>
      
    </head>
    <body>
      <h1> My first php pag</h1>
      <?php
      
      $text="hello";
      $a=5;
      $b=2.3;
      
          print  var_dump($a)."<br>";
         print  var_dump($b)."<br>";
         print  var_dump($text)."<br>";
           echo "<br>hello world";
           echo "<br>";
           echo $text;
           echo"<br>";
           echo  "<h2> value A:- ".$a."<h2><br>";
           print "<h1> value B:-".$b."<h1><br>";
           
          
          
          function myTest()
          {
          static  $x=0;
            global $a,$b; 
            $b =$a+$b;
            echo $x;
            $x++;
           # echo "<p> valu of A:-$a</p>";
          }


      /*  myTest();
          {
            echo "<p> valu of A:-$b </p>";
          }*/
          
           echo"<br>";
           myTest();
           echo "<br>";
           myTest();
           echo "<br>";
           myTest();
           print "<br>";
           
           
           
           
           #ARRAY 
           $cars = array(BMW,Toyota,Volvo);
           var_dump($cars)
      ?>
    </body>
  </body>
</html>
