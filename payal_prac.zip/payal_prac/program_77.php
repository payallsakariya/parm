<!--
77. Write a  Program to convert a currency value (floating point with two decimal places) to the possible number of notes and coins.  
Sample Output:
Input the currency value (floating point with two decimal places):
10357.75

Currency Notes:
100 number of Note(s): 103
50 number of Note(s): 1
5 number of Note(s): 1
2 number of Note(s): 1

Currency Coins:
.50 number of Coin(s): 1
.25 number of Coin(s): 1

-->


<html>
  <body>
    <form method="post" target="_slef">
        <table>
          <tr>
            <td>
              <label for="amout1">Enter The Amount: </label>
            </td>
            <td>
              <input type="text" id="amout1" name="amout1">
            </td>
          </tr>
          <tr>
            <td>
              <input type="submit" value="Submit">
            </td>
          </tr>
        </table>
    </form>
    
    <?php
      
      $amuot=$_POST["amout1"];
    
      $note100=0;
      $note50=0;
      $note20=0;
      $note10=0;
      $note2=0;
      $note1=0;
   
     if($amuot>=100){
       $note100=$amuot/100;
       
       $amuot=$amuot%100;
     }
          $note_100=floor($note100);
         echo "<br> 100.00 number of Note(s) : ".$note_100;
         
       if($amuot>=50){
           $note50=$amuot/50;
           $amuot=$amuot%50;
         }
              $note_50=floor($note50);
             echo "<br> 50.00 number of Note(s) : ".$note_50;   
    
     if($amuot>=20){
          $note20=$amuot/20;
          $amuot=$amuot%20;
         }
              $note_20=floor($note20);
             echo "<br> 20.00 number of Note(s) : ".$note_20;   
    
    
     if($amuot>=10){
         $note10=$amuot/10;
         $amuot=$amuot%10;
         }
              $note_10=floor($note10);
             echo "<br> 10.00 number of  Note(s) : ".$note_10;   
    
    
     if($amuot>=5){
       $note5=$amuot/5;
        $amuot=$amuot%5;
         }
               $note_5=floor($note5);
             echo "<br> 05.00 number of Note(s) : ".$note_5;   
    
    
     if($amuot>=2){
       $note2=$amuot/2;
         $amuot=$amuot%2;
         } 
               $note_2=floor($note2);
             echo "<br> 02.00 number of Note(s) : ".$note_2;   
      if($amuot>=1){
        $note1=$amuot/1;
         $amuot=$amuot%1;
         }
              $note_1=floor($note1);
             echo "<br> 01.00 number of Note(s) : ".$note_1;  
             
       $sum=(($note_100*100)+($note_50*50)+($note_20*20)+($note_10*10)+($note_5*5                )+($note_2*2)+($note_1*1));  
          echo "<br>".$sum."<br>";
    
    
       $amuot=$_POST["amout1"];
       $coin_sum=$amuot-$sum;
       $coin_sum;
       $coin_50=0;
       $coin_25=0;
       
       while($coin_sum>0.00){
         if($coin_sum>0.50){
           $coin_sum-= 0.50;
          $coin_50++;
         }else{
            $coin_sum-= 0.25;
            $coin_25++;
          }
        }
  
          echo"<br>.50 number of Coin(s) : " .$coin_50;
      
          echo "<br>.25 number of Coin(s) : ".$coin_25;
             
       
    ?>
