<!--

44. Write a  Program to read an array of length 6, change the first element by the last, the second element by the fifth and the third element by the fourth. Print the elements of the modified array.  
Test Data:
Input the 5 members of the array:
15
20
25
30
35
 
Expected Output:
array_n[0] = 35
array_n[1] = 30
array_n[2] = 25
array_n[3] = 20
array_n[4] = 15
 

-->
 <html>
    <body>
      <form method='post'>
        <table>
          <tr>
            <td>
              <label for='num'> Enter 5 numbers of array value : </label>
            </td>
            <td>
             <input type='text' id='num' name='no1'>
             </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <input type='text' id='num' name='no2'>
            </td>
          </tr>
          
          <tr>
            <td></td>
            <td>
              <input type='text' id='num' name='no3'>
            </td>
          </tr>
          
          <tr>
            <td></td>
            <td>
              <input type='text' id='num' name='no4'>
            </td>
          </tr>
          
          <tr>
            <td></td>
            <td>
              <input type='text' id='num' name='no5'>
            </td>
          </tr>
          
        <tr>
          <td>
            <input type='submit' name='Submit'>
          </td>
        </tr>
        
        
        </table>
      </form>
    </body>
  </html>
  <?php
       
         $number1=$_POST['no1'];
        $number2=$_POST['no2'];
        $number3=$_POST['no3'];
        $number4=$_POST['no4'];
       $number5=$_POST['no5'];
       
        $number_array=array($number1,$number2,$number3,$number4,$number5);
        $count=count($number_array);
         $no=$count;
        // $ans_array=array_replace($number_array);
      $ans=array_reverse($number_array);
      $list=implode(',',$ans);
      
         for($i=0;$i<$no;$i++){
          
           echo "<br>A[$i] =".$ans[$i];
          
        }
        
  ?>


