<!--
50. Write a  Program to reverse and print a given number.  
Input a number:
The original number = 234
The reverse of the said number = 432

-->


<html>
  <body>
    <form method='post'>
      <label for='num'> Enter Number : </label>
      <input type='text' id='num' name='num'>
      <input type='submit' name='Submit'>
    </form>
  </body>
</html>

<?php
  
  echo $_POST['num'];
  echo "<br>".strrev($_POST['num']);



?>
