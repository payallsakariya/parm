<form method="post">  
Enter a Number: <input type="text" name="input"><br><br>  
<input type="submit" name="submit" value="Submit">  
</form>  
<?php  
if($_POST)  
{  
    $input=$_POST['input'];  
    for ($i = 2; $i <= $input-1; $i++) {  
      if ($input % $i == 0) {  
        echo "hi";
      $value= True;  
      }  
}  
if (isset($value) && $value) {  
     echo 'The Number '. $input . ' is not prime';  
}  else {  
   echo 'The Number '. $input . ' is prime';  
   }   
}  
?>  





<!-- $flga=0;
      for($i=1;$i<$no1;$i++){
          if($no1%$i==0){
            $flga++;
          // return 1;
      }
      
      }
      if($flga==1)
      {
        echo "prim".$i;
      }
      else {
        echo "no prim";
      }-->