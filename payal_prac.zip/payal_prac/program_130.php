<!--

130. Write a  Program to create an array of length n and fill the array elements with integer values. Now find the smallest value and it’s position within the array.  
Sample Output:
Input a number:
35

Array elements:
array_nums[0] = 35.0000
array_nums[1] = 11.6667
array_nums[2] = 3.8889
array_nums[3] = 1.2963
array_nums[4] = 0.4321
array_nums[5] = 0.1440
array_nums[6] = 0.0480
array_nums[7] = 0.0160
array_nums[8] = 0.0053
array_nums[9] = 0.0018


-->
<html>
  <body>
    <form method='post'>
      <label for='num'> Enter Number : </label>
      <input type='text' id='num' name='num'>
      <input type='submit' name='Submit'>
    </form>
    <?php
       $number=$_POST['num'];
       session_start();
       if(!empty($_SESSION['get_num'])){
         
       }else
       {
         $_SESSION['get_num']=array();
       }
       
       if ($_POST['num']!=000){
       array_push($_SESSION['get_num'],$_POST['num']);
        
         
       }else{
       $count=count($_SESSION['get_num']);
 $a=array();
       for($i=0;$i<$count;$i++){
        // echo intval($_SESSION['get_num'][$i]) . "<br>";
             array_push($a,intval($_SESSION['get_num'][$i]));
       }
      // $max=max($a);
      // echo $max;
       
       for($j=0;$j<$count;$j++){
         if($a[0]<$a[$j]){
           $temp=$a[0];
           $a[0]=$a[$j];
           $a[$j]=$temp;
         }
         
       }
       echo "<br>max value is".$a[0];
          session_destroy();
     }
       
    ?>
</body>
</html>
