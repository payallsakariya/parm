<!--
11. Write a  Program to read an amount (integer value) and break the amount into the smallest possible number of bank notes.  
Test Data:
Input the amount: 375
Expected Output:
There are:
3 Note(s) of 100.00
1 Note(s) of 50.00
1 Note(s) of 20.00
0 Note(s) of 10.00
1 Note(s) of 5.00
0 Note(s) of 2.00
0 Note(s) of 1.00

-->
<html>
  <body>
    <form method="post" target="_slef">
        <table>
          <tr>
            <td>
              <label for="amout1">Enter The Amount: </label>
            </td>
            <td>
              <input type="text" id="amout1" name="amout1">
            </td>
          </tr>
          <tr>
            <td>
              <input type="submit" value="Submit">
            </td>
          </tr>
        </table>
    </form>
    
    <?php 
    $amot=$_POST["amout1"];
    $note100=0;
    $note50=0;
    $note20=0;
    $note10=0;
    $note05=0;
    $note02=0;
    $note01=0;
    while($amot>=100) {
            $amot=$amot-100;
            $note100++;
             
          } 
        
      echo "<br>".$note100  ."  Note(s) of 100.00<br>"; 
    
      while($amot>=50) {
            $amot=$amot-50;
            $note50++;
            
          } 
         echo "<br>".$note50  ."   Note(s) of 50.00<br>"; 
            
          
    while($amot>=20) {
            $amot=$amot-20;
            $note20++;
            
          } 
         echo "<br>".$note20 ."   Note(s) of 20.00<br>"; 
         
     while($amot>=10) {
            $amot=$amot-10;
            $note10++;
            
          } 
         echo "<br>".$note10. "   Note(s) of 10.00<br>"; 
         
         
         
   while($amot>=5) {
            $amot=$amot-5;
            $note05++;
            
          } 
         echo "<br>".$note05  ."   Note(s) of 5.00<br>"; 
         
         
         
   while($amot>=2) {
            $amot=$amot-2;
            $note02++;
            
          } 
         echo "<br>".$note02  ."   Note(s) of 2.00<br>"; 
         
         
   while($amot>=1) {
            $amot=$amot-1;
            $note01++;
            
          } 
         echo "<br>".$note01  ."   Note(s) of 1.00<br>"; 
                                   
         
         
      
    ?>
  </body>
</html>
