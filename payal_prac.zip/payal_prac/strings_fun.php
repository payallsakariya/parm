<html>
  <style>
        table, tr,td {border: 2px solid black;  }
        h2,form{font:center;}
    </style>
  <body>
   <center> <h2>String Function</h2></center><br><br>
    <form method="post">
      <table>
         <?php
              $str="hello wlord";
              $x =223.3
         ?>
        <tr>
          <td>
            <label>Strlen Function :- </label>
          </td>
          <td>
            <label><?php echo strlen($str); ?></label>
          </td>
        </tr>
        <tr>
          <td>
            <label>tr_word_count function :- </label>
          </td>
          <td>
            <label><?php echo str_word_count($str); ?></label>
          </td>
        </tr>
        <tr>
          <td>
            <label>str_srtrev function :- </label>
          </td>
          <td>
            <label><?php echo strrev($str); ?></label>
          </td>
        </tr>
        <tr>
          <td>
            <label>strpos function :-</label>
          </td>
          <td>
            <label><?php echo strpos($str,'wlord'); ?></label>
          </td>
        </tr>
        <tr>
          <td>
            <label>str_replace function:-</label>
          </td>
          <td>
            <lable><?php echo str_replace('hello','helloooo',$str); ?></lable>
          </td>
        </tr>
        <tr>
          <td>
            <label>addcslashes fun :-</label>
          </td>
          <td><?php echo addcslashes($str,'w'); ?></td>
        </tr>
        <tr>
          <td>
            <label>addcslashes A..Z fun :-</label>
          </td>
          <td>
            <label><?php echo addcslashes($str,'a..z'); ?></label>
          </td>
        </tr>
        
        <tr>
          <td>
            <label> chop fun :-</label>
          </td>
          <td>
            <label><?php echo chop($str,'world'); ?></label>
          </td>
        </tr>
        
         <tr>
          <td>
            <label> chunk_split fun :-</label>
          </td>
          <td>
            <label><?php echo chunk_split($str,1,".");?></label>
          </td>
        </tr>
        
        <tr>
          <td>
            <label> Strtolower fun :-</label>
          </td>
          <td>
            <label><?php echo strtolower("Hello WORLD.");?></label>
          </td>
        </tr>
        
        
        <tr>
          <td>
            <label> substr fun :-</label>
          </td>
          <td>
            <label><?php echo substr("Hello world",6);?></label>
          </td>
        </tr>
        <tr>
          <td>
            <label> substr fun :-</label>
          </td>
          <td>
            <label><?php echo substr("Hello world",0,5);?></label>
          </td>
        </tr>
        
        <tr><td>this numeric function</td></tr>
        
         <tr>
          <td>
            <label> is_int fun :-</label>
          </td>
          <td>
            <label><?php echo var_dump(is_float($x));?></label>
          </td>
        </tr>
        
        <tr>
          <td>
            <label> is_numeric fun :-</label>
          </td>
          <td>
            <label><?php echo var_dump(is_numeric($str));?></label>
          </td>
        </tr>
        
        <tr>
          <td>
            <label> $int_cast fun :-</label>
          </td>
          <td>
            <label><?php echo $int_cast = (int)$x;?></label>
          </td>
        </tr>
        
        <tr>
          <td>
            <label >this is math fun</label>
          </td>
        </tr>
        
        <tr>
          <td>
            <label> PI fun :-</label>
          </td>
          <td>
            <label><?php echo (pi());?></label>
          </td>
        </tr>
        
        
        <tr>
          <td>
            <label> min fun :-</label>
          </td>
          <td>
            <label><?php echo (min(0, 150, 30, 20, -8, -200));?></label>
          </td>
        </tr>
        
        <tr>
          <td>
            <label> max fun :-</label>
          </td>
          <td>
            <label><?php echo (max(0, 150, 30, 20, -8, -200));?></label>
          </td>
        </tr>
        
        
        <tr>
          <td>
            <label> abs fun :-</label>
          </td>
          <td>
            <label><?php echo (abs(-200.9));?></label>
          </td>
        </tr>
        
        
        <tr>
          <td>
            <label> sqrt fun :-</label>
          </td>
          <td>
            <label><?php echo (sqrt(64));?></label>
          </td>
        </tr>
        
        <tr>
          <td>
            <label> rand fun :-</label>
          </td>
          <td>
            <label><?php echo (rand());?></label>
          </td>
        </tr>
        
        
        <tr>
          <td>
            <label> rand fun :-</label>
          </td>
          <td>
            <label><?php echo (rand(10,100));?></label>
          </td>
        </tr>
        
        
        
      </table>
      
    </form>
    
 
    
    
<?php
$age=array("Peter"=>"35");
print "Peter is " . $age['Peter'] . " years old.<br>";
echo "Peter is " . $age['Peter'] . " years old.<br><br>";


define("cars", [
             "Alfa Romeo",
             "BMW",
             "Toyota"
              ],true);
      echo cars[1];
?>
    
    
  </body>
</html>

