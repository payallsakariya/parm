<!-- 12. Write a  Program to convert a given integer (in seconds) to hours, minutes and seconds.  
          Test Data :
          Input seconds: 25300
          Expected Output:
          There are:
          H:M:S - 7:1:40
-->

<html>
  <body>
    <form>
      <table>
        <tr>
          <td>
            <label for="no_second">Enter Seconds</label>
          </td>
          <td>
        <input type="text" id="no_second" name="no_second" onblur="myfunction()">
          </td>
        </tr>
      </table>
      <p id="demo"></p>
       <p id="demo1"></p>
    </form>
    <script>
      function myfunction(){
        var Seconds=document.getElementById('no_second').value;
        document.getElementById('demo').innerHTML=Seconds;
        
    
         let munits=parseInt(mu=(Seconds/60)); 
        var hours=parseInt(hours=munits/60);
        var second2=munits*60;
        var munits1=parseInt(hours*60);
        var F_munits=munits-munits1;
          
          var F_second=Seconds-second2;
          // document.getElementById('demo1').innerHTML=munits;
          document.getElementById('demo1').innerHTML="H:M:S -" + hours + ":" +                        F_munits + ":" +F_second;
      }
    </script>
  </body>
</html>
