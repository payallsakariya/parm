<!-- 12. Write a  Program to convert a given integer (in seconds) to hours, minutes and seconds.  
          Test Data :
          Input seconds: 25300
          Expected Output:
          There are:
          H:M:S - 7:1:40
-->

<html>
  <body>
    <form method="post" target="_top">
      <table>
        <tr>
          <td>
            <label for="no_second">Enter Seconds</label>
          </td>
          <td>
            <input type="text" id="no_second" name="no_second">
          </td>
        </tr>
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
      </table>
    </form>
    
    <?php
         $second=$_POST["no_second"];
        $munits=floor($munits=$second/60); 
        $hours=floor($hours=$munits/60);
        $second2=$munits*60;
        $munits1=floor($hours*60);
        //echo $munits1;
        $F_munits=$munits-$munits1;
          
          $F_second=$second-$second2;
        echo "H:M:S -". $hours.':'. $F_munits.':'.$F_second;
        
    ?>
  </body>
</html>
