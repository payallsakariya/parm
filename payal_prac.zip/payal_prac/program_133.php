<!--
133. Write a  Program to calculate the sum of two given integers and count the number of digits of the sum value.  
Sample Output:
Input two integer values:
68
75

Number of digits of the sum value of the said numbers:

-->

<html>
  <body>
    <form method="post">
      <table>
        <tr>
          <td>
            <label for="num1">enter number 1</label>
          </td>
          <td>
            <input type="text" id="num1" name="num1">
          </td>
        </tr>
        
         <tr>
          <td>
            <label for="num2">enter number 2</label>
          </td>
          <td>
            <input type="text" id="num2" name="num2">
          </td>
        </tr>
        
        <tr>
          <td>
            <input type="submit" name="Submit">
          </td>
        </tr>
      </table>
    </form>
    
    <?php
     
       $num1=$_POST['num1'];
       $num2=$_POST['num2'];
       $sum=$num1+$num2;
       $count=0;
       for($i=1;$i<=$sum;$i++){
         $count=$i;
       }
       echo "sum of digits".$count;
echo "<br>Number of digits of the sum value of the said numbers : ".strlen($sum);
    ?>
</body>
</html>
