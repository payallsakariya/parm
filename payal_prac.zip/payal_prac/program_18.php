<!--18. Write a  Program that reads two integers and checks whether they are multiplied or not.  
Test Data :
Input the first number: 5
Input the second number: 15
Expected Output:
Multiplied!
 -->



<html>
  <body>
    <form method="post" target="_top">
      <body>
        <table>
          <tr>
            <td>
              <label for="f_numbre">Enter the first number : </label>
            </td>
            <td>
              <input type="text" id="f_numbre" name="f_numbre">
            </td>
          </tr>
          <tr>
            <td>
              <label for="s_numbre">the second number : </label>
            </td>
            <td>
              <input type="text" id="s_numbre" name="s_numbre">
            </td>
          </tr>
          <tr>
            <td>
              <input type="submit" value="Sumbit">
            </td>
          </tr>
        </table>
      </body>
    </form>
    
    <?php 
          $f_number= $_POST["f_numbre"];
          $s_numbre= $_POST["s_numbre"];
          for($x=1;$x<=10;$x++){
            //echo($x);
            if($x*$f_number == $s_numbre){
              echo("Multiplied!");
            }
           
          }
      
    ?>
  </body>
</html>
