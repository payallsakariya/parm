<!--
60. Write a  Program to remove any negative sign in front of a number.  
Input a value (negative):
Original value = -253
Absolute value = 253

-->

<?php
  $number=-153;
  $absolute=abs($number);
  echo "Original value =".$number;
  echo "<br>Absolute value = ".$absolute;
  
?>