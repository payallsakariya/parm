
<!DOCTYPE html>
<html>
    <head>
        <title> Form </title>
    </head>
    <style>
        table, tr,td {border: 2px solid black;  }
    </style>
    
    <body>
       <center><h2>From</h2></center> <br><br>

        <form action="#" method="post">
            <center>
            <table style="border: 1px solid width 200,height 200">
                <tr>
                    <td>
                        <label for="iname">Id : </label>
                    </td>
                    <td>
                      <input type="text" id="iname" name="iname" pattern="[0-9]{3}" required>
                    </td>
                </tr>  
                <tr>
                    <td>  
                       <label for="fname">First Name : </label>
                    </td>
                    <td>
                        <input type="text" id="fname" name="fname" placeholder="enter first name" required>
                    </td>
                </tr>
                <tr>
                    <td>      
                       <label for="lname">Last Name : </label>
                     </td>
                     <td>
                        <input type="text" id="lname" name="lname" placeholder="enter last name" required>
                     </td>
                </tr>
                <tr>
                    <td>      
                       <label for="phone">Phone number : </label>
                    </td>
                    <td>
                        <input type="tel" id="phone" name="phone" placeholder="9872635467" pattern="[0-9]{10}" required >
                    </td>
                </tr>
                   <td>      
                      <label for="email">Email</label>
                   </td>
                   <td>
                    <input type="email" id="email" name="email"  required >
                   </td>
                </tr>                  
                <tr>
                    <td>
                        <label for="gender">  Gender : </label>
                    </td>
                    <td>  
                        <input type="radio" id="male" name="gender" value="MALE" required>
                        <label for="male">Male</label>
                        <input type="radio" id="female" name="gender" value="FEMALE">
                        <label for="female">Female</label>    
                        <input type="radio" id="other" name="gender" value="OTHER">
                       <label for="other">Other</label>
                    </td>
                </tr>   
                <tr>
                    <td>
                       <label>Course : </label>
                    </td>
                    <td>   
                       <input type="checkbox" id="c++" name="course1" checked>
                       <label for="c++"> C++</label>
                       <input type="checkbox" id="javascrept" name="course2" >
                        <label for="javascrept">JavaScrept</label>  
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="blood">Blood group : </label>
                    </td>
                    <td>    
                        <select id="blood" name="blood" >
                            <option value="select">Select</option>
                            <option value="o+">O+</option>
                            <option value="ab">AB</option>
                        </select>
                    </td>
                </tr>    
                <tr>
                    <td>
                        <label for="brith">BrithDay : </label>
                    </td>
                    <td>    
                        <input type="date" id="brith" name="brith" min="2020-01-02" max="2021-01-01">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>du_date:</label>
                    </td>
                    <td>
                        <input type="date" id="d1" name="a_date1" value="date1">
                        <input type="date" id="d2" name="a_date2" value="date2">
                    </td>
                </tr>
            
                
                <tr>
                    <td>
                        <input type="submit" value="Submit">
                        
                    </td>
                </tr>
            
            </table>
            </center>
            <br>
           
            
 
    <center> 
 <table>
   <center>
    <h2>my info</h2><br>
   <tr>
     <td>
       <label>My Id Is:- </label>
     </td>
     <td><?php echo $_POST["iname"]; ?> <br></td>
   </tr>
   
   <tr>
     <td>
       <label>My FirstName Is:- </label>
     </td>
     <td><?php echo $_POST["fname"]; ?> <br></td>
   </tr>
   
   <tr>
     <td>
       <label>My LastName Is:- </label>
     </td>
     <td><?php echo $_POST["lname"]; ?> <br></td>
   </tr>
   
   <tr>
     <td>
       <label>My Phone Number Is:- </label>
     </td>
     <td><?php echo $_POST["phone"]; ?> <br></td>
   </tr>
   
   <tr>
     <td>
       <label>My EmailId Is:- </label>
     </td>
     <td><?php echo $_POST["email"]; ?> <br></td>
   </tr>
   
   <tr>
     <td>
       <label>My Gender:- </label>
     </td>
     <td><?php echo $_POST["gender"]; ?> <br></td>
   </tr>
   
   <tr>
     <td>
       <label>My Course Is:- </label>
     </td>
     <td style="border-style :hidder"><?php echo $_POST["course1"]; ?> </td>
     <td><?php echo $_POST["course2"]; ?> </td>
   </tr>

 <tr>
     <td>
       <label>My Blood Group Is:- </label>
     </td>
     <td><?php echo $_POST["blood"]; ?> <br></td>
   </tr>
   
    <tr>
     <td>
       <label>My BirthDay Is:- </label>
     </td>
     <td><?php echo $_POST["brith"]; ?> <br></td>
   </tr>
   <tr>
     <td>
       <label>My During Date Is:- </label>
     </td>
     <td><?php echo $_POST["a_date1"]; ?> <br></td>
     <td><?php echo $_POST["a_date2"]; ?> <br></td>
   </tr>
 </table>
 
 
 
 
 
 
 
 
 
 </form>
 </center>
 
    </body>
</html>