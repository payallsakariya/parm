<html>
  <body>
 
    <label>percent</label>
    <input type="text" id="num" name="num" onblur="myfunction()">
    <br>
    <table>
      <tr>
        <td>
          <label for="num1">percent_1</label>
        </td>
        <td>
         <input type="text"id="num1" name="num1" onblur="myfunction()"> 
        </td>
      </tr>
      <tr>
        <td>
          <label for="num2">percent_2</label>
        </td>
        <td>
          <input type="text" id="num2" name="num2" onblur="myfunction()">
        </td>
      </tr>
      <tr>
        <td>
          <label for="num3">percent_3</label>
        </td>
        <td>
         <input type="text" id="num3" name="num3"onblur="myfunction()"> 
        </td>
      </tr>
    </table>
  
    <p id="demo"></p>
    <p id="demo1"></p>
    <p id="demo2"></p>
    <p id="demo3"></p>
    <p id="demo4"></p>
    
  </body>
  <script>
    function myfunction(){
      // alert("hi");
      var per=document.getElementById('num').value;
      document.getElementById('demo').innerHTML=per;
    //   var per1=document.getElementById('num1').value;
    //   document.getElementById('demo1').innerHTML=per1;
    // var per2=document.getElementById('num2').value;
    //   document.getElementById('demo2').innerHTML=per2;
    //   var per3=document.getElementById('num3').value;
    //   document.getElementById('demo3').innerHTML=per3;
    //   // console.log();
      
    //   var a=parseInt(per1)+parseInt(per2)+parseInt(per3);
    //   // document.getElementById('demo4').innerHTML=a;
    //   var text="";
    //   if(per<a){
    //     text="Wrong values";
    //   }else{
    //     text ="right values";
    //   }
    //   document.getElementById('demo4').innerHTML=text;
    
    
    
      }
  
  </script>
</html>