<!-- 22. Write a  Program that read 5 numbers and counts the number of positive numbers and print the average of all positive values.  
            Test Data :
            Input the first number: 5
            Input the second number: 8
            Input the third number: 10
            Input the fourth number: -5
            Input the fifth number: 25
            Expected Output:
            Number of positive numbers: 4
            Average value of the said positive numbers: 12.00
-->


<html>
  <body>
    <form method="post" target="_top">
      <table>
        <tr>
          <td>
            <label for="first_no">Enter the first number :</label>
          </td>
          <td>
            <input type="text" id="first_no" name="first_no">
          </td>
        </tr>
        
        <tr>
        <td>
            <label for="second_no">Enter the second number :</label>
          </td>
          <td>
            <input type="text" id="second_no" name="second_no">
          </td>
        </tr>
        
        <tr>
         <td>
            <label for="third_no">Enter the third number :</label>
          </td>
          <td>
            <input type="text" id="third_no" name="third_no">
          </td>
        </tr>
         
         <tr>
         <td>
            <label for="fourth_no">Enter the fourth number :</label>
          </td>
          <td>
            <input type="text" id="fourth_no" name="fourth_no">
          </td>
        </tr>

         <tr>
         <td>
            <label for="fifth_no">Enter the  fifth number :</label>
          </td>
          <td>
            <input type="text" id="fifth_no" name="fifth_no">
          </td>
        </tr>
        
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
      </table>
    </form>
    
    <?php 
    
       $first_no = $_POST["first_no"];
       $second_no = $_POST["second_no"];
       $third_no = $_POST["third_no"];
       $fourth_no = $_POST["fourth_no"];
       $fifth_no = $_POST["fifth_no"];
       $number=array($first_no,$second_no,$third_no,$fourth_no,$fifth_no);
       $positive=array();
       $negative=array();
      
       $count=count($number);
      $i=0;
      $j++;
      for($x=0;$x<$count;$x++){
      
        if($number[$x]>0){
          array_push($positive,$number[$x]);
          //$i++;
          }
        else {
          array_push($negative,$number[$x]);
          // $j++;
        }
      }
     $positive_no=count($positive);
     //echo("Number of positive numbers : ".$positive_no);
     
     $negatives_no=count($negative);
     //echo("<br> Number of positive numbers : ".$negatives_no);  
     // echo "<br>";
     $p_sum = array_sum($positive);
      
      $Average=$p_sum/$positive_no;
      echo "Average value of the said positive numbers : ".$Average;
      
        ?>
    
  </body>
</html>


