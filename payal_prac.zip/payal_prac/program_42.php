<!-- 
42. Write a  Program to read and print the elements of an array of length 7, before print, put the triple of the previous position starting from the second pos                                                                                                         ition of the array.  
For example, if the first number is 2, the array numbers must be 2, 6, 18, 54 and 162
Test Data:
Input the first number of the array: 5
Expected Output:
n[0] = 5
n[1] = 15
n[2] = 45
n[3] = 135
n[4] = 405

-->
<html>
  <body>
     <form method='post'>
          <label for='num'> Enter Number : </label>
          <input type='text' id='num' name='num'>
          <input type='submit' name='Submit'>
     </form>
     <?php
           
          $number = $_POST["num"];
          echo "<br> n[0] =".$number;
          //echo $number;
          $j=$number;
          for($i=1;$i<$number;$i++){
              // echo "<br> n[$i] =".$number;
               
               if($number>0){
                 $j=$j*3;
                echo "<br> n[$i] =".$j;
               }
               
          }
          
     
     ?>
  </body>
</html>
