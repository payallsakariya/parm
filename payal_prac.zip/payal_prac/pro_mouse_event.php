<html>
  <body>
    <p id="demo" onmousedown="mouseDown()" onmouseup="mouseUp()">mouse over me</p>
    
    <script>
    document.getElementById("demo").onmouseenter = function() {mouseEnter()};
    document.getElementById("demo").onmouseleave = function() {mouseLeave()};
    function mouseEnter() {
          document.getElementById("demo").style.color = "red";
        }
        
        function mouseLeave() {
          document.getElementById("demo").style.color = "black";
        }
    
        function mouseDown() {
          document.getElementById("demo").innerHTML = "The mouse button is held down.";
        }
        
        function mouseUp() {
          document.getElementById("demo").innerHTML = "You released the mouse button.";
        }
</script>
  </body>
</html><?php
