<!--
71. Write a  Program to calculate and print the average of some integers. Accept all the values preceding 888.  
Sample Input:12
15
24
888
Sample Output:
Input each number on a separate line (888 to exit):

The average value of the said numbers is 17.000000
-->

 <html>
      <body>
        
        <form method='post'>
          <table>
            <tr>
              <td>
                <label for='num'> Enter mathematics marks : </label>
              </td>
              <td>
                <input type='text' id='num' name='num'>
              </td>
            </tr>
            
            <tr>
              <td></td>
              <td>
                <br>
                <input type="submit" name="Submit1">
              </td>
            </tr>
          </table>
        </form>
      </body>
    </html>
    <?php
     session_start();
     if(!empty($_SESSION['get_num'])){
       
     }else {
       $_SESSION['get_num']=array();
     }
     if($_POST['num']!=888){
       array_push($_SESSION['get_num'],$_POST['num']);
     }else
     {
       $count=count($_SESSION['get_num']);
       $array_sum=array_sum($_SESSION['get_num']);
       $average=$array_sum/$count;
       echo "Input each number on a separate line (888 to exit):";
       echo "<br>The average value of the said numbers is ".$average;
       session_destroy();
     }
     
    ?>