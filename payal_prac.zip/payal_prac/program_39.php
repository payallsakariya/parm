<!-- 
39. Write a  Program to calculate the value of S where S = 1 + 3/2 + 5/4 + 7/8.  
Expected Output:
Value of series: 4.62

-->
<html>
  <body>
   <form method='post'>
          <label for='num'> Enter no of terms : </label>
          <input type='text' id='num' name='num'>
          <input type='submit' name='Submit'>
   </form>
   
    <?php 
    $number=$_POST['num'];
     // echo $number;
     $nom=1;
     $denom=1;
     $sum=0;
     $t="";
     for($terms=1;$terms<=$number;$terms++){
        // echo $terms;
          $num = ($nom/$denom);
          //echo $num."<br>";
          $sum+=$num;
          // echo $sum."<br>";
          $t.="+".$nom."/".$denom;
          $nom=$nom+2;
          $denom=$denom*2;
          
 
     } 
     
     echo $t."<br>";
     echo "<br>Value of series :".$sum;
   // echo "<br>".$s=1+(3/2)+(5/4)+(7/8);
    ?>
  </body>
</html>
