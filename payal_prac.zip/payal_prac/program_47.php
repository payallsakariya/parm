<!--
47. Write a  Program that accepts principle, rate of interest, time and compute the simple interest.  
Test Data:
Input Data: p = 10000, r = 10% , t = 12 year
Expected Output:
Input principle, Rate of interest & time to find simple interest:
Simple interest = 12000


-->

 <html>
    <body>
      <form method='post'>
        <table>
          <tr>
            <td>
              <label for='p_num'> Enter principle: </label>
            </td>
            <td>
             <input type='text' id='p_num' name='p_num'>
             </td>
          </tr>
          <tr>
            <td>
               <label for='R_num'> Rate of interest : </label>
            </td>
            <td>
              <input type='text' id='R_num' name='R_num'>
            </td>
          </tr>
          
          <tr>
            <td>
              <label for='Time'>  Rate of interest & Time: </label>
            </td>
            <td>
              <input type='text' id='Time' name='Time'>
            </td>
          </tr>
    
        <tr>
          <td>
            <input type='submit' name='Submit'>
          </td>
        </tr>
        
        
        </table>
      </form>
    </body>
  </html>
  <?php
       
         $principle=$_POST['p_num'];
        $Rate=$_POST['R_num'];
        $time=$_POST['Time'];
        
        
        $Simple_interest=($principle*$Rate*$time)/100;
        echo "Simple interest = ".$Simple_interest;
        
  ?>