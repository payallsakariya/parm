 <!-- 15. Write a  Program that reads an integer and check the specified range where it belongs. Print an error message if the number                is negative and greater than 80.  
          Test Data :
          Input an integer: 15
          Expected Output:
          Range [0, 20]
-->
<html>
  <body>
<form>
  <table>
    <tr>
      <td>
        <label for="no">Enter integer number</label>
      </td>
      <td>
      <input type="text" id="no" name="no" onblur="myfunction()">
      </td>
    </tr>
  </table>
</form>
<p id="demo"></p>
<p id="demo1"></p>

<script>
 function myfunction(){
        var num = document.getElementById("no").value;
        document.getElementById('demo').innerHTML = num;
        var text=" ";
          switch (num>0) {
            case (num <= 20):
              // alert(num);
                text = "[0-20]";
                 break;
                 
           case (num <= 40):
                text = "[0-40]";
                 break;
                 
           case (num <= 60):
                text = "[0-60]";
                 break;
                 
          case (num <= 80):
                text = "[0-80]";
                 break;  
                 
          default:
              text = "The number is negative and greater than 80.";
          }
          document.getElementById('demo1').innerHTML = text;
  }
</script>
    
  </body>
</html>
