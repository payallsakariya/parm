<!-- 17. Write a  Program that reads three floating values and check if it is possible to make a triangle with them. Also calculate the perimeter of the triangle if the said values are valid.  
            Test Data :
            Input the first number: 25
            Input the second number: 15
            Input the third number: 35
            Expected Output:
            Perimeter = 75.0
-->
<html>
  <body>
      <form>
      <table>
        <tr>
          <td>
            <label for="first_no">Enter the first number :</label>
          </td>
          <td>
          <input type="text" id="first_no" name="first_no" onblur="myfunction()">
          </td>
        </tr>
        <tr>
        <td>
          <label for="second_no">Enter the second number :</label>
        </td>
        <td>
        <input type="text" id="second_no" name="second_no" onblur="myfunction()">
        </td>
        </tr>
         <tr>
           <td>
            <label for="third_no">Enter the third number :</label>
          </td>
          <td>
            <input type="text" id="third_no" name="third_no" onblur="myfunction()">
          </td>
        </tr>
        </table>
        </form>
        <p id="demo"></p>
        <p id="demo1"></p>
        <p id="demo2"></p>
        <p id="demo3"></p>
 <script>
   function myfunction(){
     var first_no =document.getElementById('first_no').value;
     document.getElementById('demo').innerHTML=first_no;
     var second_no =document.getElementById('second_no').value;
     document.getElementById('demo1').innerHTML=second_no;
     var third_no=document.getElementById('third_no').value;
     document.getElementById('demo2').innerHTML=third_no; 
     var sum =0;
    
if(parseInt(first_no)+parseInt(second_no) > third_no && parseInt(second_no) + parseInt(third_no) > first_no && parseInt(first_no) + parseInt(third_no) >second_no){
 
          sum += parseInt(first_no) + parseInt(second_no) + parseInt(third_no);
        
      }
       document.getElementById('demo3').innerHTML=sum+".0"; 
    
   }
 </script>
  </body>
</html>