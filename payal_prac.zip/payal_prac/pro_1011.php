<!--
11. Write a  Program to read an amount (integer value) and break the amount into the smallest possible number of bank notes.  
Test Data:
Input the amount: 375
Expected Output:
There are:
3 Note(s) of 100.00
1 Note(s) of 50.00
1 Note(s) of 20.00
0 Note(s) of 10.00
1 Note(s) of 5.00
0 Note(s) of 2.00
0 Note(s) of 1.00

-->
<html>
  <body>
    <form>
        <table>
          <tr>
            <td>
              <label for="amout1">Enter The Amount: </label>
            </td>
            <td>
              <input type="text" id="amout1" name="amout1" onblur="myfunction()">
            </td>
          </tr>
        </table>
        <p id="demo"></p>
        <p id="demo1"></p>
        <p id="demo2"></p>
        <p id="demo3"></p>
        <p id="demo4"></p>
        <p id="demo5"></p>
        <p id="demo6"></p>
        <p id="demo7"></p>
    </form>
    <script>
      function myfunction(){
        var sr=document.getElementById('amout1').value;
        document.getElementById('demo').innerHTML=sr;
        var note100=0;
        var note50=0;
        var note20=0;
        var note10=0;
        var note05=0;
        var note02=0;
        var note01=0;
        while(sr>=100) {
            sr-=100;
            note100++;
             
          } 
    document.getElementById('demo1').innerHTML="<br>Note(s) of 100.00 : "+note100;
   
         while(sr>=50) {
            sr-=50;
            note50++;
             
          } 
    document.getElementById('demo2').innerHTML="<br>Note(s) of 50.00 : "+note50;
    
        while(sr>=20) {
            sr-=20;
            note20++;
             
          } 
    document.getElementById('demo3').innerHTML="<br>Note(s) of 20.00 : "+note20;
   
         while(sr>=10) {
            sr-=10;
            note10++;
             
          } 
    document.getElementById('demo4').innerHTML="<br>Note(s) of 10.00 : "+note10;
    
        while(sr>=5) {
            sr-=5;
            note05++;
             
          } 
    document.getElementById('demo5').innerHTML="<br>Note(s) of 05.00 : "+note05;
   
         while(sr>=2) {
            sr-=2;
            note02++;
             
          } 
    document.getElementById('demo6').innerHTML="<br>Note(s) of 02.00 : "+note02;

         while(sr>=1) {
            sr-=1;
            note01++;
             
          } 
    document.getElementById('demo7').innerHTML="<br>Note(s) of 01.00 : "+note01;          
      }
    </script> 
   
  </body>
</html>
