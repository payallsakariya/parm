<!-- 
52. Write a  Program to display sum of series 1 + 1/2 + 1/3 + ………. + 1/n.  
Input any number: 1 + 1/0
Sum = 1/0

-->
<html>
  <body>
   <form method='post'>
          <label for='num'> Enter no of terms : </label>
          <input type='text' id='num' name='num'>
          <input type='submit' name='Submit'>
   </form>
   
    <?php 
    $number=$_POST['num'];
     // echo $number;
     $nom=1;
    
     $sum=0;
     $sum1=0;
     $t="";
     for($terms=1;$terms<=$number;$terms++){
        
            $sum+=(1/$terms)."<br>";
             $sum1+=$terms;
             $denom=$terms;
             $t.="+".$nom."/".$denom;
          
          
 
     } 
     
     echo "1".$t."<br>";
     echo "1/".$sum1;
     echo "<br>Value of series :".$sum;
    ?>
  </body>
</html>

