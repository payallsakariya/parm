<html>
  <body>
    <form>
      <table>
        <tr>
          <td>
            <label for="first_no">Enter the first number :</label>
          </td>
          <td>
          <input type="text" id="first_no" name="first_no" onblur="myfunction()">
          </td>
        </tr>
        
        <tr>
        <td>
            <label for="second_no">Enter the second number :</label>
          </td>
          <td>
        <input type="text" id="second_no" name="second_no" onblur="myfunction()">
          </td>
        </tr>
        
        <tr>
         <td>
            <label for="third_no">Enter the third number :</label>
          </td>
          <td>
          <input type="text" id="third_no" name="third_no" onblur="myfunction()">
          </td>
        </tr>
         
         <tr>
         <td>
            <label for="fourth_no">Enter the fourth number :</label>
          </td>
          <td>
       <input type="text" id="fourth_no" name="fourth_no" onblur="myfunction()">
          </td>
        </tr>

         <tr>
         <td>
            <label for="fifth_no">Enter the  fifth number :</label>
          </td>
          <td>
          <input type="text" id="fifth_no" name="fifth_no" onblur="myfunction()">
          </td>
        </tr>
      </table>
    </form>
    <p id="demo"></p>
    <p id="demo1"></p>
    <p id="demo2"></p>
  <script>
    function myfunction(){
       var first =document.getElementById('first_no').value;
       var second = document.getElementById('second_no').value;
       var third = document.getElementById('third_no').value;
       var fourth = document.getElementById('fourth_no').value;
       var fifth = document.getElementById('fifth_no').value;
       const number=[first,second,third,fourth,fifth];
       document.getElementById('demo').innerHTML=number;
       
      var even=0;
      var odd=0;
  
      for(var x=0; x < number.length; x++){
              // alert(number.)
        if(number[x]%2==0){
          even += parseInt(number[x]);
          }
        else {
          odd += parseInt(number[x]);
        }
      }
     
      document.getElementById('demo1').innerHTML="<br>even sum : "+even;
      document.getElementById('demo2').innerHTML="<br>Odd number sum : "+odd;
    }
  </script>
    
  </body>
</html>
