<!--
14. Write a  Program that accepts 4 integers p, q, r, s from the user where q, r and s are positive and p is even. If q is greater than r and s is greater than p and if the sum of r and s is greater than the sum of p and q print "Correct values", otherwise print "Wrong values".  
Test Data :
Input the second integer: 35
Input the third integer: 15
Input the fourth integer: 46
Expected Output:
Wrong values
-->
<html>
  <body>
    <form method="post" target="_top">
      <body>
        <table>
          <tr>
            <td>
              <label for="f_numbre">Enter the first number : </label>
            </td>
            <td>
              <input type="text" id="f_numbre" name="f_numbre">
            </td>
          </tr>
          <tr>
            <td>
              <label for="s_numbre">the second number : </label>
            </td>
            <td>
              <input type="text" id="s_numbre" name="s_numbre">
            </td>
          </tr>
          
           <tr>
            <td>
              <label for="t_numbre">Enter the third number : </label>
            </td>
            <td>
              <input type="text" id="t_numbre" name="t_numbre">
            </td>
          </tr>
          <tr>
            <td>
              <label for="F_numbre">the fourth number : </label>
            </td>
            <td>
              <input type="text" id="F_numbre" name="F_numbre">
            </td>
          </tr>
          
          
          <tr>
            <td>
              <input type="submit" value="Sumbit">
            </td>
          </tr>
        </table>
      </form>
  </body>
  
    
    <?php 
          $p= $_POST["f_numbre"];
          $q= $_POST["s_numbre"];
          $r= $_POST["t_numbre"];
          $s= $_POST["F_numbre"];
          
          if($q>$r && $s>$p){
            $a=$r+$s;
            $b=$p+$q;
          }
          if($a>$b){
            echo "Correct values";
          }else {
            echo "not Correct values";
          }
          
          
    ?>      