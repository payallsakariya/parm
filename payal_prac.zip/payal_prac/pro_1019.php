<!-- 19. Write a  Program that reads an integer between 1 and 12 and print the month of the year in English.  
      Test Data :
      Input a number between 1 to 12 to get the month name: 8
      Expected Output:
      August
      January, February, March, April, May, June, July, and August. September, October, November, and December.
-->
<html>
  <body>
    <form>
      <table>
        <tr>
          <td>
            <label for="e_name">Enter number :</label>
          </td>
          <td>
            <input type="text" id="e_name" name="e_name" onblur="myfunction()">
          </td>
        </tr>
      </table>
      <p id="demo"></p>
       <p id="demo1"></p>
    </form>
    <script>
      function myfunction(){
        var number=document.getElementById('e_name').value;
        document.getElementById('demo').innerHTML=number;
        const year = {1:"January" ,2:"February" , 3 :"March",4:"April",
                       5 : "May",6:"June",
                       7 : "July",8:" August",
                       9 : "September",10:"October",
                       11 : "November",12:"December"};
                       
         document.getElementById('demo1').innerHTML=year[number];
                       
      }
    </script>
  </body>
</html>