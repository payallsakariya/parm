<!--
30. Write a  Program to read a password until it is correct. For wrong password print "Incorrect password" and for correct password print "Correct password" and quit the program. The correct password is 1234.  
Test Data :
Input the password: 1234
Expected Output:
Correct password

-->

<html>
  <body>
    <form method="post">
      <label for="no1"> Enter password : </label>
      <input type="text" id='no1' name='no1'>
      <br><br>
      <input type="submit" name="Submit">
    </form>
<?php
$num=$_POST['no1'];
$pass=1234;
if($pass==$num){
  echo "Correct password";
}else {
  echo "not Correct password";
}

?>
</body>
</html>