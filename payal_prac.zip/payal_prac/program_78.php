<!--78. Write a  Program that reads three integers and sort the numbers in ascending order. Print the original numbers and sorted numbers.  
Sample Output:
Input 3 integers: 17
-5
25

---------------------------
Original numbers: 17, -5, 25
Sorted numbers: -5, 17, 25
-->
<html>
      <body>
        <form method='post'>
          <table>
            <tr>
              <td>
                 <label for='no1'> Enter number1 : </label>
              </td>
              <td>
                <input type='text' id='no1' name='no1'>
              </td>
            </tr>
            
             <tr>
              <td>
                 <label for='no2'> Enter number2 : </label>
              </td>
              <td>
                <input type='text' id='no2' name='no2'>
              </td>
            </tr>
            
             <tr>
              <td>
                 <label for='no3'> Enter number3 : </label>
              </td>
              <td>
                <input type='text' id='no3' name='no3'>
              </td>
            </tr>
            <tr>
              <td>
                 <input type='submit' name='Submit'>
              </td>
            </tr>
            
          </table>
             
        </form>
      </body>
    </html>
    
    
    <?php 
    
        $number1 = $_POST['no1'];
        $number2 = $_POST['no2'];
        $number3 = $_POST['no3'];
        $num_array=array($number1,$number2,$number3);
        
        $list1=implode(",",$num_array);
        print_r("Original numbers: ".$list1);
        
        sort($num_array);
        
      
        echo "<br>";
        $list=implode(",",$num_array);
        print_r("Sorted numbers: ".$list);
       
        ?>

