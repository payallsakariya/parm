<!-- 
66. Write a  Program to demonstrates the difference between predecrementing and postdecrementing using the decrement operator --.  
Sample Output:
Predecrementing:
x = 10
x-- = 10
x = 9

-->
<html>
  <body>
   <form method='post'>
          <label for='num'> enter number : </label>
          <input type='text' id='num' name='num'>
          <input type='submit' name='Submit'>
   </form>
   <?php
       $x=$_POST['num'];
      
       echo "x = ".$x;
       $x1=$x--;
       echo "<br>x-- = ".$x1;
       echo "<br>x = ".$x;
   
   
   ?>
   </body>
</html>