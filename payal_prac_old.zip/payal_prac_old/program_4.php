<!-- 4. Write a  program to input and print the age which should be greater than 18 and less than 30, 
           age check should be there and input  the age recursively until the age value is not valid 

-->



<html>
  <body>
  <form action="action_pro4.php" method="post" target="_top">
    <table>
      <tr>
        <td>
          <label for="">Enter Age</label>
        </td>
        <td>
          <input type="text" id="age" name="age">
        </td>
      </tr>
      <tr>
        <td>
          <input type="submit" value="Submti">
        </td>
      </tr>
    </table>
  </form>
  
  
  </body>
</html>
