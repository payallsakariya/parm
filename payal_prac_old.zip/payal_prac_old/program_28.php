<!--
28. Write a  Program to compute the sum of consecutive odd numbers from a given pair of integers.  
Test Data :
Input a pair of numbers (for example 10,2):
Input first number of the pair: 10
Input second number of the pair: 2
Expected Output:
List of odd numbers: 3
5
7
9
Sum=24

-->

<html>
  <body>
    <form method="post" target="_top">
      <table>
        <tr>
          <td>
            <label for="f_number">Enter first number :</label>
          </td>
          <td>
            <input type="text" id="f_number" name="f_number">
          </td>
        </tr>
        
        
        <tr>
          <td>
            <label for="s_number">Enter second number :</label>
          </td>
          <td>
            <input type="text" id="s_number" name="s_number">
          </td>
        </tr>
        
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
        
      </table>
    </form>
    <?php 
    $f_number =$_POST["f_number"];
    $s_number =$_POST["s_number"];
    $oddarr=array();
  
     if($f_number>$s_number){
       for($i=$s_number;$i<=$f_number;$i++){
         // echo $i;
          if($i%2==1){
              array_push($oddarr,$i);
         }
          }
     }
     
    echo "List of odd numbers:<br ";
    $count=count($oddarr);
  for($x=0;$x<$count;$x++)
  {
      echo $oddarr[$x];
      echo "<br>";
  }
    $sum=array_sum($oddarr);
   echo "<br> Sum is".$sum;
   
    
    ?>
  </body>
</html>

