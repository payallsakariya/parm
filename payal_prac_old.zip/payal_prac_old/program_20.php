<!-- 20. Write a  Program that prints all even numbers between 1 and 50 (inclusive).  
        Test Data :
        Even numbers between 1 to 50 (inclusive):
        Expected Output:
        2 4 6 8 10 12 14 16 18 20 22 24 26 28 30 32 34 36 38 40 42 44 46 48 50

-->
<html>
  <body>
 <!--   <form method="post" target="_top" >
      <table>
        <tr>
          <td>
            <label for="e_name">Enter number :</label>
          </td>
          <td>
            <input type="text" id="e_name" name="e_name"
          </td>
        </tr>
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
      </table>
      
    </form>-->
    
  <?php 
           // $number= $_POST["e_name"];
                 
            //echo $number;
      for($i=1;$i<=50;$i++){
        if($i%2==0){
        echo $i." ";
        //echo("<br>");
          
        }
      }
        
  ?>
  </body>
</html>
