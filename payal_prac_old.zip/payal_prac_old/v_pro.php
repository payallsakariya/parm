<html>
  <body>
       <table>
         <tr>
        <td>
          <label>percent</label>
        </td>
        <td>
          <input type="text" id="num" name="num" onblur="myfunction()">
        </td>
      </tr>
      <tr>
        <td>
          <label for="1">percent_1</label>
        </td>
        <td>
         <input type="text"id="1" name="num1" onblur="myfunction()"> 
        </td>
      </tr>
      <tr>
        <td>
          <label for="2">percent_2</label>
        </td>
        <td>
          <input type="text" id="2" name="num2" onblur="myfunction()">
        </td>
      </tr>
      <tr>
        <td>
          <label for="3">percent_3</label>
        </td>
        <td>
         <input type="text" id="3" name="num3" onblur="myfunction()"> 
        </td>
      </tr>
      <tr>
        <td>
          <label for="4">percent_4</label>
        </td>
        <td>
         <input type="text" id="4" name="num4" onblur="myfunction()"> 
        </td>
      </tr>
      
      <tr>
        <td>
          <label for="5">percent_5</label>
        </td>
        <td>
         <input type="text" id="5" name="num5" onblur="myfunction()"> 
        </td>
      </tr>
      
    </table>
    <p id="demo"></p>
    <script>
      function myfunction(){
         var per = document.getElementById('num').value;
        var inputVal = 0;
        for(let i = 1; i <= 10; i++){
          
             var nums = document.getElementById(i);
         
              if (nums) {
                if(inputVal<per){
                  inputVal += parseInt(nums.value);
                }
              }
        }
          
          // alert(inputVal);
         
          var text="";
          if(per<inputVal){
             text="Wrong values";
          }else{
            text ="right values";
          }
          document.getElementById('demo').innerHTML=text;
          }
  
      
    </script>
  </body>
</html>
