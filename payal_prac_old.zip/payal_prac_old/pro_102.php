<!-- 2. Write a  program to take input of two numbers, and find their sum, product and sum of the squares.
 -->

<html>
  <body>
      <table>
        <tr>
          <td>
            <label for="no1">enter number 1 :- </label>
          </td>
          <td>
            <input type="text" id="no1" name="no1" onblur="form_value()" required>
          </td>
        </tr>
        
         <tr>
          <td>
            <label for="no2">enter number 2 :- </label>
          </td>
          <td>
            <input type="text" id="no2" name="no2" onblur="form_value()" required>
          </td>
        </tr>
      </table>
      <table>
        <tr>
          <td>
            <p id="demo1"></p>
          </td>
        </tr>
        
        <tr>
          <td>
            <p id="demo2"></p>
          </td>
        </tr>
      </table>
      
      
  <script>
    function form_value(){
      var A=document.getElementById('no1').value;
      var B=document.getElementById('no2').value;
      var sum = A + B;
      // document.getElementById('demo1').innerHTML =sum;
   document.getElementById('demo2').innerHTML ="squares is" + (A*B);
   document.getElementById("demo1").innerHTML = "The sum of A + B is: " + sum;
    }
    
    
  </script>
    
  </body>
</html>
