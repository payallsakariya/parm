<!-- 
53. Write a  Program that accepts a positive integer less than 500 and prints out the sum of the digits of this number.  
Input a positive number less than 500:
Sum of the digits of 347 is 14

-->
<html>
  <body>
   <form method='post'>
          <label for='num'> Enter no of terms : </label>
          <input type='text' id='num' name='num'>
          <input type='submit' name='Submit'>
   </form>
   
    <?php 
    $sum=0;
    $number=$_POST['num'];
    // echo strlen($number);
    if($number<500)
    {
     $strlen=strlen($number);     
     for($i=0;$i<=$strlen;$i++){
      // echo "hi";
      // echo "<br>".$number[$i];
        $sum+=$number[$i];
     }
     
      echo "Sum of the digits of ".$number." is ".$sum;
    }else {
      echo "Enter valid number less then 5000";
    }
    ?>
  </body>
</html>

