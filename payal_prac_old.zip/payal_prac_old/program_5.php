<html>
  <body>
    <form  method="post">
      <table>
        <tr>
          <td>
            <label for="sname">Enter String</label>
          </td>
          <td>
            <input type="text" id="sname" name="sname">
          </td>
        </tr>
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
      </table>
    </form>
    <?php 
      echo "The reverse of string : ".strrev($_POST["sname"]);
    ?>
  </body>
</html>
