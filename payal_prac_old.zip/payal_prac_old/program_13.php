<!-- 13. Write a  Program to convert a given integer (in days) to years, months and days assuming that all months have 30 days and                   all years have 365 days.  
        Test Data:
        Input no. of days: 2535
        Expected Output:
        6 Year(s)
        11 Month(s)
        15 Day(s)
         
        -->

<html>
  <body>
    <form  method="post" target="_blank" >
      <table>
        <tr>
          <td>
            <label for="ndays">Number of days : </label>
          </td>
          <td>
            <input type="text" id="ndays" name="ndays">
          </td>
        </tr>
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
      </table>
    </form>
    
     <?php $a=$_POST["ndays"];
             echo " Test Data :<br>";
            echo " Number of days :".$a ."<br>";
            
            $y= $a / 365;
            $years=(int)$y;
            $Y=365*$years;
            $w1=$a-$Y;
            $w2=$w1/30;
            $months=(int)$w2;
            $W=$months*30;
            $days=$a-$Y-$W;
           
            echo "Years : ".$years."<br>";
            echo "Month : ".$months."<br>"; 
            echo "Days :".$days;
          
            
         ?>
  </body>
</html>
