<!--18. Write a  Program that reads two integers and checks whether they are multiplied or not.  
Test Data :
Input the first number: 5
Input the second number: 15
Expected Output:
Multiplied!
 -->



<html>
  <body>
    <form>
      <body>
        <table>
          <tr>
            <td>
              <label for="f_numbre">Enter the first number : </label>
            </td>
            <td>
          <input type="text" id="f_numbre" name="f_numbre" onblur="myfunction()">
            </td>
          </tr>
          <tr>
            <td>
              <label for="s_numbre">the second number : </label>
            </td>
            <td>
          <input type="text" id="s_numbre" name="s_numbre" onblur="myfunction()">
            </td>
          </tr>
        </table>
      </body>
    </form>
    <p id="demo"></p>
    <p id="demo1"></p>
    <p id="demo2"></p>
    <script>
    function myfunction(){
      var f_number =document.getElementById('f_numbre').value;
      var s_number =document.getElementById('s_numbre').value;
      document.getElementById('demo').innerHTML=f_number;
      document.getElementById('demo1').innerHTML=s_number;
      text="";
        for(var x=1; x <= 10; x++){
     
            if( parseInt(x) * parseInt(f_number) == s_number){
           
              text ="Multiplied!";
            }
          }
          document.getElementById('demo2').innerHTML=text;
    }
    </script>
  </body>
</html>
