<!--
65. Write a  Program that accepts principal amount, rate of interest and days for a loan and calculate the simple interest for the loan, using the following formula.  
interest = principal * rate * days / 365.
Sample Input:
10000
.1
365
0
Sample Output:
Input loan amount (0 to quit): Input interest rate: Input term of the loan in days: The interest amount is $1000.00
Input loan principal_amt (0 to quit):



-->

 <html>
    <body>
      <form method='post'>
        <table>
          <tr>
            <td>
              <label for='p_num'> Enter principle: </label>
            </td>
            <td>
             <input type='text' id='p_num' name='p_num'>
             </td>
          </tr>
          <tr>
            <td>
               <label for='R_num'> Rate of interest : </label>
            </td>
            <td>
              <input type='text' id='R_num' name='R_num'>
            </td>
          </tr>
          
          <tr>
            <td>
              <label for='day'>enter days: </label>
            </td>
            <td>
              <input type='text' id='day' name='day'>
            </td>
          </tr>
    
        <tr>
          <td>
            <input type='submit' name='Submit'>
          </td>
        </tr>
        
        
        </table>
      </form>
    </body>
  </html>
  <?php
       
         $principle=$_POST['p_num'];
        $Rate=$_POST['R_num'];
        $days=$_POST['day'];
        
        
        $Simple_interest=($principle*$Rate*$days)/365;
        echo "the interest amount is $".$Simple_interest;
        
  ?>