<html>
  <body>
    <?php declare(strict_types=1);       
       function familyName($fname){
         echo "$fname .<br>";
       }
       
       function brithDay($bname, $year){
         echo "$bname b_year $year.<br>";
       }
       
       function duA(int $val=20){
         echo "$val <br>";
        }
        duA();
        duA(32);
        
       

function myfunction($a,$b)
¸.


       
       familyName("priya");
       familyName("pari");     
       brithDay("dax","1991");
       brithDay("dixit","1992");
    
    ?>
    
    
 


  </body>
</html>
