<!--
32. Write a  Program to calculate the sum of all numbers not divisible by 17 between two given integer numbers.  
Test Data:
Input the first integer: 50 Input the second integer: 99
Expected Output:
Sum: 3521

-->

<html>
  <body>
    <form method="post" target="_top">
      <table>
        <tr>
          <td>
            <label for="f_number">Enter first number :</label>
          </td>
          <td>
            <input type="text" id="f_number" name="f_number">
          </td>
        </tr>
        
        
        <tr>
          <td>
            <label for="s_number">Enter second number :</label>
          </td>
          <td>
            <input type="text" id="s_number" name="s_number">
          </td>
        </tr>
        
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
        
      </table>
    </form>
    <?php 
     $f_number =$_POST["f_number"];
     $s_number =$_POST["s_number"];
    //$divarr=array();
    $ansarr=array();
    $nober=array();
 // $ans=0;
    if($f_number<$s_number){
       for($i=$f_number+1;$i<$s_number;$i++){
         //array_push($nober,$i);
         if($i%17!=0)
         {
           echo($i."<br>");
            array_push($ansarr,$i);
            
        
         }
         
       }
    }
    
    //$sum4=array_sum($nober);
   //echo "<br> Sum is : ".$sum4;
   
   
     $sum1=array_sum($ansarr);
   echo "<br> Sum is : ".$sum1;
   
    ?>
  </body>
</html>

