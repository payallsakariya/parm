<!--8. Write a  Program to convert specified days into years, weeks and days.  
        Note: Ignore leap year.
        
        Test Data :
        Number of days : 1329
        Expected Output :
        Years: 3
        Weeks: 33
        Days: 3
-->

<html>
  <body>
    <form action="action_pro8.php" method="post" target="_top" >
      <table>
        <tr>
          <td>
            <label for="dgt">Number of days : </label>
          </td>
          <td>
            <input type="text" id="dgt" name="dgt">
          </td>
        </tr>
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
      </table>
    </form>
  </body>
</html>
