<html>
  <body>
    <form method="post">
      <label for=""> Enter value</label>
      <input type="text" id='tir' name='tir'>
      <input type="submit" name="Submit">
    </form>
             
      <?php 
        $a=$_POST['tir'];
     
        ?>
        
        <table>
          <tr>
            <td>
               <?php
               $k=1;  
             for($i=0;$i<=$a;$i++){  
               for($j=0;$j<=$i;$j++){  
                    echo $k." ";  
                     $k++;  
                   }  
                 echo "<br>";  
               } 
               ?>      
              
            </td>
          </tr>
          
          <tr>
            <td>
               <?php
             
             for($i=0;$i<=$a;$i++){  
               for($j=1;$j<=$i;$j++){  
                    echo $j." ";  
                   }  
                 echo "<br>";  
               } 
      ?>    
              
            </td>
          </tr>
        </table>
        
          
  </body>
</html>
