<!--
62. Write a  Program to display the integer equivalents of letters (a-z, A-Z).  
Sample Output:
List of integer equivalents of letters (a-z, A-Z).
==================================================
97 98 99 100 101 102
103 104 105 106 107 108
109 110 111 112 113 114
115 116 117 118 119 120
121 122 32 65 66 67
68 69 70 71 72 73
74 75 76 77 78 79
80 81 82 83 84 85
86 87 88 89 90

-->
<html>
  <body>
    <?php
      
  echo "List of integer equivalents of letters (a-z, A-Z).
         <br>======================<br>"; 
         $a=57;
         $k=97;
      for($i=1;$i<=9;$i++){
        // echo $i;
         for($j=1;$j<=6;$j++){
           if($k<122){
               echo " ".$k+=1;
              // $k++;
            }else {
              echo "  ".$k-$a;
              $k++;
            }  
         }
         echo "<br>";
         
       
       }
      
      // for($i=65;$i<=90;$i++){
      //     echo $i;
      //   for($j=1;$j<6;$j++){
      //     echo " ".$i+=1;
      //   }
      //   echo "<br>";
      
      // }
    
    ?>
  </body>
</html>