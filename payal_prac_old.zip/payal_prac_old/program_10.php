<!-- 
10. Write a  Program that accepts three integers and find the maximum of three.  
Test Data:
Input the first integer: 25
Input the second integer: 35
Input the third integer: 15
Expected Output:
Maximum value of three integers: 35

-->

<html>
  <body>
     <form  method="post">
      <table>
        <tr>
          <td>
            <label for="no1">Input the first integer:</label>
          </td>
          <td>
            <input type="text" id="no1" name="no1">
          </td>
        </tr>
        <tr>
          <td>
            <label for="no2">Input the second integer:</label>
          </td>
          <td>
            <input type="text" id="no2" name="no2">
          </td>
        </tr>
        
        <tr>
          <td>
            <label for="no3">Input the third integer:</label>
          </td>
          <td>
            <input type="text" id="no3" name="no3">
          </td>
        </tr>
        
        
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
      </table>
    </form>
    <?php 
      echo "Maximum value of three integers : ".max($_POST["no1"],$_POST["no2"],$_POST["no3"]);
    ?>
  </body>
</html>