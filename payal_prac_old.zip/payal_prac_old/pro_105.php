<html>
  <body>
    <!--<form  method="post">-->
    <!--  <table>-->
    <!--    <tr>-->
    <!--      <td>-->
    <!--        <label for="sname">Enter String</label>-->
    <!--      </td>-->
    <!--      <td>-->
    <!--        <input type="text" id="sname" name="sname" onblur="form_value()">-->
    <!--      </td>-->
    <!--    </tr>-->
      
    <!--  </table>-->
    <!--</form>-->
  <p id="demo1"></p>
  <br>
  <p id="demo2"></p>
  
<script>
  // function form_value(){
  //   // alert('hi');
  //   const str=document.getElementById('sname').value;
  //   // var reverse(str);
  //   document.getElementById('demo1').innerHTML = str;
  //   // document.getElementById('demo2').innerHTML = str.reverse();
  // let fLen = str.length; 
  // document.getElementById('demo').innerHTML = fLen;
  // }
  
  const str=['X','M','L'];
  document.getElementById('demo1').innerHTML="sring : " +str;
  document.getElementById('demo2').innerHTML="reverse sring : " +str.reverse();
  
</script>
  </body>
</html>

