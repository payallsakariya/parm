
<!DOCTYPE html>

<!-- 1 Write a program to input and print your name, date of birth. and mobile number. 
        Expected Output: 
        Name   : Alexandra Abramov  
        DOB    : July 14, 1975  
        Mobile : 99-9999999999 -->
<html>
    <body>
<form method="post" id="form">
    <center>
    <table>
      <tr>        
      <td> 
      <label for="fname">Name  </label>
      </td>
     <td>
     <input type="text" id="fname" name="fname" onblur="form_value()" required>
     </td>
     </tr>
                
     <tr>
      <td>
         <label for="brith">DOB : </label>
      </td>
      <td>    
        <input type="date" id="brith" name="brith" onblur="form_value()" required>
      </td>
    </tr>
      
                
<tr>
    <td>  
       
       <label for="phone">Mobile : </label>
    </td>
    <td>
        <input type="tel" id="phone" name="phone" placeholder                                 ="9872635467"pattern="[0-9]{10}" onblur="form_value()" required >
    </td>
</tr>
                <!--<tr>-->
                <!--    <td>-->
                <!--        <input type="submit" value="Submit" id="Submit" onclick="form_value()" >-->
                <!--    </td>-->
                <!--</tr>-->
            
            </table>
            </center>
            </form>
<table>
  <tr>
    <td>
      <label> Name :</label>
    </td>
    <td>
        <p id="demo1"></p>
    </td>
  </tr>
  <tr>
     <td>
      <label> DOB :</label>
    </td>
    <td>
        <p id="demo2"></p>
    </td>
  </tr>
  <tr>
     <td>
      <label> Mobile :</label>
    </td>
    <td>
        <p id="demo3"></p>
    </td>
  </tr>
</table>            
            
             
<script>
  function form_value() {
    //alert("hi");
   var name = document.getElementById("fname").value;
   //alert(name);
   var brith = document.getElementById("brith").value;
   var phone = document.getElementById("phone").value;
   
  document.getElementById("demo1").innerHTML = name;

  document.getElementById("demo2").innerHTML = brith;
  document.getElementById("demo3").innerHTML = phone;
    
  }
 // document.getElementById("demo1").innerHTML = name;
</script>

    </body>
</html>