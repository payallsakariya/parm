<!--
67. Write a  Program using looping to produce the following table of values.  
Sample Output:
x       x+2     x+4     x+6
--------------------------------
1       3       5       7
4       6       8       10
7       9       11      13
10      12      14      16
13      15      17      19


-->

<html>
  <body>

       
  
   <?php
       

       echo "<table >";
        echo "<tr>
        <td>X</td>
        <td>X+2</td> 
        <td>X+4</td>
        <td>X+5</td>
        </tr>";
       
         echo "<tr><td>";
         echo "--------------------------------";   
         echo "</td></tr>";
     
         
          
 
      for($i=1;$i<=5;$i++){
           echo "<tr>";
        // $sum=$k;
          if($i==1){
            $k=1;
            $x=1;
          }else
          {
            $k=$x+3;
            $x=$k;
          }
          
        for($j=1;$j<=4;$j++){
          if($j==1){
          
             echo "<td>";
             echo $k."   ";
             echo "</td>";
          
            
          }else {
          
            echo "<td>";
            echo $k+=2;
            echo "</td>";
       
          }
           
           
        }
     
          echo "<br>";
         echo "</tr>"; 
      }  
     
       echo "</table>"
       
       
    ?>
</body>
</html>