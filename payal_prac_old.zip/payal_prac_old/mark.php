<html>
  <body>
    <form method="post" target="top">
      <label for="">Enter percentage</label>
      <input type="munber" id="ps" name="ps">
      <input type="submit" id="Submit">
    </form>
    <?php
      $ps = $_POST['ps'];
      
      // echo $ps;
       
     // echo "<br>percentage is : -".$ps."<br><br>";
      
      if ($ps <=100 && $ps>=90) {
            echo "AA";
      }
      elseif ($ps<=90 && $ps>=75) {
          echo "BB";
        // code...
      } 
      elseif($ps<=75 && $ps>=50){
         echo "CC";
      }
      elseif($ps<=50){
        echo "DD";
      }
      else {
        echo "FF";
      }
      
    
    ?>
  </body>
</html>
