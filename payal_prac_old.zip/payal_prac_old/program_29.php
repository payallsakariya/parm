<!--
29. Write a  Program to check whether two numbers in a pair is in ascending order or descending order.  
Test Data :
Input a pair of numbers (for example 10,2 : 2,10):
Input first number of the pair: 10
Input second number of the pair: 2

Expected Output:

The pair is in descending order!


-->

<html>
  <body>
    <form method="post" target="_top">
      <table>
        <tr>
          <td>
            <label for="f_number">Enter first number :</label>
          </td>
          <td>
            <input type="text" id="f_number" name="f_number">
          </td>
        </tr>
        
        
        <tr>
          <td>
            <label for="s_number">Enter second number :</label>
          </td>
          <td>
            <input type="text" id="s_number" name="s_number">
          </td>
        </tr>
        
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
        
      </table>
    </form>
    <?php 
    $f_number =$_POST["f_number"];
    $s_number =$_POST["s_number"];
    
  
     if($f_number<$s_number){
       echo "The pair is in  ascending order!";
     }else {
       echo "The pair is in descending order!";
     }
     
    
   
    
    ?>
  </body>
</html>


