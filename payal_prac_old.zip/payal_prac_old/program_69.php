<html>
  <head>
    <style>
      table{
        width: 10px;
        height: 10px;
    </style>
  </head>
  <body>
<?php
echo "<table><tr><td>";
      for($i=1;$i<11;$i++){
          echo "#";
        }
echo "</td></tr><tr><td>";  
        for($i=0;$i<8;$i++){
           echo "<br>#";
        }
echo "</td><td>";       
         for($i=0;$i<8;$i++){
            echo "<br>#";
        }
echo "</td></tr><tr><td>";
         for($i=1;$i<11;$i++){
            echo "#";
            }
echo "</td></tr></table>";            

?>
</body>
</html>