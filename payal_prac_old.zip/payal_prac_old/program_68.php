<!--
68. Write a  Program that reads the side (side sizes between 1 and 10 ) of a square and prints square using hash (#) character.  
Sample Input: 10
Sample Output:
Input the size of the square: 
 # # # # # # # # # #
 # # # # # # # # # #
 # # # # # # # # # #
 # # # # # # # # # #
 # # # # # # # # # #
 # # # # # # # # # #
 # # # # # # # # # #
 # # # # # # # # # #
 # # # # # # # # # #
 # # # # # # # # # #


-->

    <?php
    for($i=1;$i<=10;$i++){
      for($j=1;$j<=10;$j++){
        echo "  #  ";
        
      }
      echo "<br>";
    }
    
    ?>

