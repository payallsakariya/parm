
    <html>
      <body>
        <form method='post'>
          <table>
            <tr>
              <td>
                 <label for='no1'> Enter number1 : </label>
              </td>
              <td>
                <input type='text' id='no1' name='no1'>
              </td>
            </tr>
            
             <tr>
              <td>
                 <label for='no2'> Enter number2 : </label>
              </td>
              <td>
                <input type='text' id='no2' name='no2'>
              </td>
            </tr>
            
             <tr>
              <td>
                 <label for='no3'> Enter number3 : </label>
              </td>
              <td>
                <input type='text' id='no3' name='no3'>
              </td>
            </tr>
             <tr>
              <td>
                 <label for='no4'> Enter number4 : </label>
              </td>
              <td>
                <input type='text' id='no4' name='no4'>
              </td>
            </tr>
             <tr>
              <td>
                 <label for='no5'> Enter number5 : </label>
              </td>
              <td>
                <input type='text' id='no5' name='no5'>
              </td>
            </tr>
            
            <tr>
              <td>
                 <label for='no6'> Enter number 6 : </label>
              </td>
              <td>
                <input type='text' id='no6' name='no6'>
              </td>
            </tr>
            <tr>
              <td>
                 <input type='submit' name='Submit'>
              </td>
            </tr>
            
          </table>
             
        </form>
      </body>
    </html>
    
    
    <?php 
    
        $number1 = $_POST['no1'];
        $number2 = $_POST['no2'];
        $number3 = $_POST['no3'];
        $number4 = $_POST['no4'];
        $number5 = $_POST['no5'];
        $number6 = $_POST['no6'];
        
       $num_array=array($number1,$number2,$number3,$number4,$number5,$number6);
     
        echo "Smallest Value : ".min($num_array);
        echo "<br>Smallest Value : ".max($num_array);
      
        ?>