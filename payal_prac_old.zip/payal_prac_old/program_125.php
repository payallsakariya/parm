<!--
125. Write a  Program that reads an array of integers (length 7), and replace the first element of the array by a give number and replace each subsequent position of the array by the double value of the previous.  
Sample Output:
Input the first element of the array:
5

Array elements:
array_nums[0] = 5
array_nums[1] = 10
array_nums[2] = 20
array_nums[3] = 40
array_nums[4] = 80
array_nums[5] = 160
array_nums[6] = 320

-->
<html>
  <body>
    <form method="post">
      <table>
        <tr>
          <td>
            <label for="num">enter number</label>
          </td>
          <td>
            <input type="text" id="num" name="num">
          </td>
        </tr>
        <tr>
          <td>
            <input type="submit" name="Submit">
          </td>
        </tr>
      </table>
    </form>
    
    <?php
     
       $num=$_POST['num'];
       
       for($i=0;$i<7;$i++){
         echo "<br>array_nums[$i] = ".$num;
         $num+=$num;
       }
    
    ?>
  </body>
</html>