<!--
14. Write a  Program that accepts 4 integers p, q, r, s from the user where q, r and s are positive and p is even. If q is greater than r and s is greater than p and if the sum of r and s is greater than the sum of p and q print "Correct values", otherwise print "Wrong values".  
Test Data :
Input the second integer: 35
Input the third integer: 15
Input the fourth integer: 46
Expected Output:
Wrong values
-->
<html>
  <body>
    <form>
      <body>
        <table>
          <tr>
            <td>
              <label for="f_numbre">Enter the first number : </label>
            </td>
            <td>
          <input type="text" id="f_numbre" name="f_numbre" onblur="myfunction()">
            </td>
          </tr>
          <tr>
            <td>
              <label for="s_numbre">the second number : </label>
            </td>
            <td>
        <input type="text" id="s_numbre" name="s_numbre" onblur="myfunction()">
            </td>
          </tr>
          
           <tr>
            <td>
              <label for="t_numbre">Enter the third number : </label>
            </td>
            <td>
       <input type="text" id="t_numbre" name="t_numbre" onblur="myfunction()">
            </td>
          </tr>
          <tr>
            <td>
              <label for="F_numbre">the fourth number : </label>
            </td>
            <td>
      <input type="text" id="F_numbre" name="F_numbre" onblur="myfunction()">
            </td>
          </tr>
        </table>
        <p id="demo"></p>
        <p id="demo1"></p>
        <p id="demo2"></p>
        <p id="demo3"></p>
         <p id="demo4"></p>
         </form>
         <script>
         function myfunction(){
           var p=document.getElementById('f_numbre').value;
           var q=document.getElementById('s_numbre').value;
           var r=document.getElementById('t_numbre').value;
           var s=document.getElementById('F_numbre').value; 
           
           document.getElementById('demo').innerHTML=p;
           document.getElementById('demo1').innerHTML=q;
           document.getElementById('demo2').innerHTML=r;
           document.getElementById('demo3').innerHTML=s;
          
         
            if(q > r && s > p){
              // alert("hi");
              
                var a=parseInt(r)+parseInt(s);
                var b=parseInt(p)+parseInt(q);
              }
              
              let text="";
              if(a>b){
                text= "Correct values";
              }else {
                text= "not Correct values";
              }
               document.getElementById('demo4').innerHTML=text;
         }  
         </script>
      </body>