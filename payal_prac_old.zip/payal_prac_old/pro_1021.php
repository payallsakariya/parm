<!-- 21. Write a  Program that read 5 numbers and counts the number of positive numbers and negative numbers.  
      Test Data :
      Input the first number: 5
      Input the second number: -4
      Input the third number: 10
      Input the fourth number: 15
      Input the fifth number: -1
      Expected Output:
      Number of positive numbers: 3
      Number of negative numbers: 2
-->


<html>
  <body>
    <form>
      <table>
        <tr>
          <td>
            <label for="1">Enter the first number :</label>
          </td>
          <td>
            <input type="text" id="1" name="first_no" onblur="myfunction()">
          </td>
        </tr>
        
        <tr>
        <td>
            <label for="2">Enter the second number :</label>
          </td>
          <td>
            <input type="text" id="2" name="second_no" onblur="myfunction()">
          </td>
        </tr>
        
        <tr>
         <td>
            <label for="3">Enter the third number :</label>
          </td>
          <td>
            <input type="text" id="3" name="third_no" onblur="myfunction()">
          </td>
        </tr>
         
         <tr>
         <td>
            <label for="4">Enter the fourth number :</label>
          </td>
          <td>
            <input type="text" id="4" name="fourth_no" onblur="myfunction()">
          </td>
        </tr>

         <tr>
         <td>
            <label for="5">Enter the  fifth number :</label>
          </td>
          <td>
            <input type="text" id="5" name="fifth_no" onblur="myfunction()">
          </td>
        </tr>
      
      </table>
    </form>
    <p id="demo"></p>
    <p id="demo1"></p>
    
   <script>
     function myfunction(){
       var inputodd=0;
       var inputeven=0;
       for(let i = 1; i <= 5; i++){
          var nums = document.getElementById(i);
              if (nums) {
                if(parseInt(nums.value) % 2 == 0){
                  inputodd += parseInt(1);
                
                }else{
                  inputeven += parseInt(1);
                
                }
              }
         }  
         document.getElementById('demo').innerHTML=inputodd;
         document.getElementById('demo1').innerHTML=inputeven;
     }
   </script>
    
  </body>
</html>

