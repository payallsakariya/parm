<html>
  <body>
   <form method='post'>
          <label for='num'> Enter no of terms : </label>
          <input type='text' id='num' name='num'>
          <input type='submit' name='Submit'>
   </form>
   <?php
   
       $number=$_POST['num'];
       $strlen=strlen($number);
       $num_array=array();
       for($i=0;$i<=$strlen;$i++){
     
           array_push($num_array,$number[$i]);
        }
        $List = implode('  ', $num_array);
        print_r($List);
        
   ?>
   
   
   </body>
</html>