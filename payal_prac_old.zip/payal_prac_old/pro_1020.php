<html>
  <body>
    <!--<input type="button" name="butt" onclick="myfunction()">-->
    
    <p>even numbers [0-50]</p>
    <button type="button" id="butt" onclick="myfunction()">click me</button>
     <p id="demo"></p>
  
  </body>
  <script>
    function myfunction(){
      var text=" ";
      for(var i=1; i<=50; i++){
        if(i%2==0){
           text += i+' ';
        }
      }
      document.getElementById('demo').innerHTML=text;
    }
  </script>
</html>