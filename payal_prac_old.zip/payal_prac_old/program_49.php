<!-- 
49. Write a  Program that swaps two numbers without using third variable.  
Input value for x & y:
Before swapping the value of x & y: 5 7
After swapping the value of x & y: 7 5


-->

<html>
  <body>
   <form method='post'>
          <label for='x'> enter vale of X & Y : </label>
          <input type='text' id='x' name='x'>
          <input type='submit' name='Submit'>
   </form>
   <?php
   
      //$swp=array();
       $number=$_POST['x'];
       $strlen=strlen($number);
       $num_array=array();
       for($i=0;$i<=$strlen;$i++){
     
           array_push($num_array,$number[$i]);
        }
        $List = implode('  ', $num_array);
        echo "Before swapping the value of x & y : ";
        print_r($List);
        
        $swp=array_reverse($num_array);

         $List1 = implode('  ', $swp);
        echo "<br>After swapping the value of x & y : ";
        print_r($List1);
       
    ?>
    </body>
</html>