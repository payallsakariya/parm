<html>
  <body>
    <input type="text" id="demo" onkeyup="keyupFunction()">
    <script>
    document.getElementById("demo").onkeydown = function() {keydownfun()}
      function keydownfun(){
        document.getElementById("demo").style.backgroundColor="red";
      }
    </script>
  </body>
</html>