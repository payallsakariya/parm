<!--
76. Write a  Program that takes some integer values from the user and print a histogram.  
Sample Output:
Input number of histogram bar (Maximum 10):
4
Input the values between 0 and 10 (separated by space):
9
7
4
3


Histogram:
#########
#######
####
###


-->
<html>
  <body>
    <form method="post">
      <label for="no1"> Enter number : </label>
      <input type="text" id='no1' name='no1'>
      <br><br>
      <input type="submit" name="Submit">
    </form>
    
    <?php
    
       $num=$_POST['no1'];
        for($i=1;$i<5;$i++){
              if($i<4){     
                for($j=$num-=$i;$j>=1;$j--){
                  echo "#";
                  }
              }else {
                 for($j=$num-=1;$j>=1;$j--){
                  echo "#";
                     }
                   }
          echo "<br>";
          
        }
    
    ?>
</body>
</html>