<?php
$myfile = fopen("/testfile.txt", "w");
// $myfile1 = fopen("/testfile.txt", "w+") or die("Unable to open file!");
$txt = "hello";
$my= fopen("/testfile.txt","r+");
fwrite($myfile1, $txt);
$txt = "hi";
fwrite($myfile1, $txt);
$txt ="welcom";
fwrite($myfile,$txt);

fclose($myfile1);
echo readfile("testfile.txt");
?>
