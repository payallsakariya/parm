<!--
119. Write a  Program to calculate the sum all numbers between two given numbers (inclusive) not divisible by 7.  
Sample Output:
Input two numbers(integer):
25
5
Sum of all numbers between said numbers (inclusive) not divisible by 7:
273


-->

<html>
  <body>
    <form method="post" target="_top">
      <table>
        <tr>
          <td>
            <label for="f_number">Enter first number :</label>
          </td>
          <td>
            <input type="text" id="f_number" name="f_number">
          </td>
        </tr>
        
        
        <tr>
          <td>
            <label for="s_number">Enter second number :</label>
          </td>
          <td>
            <input type="text" id="s_number" name="s_number">
          </td>
        </tr>
        
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
        
      </table>
    </form>
    <?php 
     $f_number =$_POST["f_number"];
     $s_number =$_POST["s_number"];
    $num_array=array();
    if($f_number<$s_number){
       for($i=$f_number;$i<$s_number;$i++){
         //print_r($i);
         if($i%7 !== 0)
         {
           array_push($num_array,$i);
          // echo $i."<br>";
        
         }
       }
    }
   echo"<br>Sum of all numbers between said numbers (inclusive) not divisible by 7  : ". array_sum($num_array);
    ?>
  </body>
</html>

