<!--
118. Write a  Program that reads five subject marks (0-100) of a student and calculate the average of these marks.  
Sample Output:
Input five subject marks(0-100):
75
84
56
98
68
Average marks = 76.20

-->
<html>
      <body>
        <form method='post'>
          <table>
            <tr>
              <td>
                 <label for='no1'> Enter 1 subject marks : </label>
              </td>
              <td>
                <input type='text' id='no1' name='no1'>
              </td>
            </tr>
            
             <tr>
              <td>
                 <label for='no2'> Enter 2 subject marks: </label>
              </td>
              <td>
                <input type='text' id='no2' name='no2'>
              </td>
            </tr>
            
             <tr>
              <td>
                 <label for='no3'> Enter 3 subject marks : </label>
              </td>
              <td>
                <input type='text' id='no3' name='no3'>
              </td>
            </tr>
            
            <tr>
              <td>
                 <label for='no4'> Enter 4 subject marks : </label>
              </td>
              <td>
                <input type='text' id='no4' name='no4'>
              </td>
            </tr>
            
            <tr>
              <td>
                 <label for='no5'> Enter 5 subject marks : </label>
              </td>
              <td>
                <input type='text' id='no5' name='no5'>
              </td>
            </tr>
            <tr>
              <td>
                 <input type='submit' name='Submit'>
              </td>
            </tr>
            
          </table>
             
        </form>
      </body>
    </html>
    
    
    <?php 
    
        $number1 = $_POST['no1'];
        $number2 = $_POST['no2'];
        $number3 = $_POST['no3'];
        $number4 = $_POST['no4'];
        $number5 = $_POST['no5'];
        $num_array=array($number1,$number2,$number3,$number4,$number5);
        $array_sum=array_sum($num_array);
        echo "Average marks ".$array_sum/5;
        ?>