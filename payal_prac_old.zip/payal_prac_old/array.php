<html>
  <style>
    table,tr,td{
      border: 2px solid black;
    }
  </style>
  <body>
    <table>
      <tr>
        <td><h>rsort_Fun</h></td>
        <td>
          <?php 
             $car=array("BMW","toyota","volvo");
              rsort($car);
              
              //echo $car[0],"<br>".$car[1],"<br>".$car[2],"<br><br>";
              $carlength=count($car);
              for($a=0;$a<$carlength;$a++){
                echo $car[$a]."<br>";
                
              }
              echo "<br>fav_car is :- ".$car[1];
          ?>
          
        </td>
        </tr>
        
      <tr>
        <td>krsort_Fun</td>
        <td>
          <?php 
           $salary=array("priya"=>"45000","Dev"=>"50000","diya"=>"24000");
             krsort($salary);
             foreach ($salary as $x=>$x_value){
               echo "key  = " .$x ." , value = ".  $x_value;
               echo "<br>";
             }
             print_r(array_values($salary));
             
          ?>
        </td>
      </tr>
      <tr>
        <td>array_combine</td>
        <td>
          <?php 
           $sal_name=array("priya","dev","diya");
           $sal_value=array("23000","30000","40000");
             $a=array_combine($sal_name,$sal_value);
              print_r($a);
          
          ?>
        </td>
      </tr>
      <tr>
        <td>
          array_count_values
        </td>
        <td>
        <?php
          $s_name=array("priya","dev","payal","dev","priya");
          print_r(array_count_values($s_name));
        
        ?>
      </td>
      </tr>
      <tr>
        <td>array_diff</td>
        <td><?php 
              $a1=array("a"=>"white","b"=>"green","c"=>"blue","d"=>"yellow");
              $a2=array("a"=>"red","b"=>"black","c"=>"blue","d"=>"yellow");
               print_r(array_diff($a1,$a2))."<br>";
               //print_r(array_fill(0,2,"red"));  
                 
                 
             /* function myfunction($a,$b)
              {
                       if ($a===$b)
              {
              return 0;
              }
              return ($a>$b)?1:-1;
            }
       print_r( myfunction($a2,$a1));*/
        

        ?></td>
      </tr>
      <tr>
        <td>array_flip</td>
        <td>
          <?php
          $a1=array("a"=>"white","b"=>"green","c"=>"blue","d"=>"yellow");
          print_r(array_flip($a1));
          ?>
          </td>
      </tr>
    </table>
  </body>
</html>
