<!-- 2. Write a  program to take input of two numbers, and find their sum, product and sum of the squares.
 -->

<html>
  <body>
    <form action="action_pro2.php" method="post" target="_top">
      <table>
        <tr>
          <td>
            <label for="no1">enter number 1 :- </label>
          </td>
          <td>
            <input type="text" id="no1" name="no1" required>
          </td>
        </tr>
        
         <tr>
          <td>
            <label for="no2">enter number 2 :- </label>
          </td>
          <td>
            <input type="text" id="no2" name="no2" required>
          </td>
        </tr>
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
        
      </table>
    </form>
  </body>
</html>
