
<!DOCTYPE html>

<!-- 1 Write a program to input and print your name, date of birth. and mobile number. 
        Expected Output: 
        Name   : Alexandra Abramov  
        DOB    : July 14, 1975  
        Mobile : 99-9999999999 -->
<html>

    <body>
        <form action="action_pro1.php" method="post" target="_blank">
            <center>
            <table>
               
                    <td>  
                       <label for="fname">Name  </label>
                    </td>
                    <td>
                        <input type="text" id="fname" name="fname"  required>
                    </td>
                </tr>
                
                
                <tr>
                    <td>
                        <label for="brith">DOB : </label>
                    </td>
                    <td>    
                        <input type="date" id="brith" name="brith" required>
                    </td>
                </tr>
                
                
                <tr>
                    <td>      
                       <label for="phone">Mobile : </label>
                    </td>
                    <td>
                        <input type="tel" id="phone" name="phone" placeholder="9872635467"                                 pattern="[0-9]{10}" required >
                    </td>
                </tr>
            
                
                <tr>
                    <td>
                        <input type="submit" value="Submit">
                        
                    </td>
                </tr>
            
            </table>
            </center>
            </form>
    </body>
</html>