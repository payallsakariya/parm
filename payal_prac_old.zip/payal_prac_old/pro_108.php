<!--8. Write a  Program to convert specified days into years, weeks and days.  
        Note: Ignore leap year.
        
        Test Data :
        Number of days : 1329
        Expected Output :
        Years: 3
        Weeks: 33
        Days: 3
-->

<html>
  <body>
    <form method="post">
      <table>
        <tr>
          <td>
            <label for="dgt">Number of days : </label>
          </td>
          <td>
            <input type="text" id="dgt" name="dgt" onblur="myfunction()">
          </td>
        </tr>
      </table>
    </form>
    <p id="demo"></p>
    <br>
    <p id="demo1"></p>
    <br>
    <p id="demo2"></p>
    <br>
    <p id="demo3"></p>
    
    <script>
      function myfunction(){
        var num = document.getElementById("dgt").value;
        document.getElementById('demo').innerHTML = num;
            var y= num / 365;
            var y1=parseInt(y);
            var Y=365*y1;
            var w1=num-Y;
            var w2=w1/7;
            var w3=parseInt(w2);
            var W=w3*7;
            var d1=num-Y-W;
            document.getElementById('demo1').innerHTML ="Years : "+ y1;
          document.getElementById('demo2').innerHTML = "Weeks : "+w3;
          document.getElementById('demo3').innerHTML ="Days :"+ d1;
            
          
      }
    </script>
    
  </body>
</html>
