<html>
  <body>
    <form method="post">
      <label for="number"> Enter value : </label>
      <input type="text" id='number' name='number'>
      <input type="submit" name="Submit">
    </form>
  </body>
</html>
    <?php 
        $number=$_POST['number'];
        //echo $number;
        $number1=array();
        for($i=1;$i<=$number;$i++){
          for($j=1;$j<=$number;$j++){
            if($i*$j==$number){
              array_push($number1,$i);
            }
          }
          
        }
        //print_r($number1);
        $count=count($number1);
        for($i=0;$i<=$count;$i++){
          echo  $number1[$i];
          echo "<br>";
        }
        ?>