<!--
141. Write a  Program that reads n digits (given) chosen from 0 to 9 and prints the number of combinations where the sum of the digits equals to another given number (s). Do not use the same digits in a combination.  
For example, the combinations where n = 3 and s = 6 are as follows:
1 + 2 + 3 = 6
0 + 1 + 5 = 6
0 + 2 + 4 = 6
Sample Output:
Input the number:
3

Sum of the digits:
6
Number of combinations: 3
-->
<html>
  <body>
    <form method='post'>
      <label for='no'> Enter Number : </label>
      <input type='text' id='no' name='no'>
      <br>
      <label for='num'> Enter Number of sum: </label>
      <input type='text' id='num' name='num'>
      <br>
      <input type='submit' name='Submit'>
    </form>
    <?php
    
      $num=$_POST['num'];
      $numer=$_POST['no'];
      echo "<br>Number of combinations : ".$numer;
      echo "<br>Sum of the digits : ".$num;
    if($numer==3){
      for($p=0;$p<$num;$p++){
        for($q=0;$q<$num;$q++){
          for($r=0;$r<$num;$r++){
             $sum=$p+$q+$r;
             if($sum==$num){
               echo "<br>".$p."+".$q."+".$r."=".$sum;
             }
          }
        }
      }
    }  
   ?>
</body>   
</html>