<!--

43. Write a  Program to read an array of length 5 and print the position and value of the array elements of value less than 5.  
Test Data:
Input the 5 members of the array:
15
25
4
35
40
Expected Output:
A[2] = 4.0

-->
 <html>
    <body>
      <form method='post'>
        <table>
          <tr>
            <td>
              <label for='num'> Enter 5 numbers of array value : </label>
            </td>
            <td>
             <input type='text' id='num' name='no1'>
             </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <input type='text' id='num' name='no2'>
            </td>
          </tr>
          
          <tr>
            <td></td>
            <td>
              <input type='text' id='num' name='no3'>
            </td>
          </tr>
          
          <tr>
            <td></td>
            <td>
              <input type='text' id='num' name='no4'>
            </td>
          </tr>
          
          <tr>
            <td></td>
            <td>
              <input type='text' id='num' name='no5'>
            </td>
          </tr>
          
        <tr>
          <td>
            <input type='submit' name='Submit'>
          </td>
        </tr>
        
        
        </table>
      </form>
    </body>
  </html>
  <?php
       
         $number1=$_POST['no1'];
        $number2=$_POST['no2'];
        $number3=$_POST['no3'];
        $number4=$_POST['no4'];
       $number5=$_POST['no5'];
       
        $number_array=array($number1,$number2,$number3,$number4,$number5);
        $count=count($number_array);
         $no=$count;
         
         //echo $no;
         for($i=1;$i<$no;$i++){
          // echo "<br>".$number_array[$i];
          if($number_array[$i]<$no){
            echo "<br>A[$i] =".$number_array[$i];
          }
          
          
         }
        
  ?>