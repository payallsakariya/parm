<!--
129. Write a  Program that reads an array (length 10), and replace the first element of the array by a give number and replace each subsequent position of the array by one-third value of the previous.  
Sample Output:
Input an integer (2-10)
8
array_nums[0] = 0
array_nums[1] = 1
array_nums[2] = 2
array_nums[3] = 3
array_nums[4] = 4
array_nums[5] = 5
array_nums[6] = 6
array_nums[7] = 7
array_nums[8] = 0


-->
<html>
  <body>
    <form method="post">
      <table>
        <tr>
          <td>
            <label for="num">enter number</label>
          </td>
          <td>
            <input type="text" id="num" name="num">
          </td>
        </tr>
        <tr>
          <td>
            <input type="submit" name="Submit">
          </td>
        </tr>
      </table>
    </form>
    
    <?php
     
       $num=$_POST['num'];
       $k=0;
       $j=0;
    
       for($i=0;$i<=$num;$i++){
         if($i<$num){
           echo "<br>array_nums[$i] = ".$k;
           $k++;
         }else {
           echo "<br>array_nums[$i] = ".$j;
          
         }
       }
       
      ?>
</body>
</html>
