<!-- 
3. Write a program to input n numbers and print their sum and largest number without storing them in an array.


-->

<html>
  <body>
     <form  method="post">
      <table>
        <tr>
          <td>
            <label for="no1">Input the first integer:</label>
          </td>
          <td>
            <input type="text" id="no1" name="no1">
          </td>
        </tr>
        <tr>
          <td>
            <label for="no2">Input the second integer:</label>
          </td>
          <td>
            <input type="text" id="no2" name="no2">
          </td>
        </tr>
        
        <tr>
          <td>
            <label for="no3">Input the third integer:</label>
          </td>
          <td>
            <input type="text" id="no3" name="no3">
          </td>
        </tr>
        
        
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
      </table>
    </form>
    
    <?php 
   
    $a=$_POST["no1"];
    $b=$_POST["no2"];
    $c=$_POST["no3"];
    $ans=array("$a","$b","$c");
    print_r($ans);
    echo "<br><br> array sum is :-";
    print_r(array_sum($ans));
    echo "<br><br> array Maximum value :-";
    print_r(max($ans));
// print_r $arry=array([0]=>$_POST["no1"],[1]=>$_POST["no2"],[2]=>$_POST["no3"]);
    ?>
  </body>
</html>