<html>
  <body>
    <h1>JavaScript Operators</h1>
    <p id="add"></p>
    <p id="sub"></p>
    <p id="mul"></p>
    <p id="div"></p>
    <p id="mod"></p>
   
    <script>
      var x=30;
      var y=20;
      
      
      
   document.getElementById("add").innerHTML = "<br>addition of x & y : " + (x+y);
   document.getElementById("sub").innerHTML = "<br>Subtraction of X & y : " + (x-y); 
   document.getElementById("mul").innerHTML = "<br>Multiplication of x & y : "+(x*y); 
   document.getElementById("div").innerHTML = "<br> Divisionof x & y : "+(x/y);
   document.getElementById("mod").innerHTML = "<br>Modulus of x & y : "+ (x%y);
    </script>
  </body>
</html>
