<!--
64. Write a  Program to calculate and prints the squares and cubes of the numbers from 0 to 20 and uses tabs to display them in a table of values.  
Sample Output:
Number Square Cube
=========================
0 0 0
1 1 1
2 4 8
3 9 27
.....
18 324 5832
19 361 6859
20 400 8000

-->
<html>
  <body>
    <form method="post">
      <label for="no1"> Enter value 1</label>
      <input type="text" id='no1' name='no1'>
      <br><br>
      <input type="submit" name="Submit">
    </form>
             
      <?php 
        $a=$_POST['no1'];
        
       
       
        echo "Number Square Cube<br>=========================<br><br>";
       
         for($i=0;$i<=$a;$i++){  
               for($j=1;$j<4;$j++){  
                   echo  pow($i,$j)." ";
                   }  
                  
                 echo "<br>";  
               } 
        ?>
  </body>
  </html>