<!-- 
48. Write a  Program that accepts a distance in centimeters and prints the corresponding value in inches.  
Test Data:
Input Data: 500cms
Input the distance in cm:
Distance of 500.00 cms is = 196.85 inches

-->
<html>
  <body>
   <form method='post'>
          <label for='num'> distance in centimeters  : </label>
          <input type='text' id='num' name='num'>
          <input type='submit' name='Submit'>
   </form>
   <?php
   
       $centimeters=$_POST['num'];
       $inches=($centimeters/2.54);
       echo "Distance of  ".$centimeters." cms is =".$inches;
       
    ?>
    </body>
</html>