<!-- 13. Write a  Program to convert a given integer (in days) to years, months and days assuming that all months have 30 days and                   all years have 365 days.  
        Test Data:
        Input no. of days: 2535
        Expected Output:
        6 Year(s)
        11 Month(s)
        15 Day(s)
         
        -->

<html>
  <body>
    <form >
      <table>
        <tr>
          <td>
            <label for="ndays">Number of days : </label>
          </td>
          <td>
            <input type="text" id="ndays" name="ndays" onblur="myfunction()">
          </td>
        </tr>
      </table>
      <P id="demo"></P>
      <P id="demo1"></P>
      <P id="demo2"></P>
      <P id="demo3"></P>
    </form>
    <script>
      function myfunction(){
        var n_days=document.getElementById('ndays').value;
        document.getElementById('demo').innerHTML= " Test Data :<br>"+" Number of days : "+n_days;
        
            var y= n_days / 365;
            var years=parseInt(y);
            var Y=365*years;
            var w1=n_days-Y;
            var w2=w1/30;
            var months=parseInt(w2);
            var W=months*30;
            var days=n_days-Y-W;
            
         document.getElementById('demo1').innerHTML="Years : " + years;
         document.getElementById('demo2').innerHTML="Month : " + months;
         document.getElementById('demo3').innerHTML="Days : " + days;    
      }
    </script>
  </body>
</html>
