<!--
74. Write a  Program to replace more than one blanks with a single blank in a input string.  
Sample Output:
Input a string and get number of charcters, words and lines:
The quick brown fox jumps over the lazy dog
^Z

Number of Characters = 44
Number of words = 9
Number of lines = 1
-->
 <html>
      <body>
        
        <form method='post'>
          <table>
            <tr>
              <td>
                <label for='str'> Enter string: </label>
              </td>
              <td>
                <input type="text" id="str" name="str">
              </td>
            </tr>
            
            <tr>
              <td></td>
              <td>
                <br>
                <input type="submit" name="Submit1">
              </td>
            </tr>
          </table>
        </form>
      </body>
    </html>
    <?php
    
    $_POST['str'];
  $str="The quick brown fox jumps over the lazy dog";
        echo $str."<br>";
        // echo ord("a");
        echo "<br>Number of words = ".str_word_count($str);
        echo "<br>Number of Characters = ".strlen($str);
          // for()
        
        
    ?>