<html>
  <body>
    <?php
        $x=15;
        $y=10;
        echo "Addition is :-".$a =$x + $y;
        echo "<br>Subtraction is :-".$a =$x - $y;
        echo "<br> Multiplication is :-".$a =$x * $y;
        echo "<br>Division is :-".$a =$x / $y;
        echo "<br> Modulus is :-".$a =$x % $y;
        
      ?>
    
  </body>
</html>
