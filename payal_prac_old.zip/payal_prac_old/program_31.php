<!--
31. Write a program that reads two numbers and divide the first number by second number. If the division not possible print "Division not possible".  
Test Data :
Input two numbers:
x: 25
y: 5
Expected Output: 5.0



-->

<html>
  <body>
    <form method="post" target="_top">
      <table>
        <tr>
          <td>
            <label for="f_number">Enter X value :</label>
          </td>
          <td>
            <input type="text" id="f_number" name="f_number">
          </td>
        </tr>
        
        
        <tr>
          <td>
            <label for="s_number">Enter. Y value :</label>
          </td>
          <td>
            <input type="text" id="s_number" name="s_number">
          </td>
        </tr>
        
        <tr>
          <td>
            <input type="submit" value="Submit">
          </td>
        </tr>
        
      </table>
    </form>
    <?php 
    $x =$_POST["f_number"];
    $y =$_POST["s_number"];
    
  
     if($x>$y){
       echo $div=$x/$y;
     }else {
       echo "Division not possible";
     }
     
    
   
    
    ?>
  </body>
</html>


