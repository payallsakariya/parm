<?php
date_default_timezone_set('Asa/Kolkata');
session_start();
class report {
	private $conectar;
	private $Connection;
	private $base_url;


	function __construct() {

		require_once __DIR__ . "/../core/Conectar.php";
		require_once __DIR__ . "/../model/report_model.php";
		$this->conectar = new Conectar();
		$this->model = new report_model();
		$this->base_url = base_url;
		$this->Connection = $this->conectar->Connection();
	}

	function All_report() {
		include 'views/report/dailyreport.php';
	}
	
	function report_Daily_json(){
		// echo "ohh";
		$pid=$_POST['pid'];
	$form_d=$_POST['form_date'];
	$to_d=$_POST['to_date'];
	$asdate1=date('Y-m-d', strtotime($form_d));
  $afdate1=date('Y-m-d', strtotime($to_d));
  if($_POST['report_type'] == 'daily'){
  	      $query="SELECT m.`pid`, date_format( m.`date`,'%d-%m-%Y') as date,date_format(m.date,'%l:%i-%p') as time ,m.`charge`,p.`pid`, upper(concat (p.pfname,' ',p.pmname,' ',p.plname)) as Name, concat(p.age,'-',p.ym) as age,p.gender FROM patients p join practices m on m.`pid`=p.`pid`  where  (m.`status`='payment')";

//if date is blank .......
if($form_d == '' && $to_d == '')
		{
		}
		else
		{
			$query .=" and (date_format( m.`date`,'%Y-%m-%d') >= '$asdate1' and   date_format( m.`date`,'%Y-%m-%d')  <= '$afdate1')";
		}
		
		//if patient is blank.......
		if($pid == '')
		{
		}
		else
		{
			$query .= " and m.`pid` = '$pid' ";
		}
 
    $query .=" order by m.`date`";
    $ifnal_sql = $query;
// echo $query;
  }elseif ($_POST['report_type'] == 'consultation') {
							  	     $s = "Select p.pid,c.`consult_id`, upper(concat (p.pfname,' ',p.pmname,' ',p.plname)) as Name, concat(p.age,'-',p.ym) as age,p.gender,date_format(c.`formatdate`,'%d-%m-%Y') as date,c.`provisional_diagnosis`,c.`observation`, c.`suggestion` FROM medprack_consults c join patients p on p.`pid`=c.`pid` ";
							
							//if date is blank .......
							if($form_d == '' && $to_d == '')
							{
							}
							else
							{
								$s .=" WHERE (date_format(c.`formatdate`,'%Y-%m-%d') BETWEEN '$asdate1' AND '$afdate1')";
							}
							
							//if patient is blank.....
							if($pid == '')
							{
							}
							else
							{
								$s .= " and p.`pid` = '$pid' ";
							}
							$ifnal_sql = $s;

  }else{
  	 $s = "SELECT p.`pid`,upper(concat (p.pfname,' ',p.pmname,' ',p.plname)) as Name, concat(p.age,'-',p.ym) as age,p.gender,date_format(a.`date_of_admission`,'%d-%m-%Y') as date_of_admission, a.`time_of_admission`, d.`diagnosis`, date_format(d.`oprationdate`,'%d-%m-%Y') as oprationdate, date_format(d.`dischargedate`,'%d-%m-%Y') as dischargedate, d.`operation`, d.`op_starttime`, d.`op_endtime`, d.`findings`,a.`admission_id`, d.`advice_on_dis`, d.`investigation_detail_dis`, d.`condition_on_dis`,d.`dischargeid`, d.`caseid`, d.`admissionid`,d.`operated` FROM discharges d join admissions a on a.`admission_id`= d.`dischargeid` join practices m on d.`caseid`=m.`id` join patients p on m.`pid`=p.`pid` ";


//if date is blank .......
if($form_d == '' && $to_d == '')
{
}
else
{
	$s .="WHERE (date_format(d.`dischargedate`,'%Y-%m-%d') BETWEEN '$asdate1' AND '$afdate1')";
}
//if patient is blank....
if($pid == '')
{
}
else
{
	$s .= " and p.`pid` = '$pid' ";
}
// echo $s;exit;
$ifnal_sql=$s;
  }
 
 $dailyEx= $this->model->Select($ifnal_sql);
 	 $data['data'] = $dailyEx['Data'];
 	 $array = json_decode(json_encode($data), true);
 	 echo json_encode($array);
	}
	
	
// 	function report_Consultation() {
// 		// echo "report_Consultation";exit;
// // if(isset($_POST['search'])){
// // 	echo "search";exit;
// // }
// 		include 'views/report/dailyreport.php';
// 	}
// 	function report_Discharge() {
// 		echo "report_Discharge";exit;
// if(isset($_POST['search'])){
// 	echo "search";exit;
// }
// 		include 'views/report/dailyreport.php';
// 	}

function patient_name(){
	$value = $_POST['q'];
		$sql="SELECT upper(concat(v.pfname,' ',v.pmname,' ',v.plname)) as Name,v.`pid` , v.pmshid FROM patients  v WHERE concat(v.pfname,' ',v.pmname,' ',v.plname, '') LIKE '$value%' or v.contact like '%$value%'or pmshid like '%$value%' ORDER BY v.pfname";
		
  	 $selectEx= $this->model->Select($sql);
	 	 $data['data'] = $selectEx['Data'];
 	   $array = json_decode(json_encode($data), true);
 	  echo json_encode($array);
} 
}
?>