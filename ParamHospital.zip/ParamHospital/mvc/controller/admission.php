<?php
date_default_timezone_set('Asa/Kolkata');
session_start();

class admission{

	  public $table = "patients";
     public $table1 = "practices";
     public $table2 = "prescriptions";
     public $table3 = "complains";
		 private $conectar;
     private $Connection;
     private $base_url;
		
							    function __construct() {
							        require_once  __DIR__ . "/../core/Conectar.php";
                      require_once  __DIR__ . "/../model/admission_model.php";
                      $this->conectar=new Conectar();
									    $this->model=new admission_model();
									    $this->base_url = base_url;
									    $this->Connection=$this->conectar->Connection();
						       }
	
 function AdmitPatient(){
	   $pid = $_GET['p_id'];

	  if(isset($_GET['updeta_p_id'])){
	  	// echo $_GET['updeta_p_id'];exit;
	  	  $pid = $_GET['updeta_p_id'];
	  	  $updeta_p_id = $_GET['updeta_p_id'];
	  	  // echo "pid".$pid;
	    }

	 	$sql="SELECT patients.pid,patients.contact,upper(concat (patients.pfname,' ',patients.pmname,' ',patients.plname)) as Name,patients.age,patients.gender,DATE_FORMAT(practices.date,'%d-%m-%Y')as date,practices.caseid,practices.id FROM patients INNER JOIN practices ON patients.pid = practices.pid WHERE practices.pid=$pid ORDER BY practices.id DESC LIMIT 1";
// echo $sql;exit;
	 	     $Alldata = $this->model->Select($sql);
	 	     //print_r($Alldata);exit;
    		 $_SESSION['admitpatient']=$Alldata['Data'][0];
    	
    		
       $sql1="SELECT * FROM `consults` WHERE pid = $updeta_p_id ORDER BY consults.consult_id DESC LIMIT 1";
     //echo $sql1;exit;
       $All_data = $this->model->Select($sql1);
	     $_SESSION['admitpatient_consults']=$All_data['Data'][0];
	    
	    
    		
    		  if(isset($_GET['cancel'])){
    		  	 //$and="DATE_FORMAT(complains.date,'%Y-%m-%d') = CURDATE()";
    		  	$deleteEx= $this->model->Delete($this->table3,['id'=>$this->model->htmlValidation($_GET['cancel'])],$and);
    		  	 if($deleteEx == 1){
    		  	   $url = $this->base_url.'patient/pending_cases';
				 			  header("Location: $url");
    		  	 }
    		  }
    		  
    		  if(isset($_GET['cancel_add'])){
    		  	        unset($_SESSION['admitpatient']);
    		  	       $url = $this->base_url.'admission/admission_pending';
                   header("Location: $url");
    		  }
    		  if(isset($_POST['Save'])){
    		  $date= date('Y-m-d',strtotime($_POST['date']));
    		  $pc_id=$_POST['s_id'];
    		 		$insert_data = [
			                'pid' => mysqli_real_escape_string($this->Connection,$_POST['pid']),
			                'caseid' => mysqli_real_escape_string($this->Connection,$pc_id),
			                'formatdate' => mysqli_real_escape_string($this->Connection,$date),
			                'past_history' => mysqli_real_escape_string($this->Connection,$_POST['past_history']),
			                'personal_history' => mysqli_real_escape_string($this->Connection,$_POST['personal_history']),
			                'family_history' => mysqli_real_escape_string($this->Connection,$_POST['family_history']),
			                'alergy' => mysqli_real_escape_string($this->Connection,$_POST['Allergy']),
			                'provisional_diagnosis' => mysqli_real_escape_string($this->Connection,$_POST['Provisional_Diag']),
			                'charge' => mysqli_real_escape_string($this->Connection,$_POST['Charge']),
			                'suggestion' => mysqli_real_escape_string($this->Connection,$_POST['suggestion']),
			                't' => mysqli_real_escape_string($this->Connection,$_POST['t']),
			                'bp' => mysqli_real_escape_string($this->Connection,$_POST['bp']),
			                'p' => mysqli_real_escape_string($this->Connection,$_POST['p']),
			                'rs' => mysqli_real_escape_string($this->Connection,$_POST['rs']),
			                'pa' => mysqli_real_escape_string($this->Connection,$_POST['pa']),
			                'rbs' => mysqli_real_escape_string($this->Connection,$_POST['rbs']),
			                'cvs' => mysqli_real_escape_string($this->Connection,$_POST['cvs']),
			                'cns' => mysqli_real_escape_string($this->Connection,$_POST['cns']),
			                'spo2' => mysqli_real_escape_string($this->Connection,$_POST['spo2']),
			                'tounge' => mysqli_real_escape_string($this->Connection,$_POST['tounge']),
			                'Observation' => mysqli_real_escape_string($this->Connection,$_POST['Observation'])
			                // 'Date' => $timetamp
			              ];
// echo"<pre>";
// print_r($insert_data);exit;
		      $insertcEx= $this->model->InsertData('consults',$insert_data);
		    if($insertcEx['Code'] == 1){
		    	$update_data=[
			                'status' =>'admit',
			              ];
			              $and="id = $pc_id";
		    	$updata = $this->model->UpdateData($this->table1,$update_data,['caseid'=>$this->model->htmlValidation($_POST['caseid'])],$and);
		    	
		    	if($updata['Code'] == 1){
		    		       unset($_SESSION['admitpatient']);
		    		       
		    		 if($_SESSION['type'][0]== 'doctor'){
		    		        $url = $this->base_url.'patient/completed';
				 			      header("Location: $url");
		    		 }else{
		    		 			 unset($_SESSION['admitpatient']);
		    		 	     $url = $this->base_url.'admission/admission_pending';
				 			       header("Location: $url");
		    		 }
					     
		    	}
				}else{
			          $url = $this->base_url.'admission/AdmitPatient?p_id='.$pid;
				 			  header("Location: $url");
				}
		      
		      
    		 }
    	
    		 if(isset($_GET['cancel_up'])){
    		 	 unset($_SESSION['admitpatient_consults']);
    		  	$url = $this->base_url.'patient/completed';
    		  	header("Location: $url");
    		  }
    		  
    		  if(isset($_POST['Update'])){
    		  	$c_up_id = $_POST['consult_id'];
    		 		$updateData = [
			                'past_history' => mysqli_real_escape_string($this->Connection,$_POST['past_history']),
			                'personal_history' => mysqli_real_escape_string($this->Connection,$_POST['personal_history']),
			                'family_history' => mysqli_real_escape_string($this->Connection,$_POST['family_history']),
			                'alergy' => mysqli_real_escape_string($this->Connection,$_POST['Allergy']),
			                'provisional_diagnosis' => mysqli_real_escape_string($this->Connection,$_POST['Provisional_Diag']),
			                'charge' => mysqli_real_escape_string($this->Connection,$_POST['Charge']),
			                'suggestion' => mysqli_real_escape_string($this->Connection,$_POST['suggestion']),
			                't' => mysqli_real_escape_string($this->Connection,$_POST['t']),
			                'bp' => mysqli_real_escape_string($this->Connection,$_POST['bp']),
			                'p' => mysqli_real_escape_string($this->Connection,$_POST['p']),
			                'rs' => mysqli_real_escape_string($this->Connection,$_POST['rs']),
			                'pa' => mysqli_real_escape_string($this->Connection,$_POST['pa']),
			                'rbs' => mysqli_real_escape_string($this->Connection,$_POST['rbs']),
			                'cvs' => mysqli_real_escape_string($this->Connection,$_POST['cvs']),
			                'cns' => mysqli_real_escape_string($this->Connection,$_POST['cns']),
			                'spo2' => mysqli_real_escape_string($this->Connection,$_POST['spo2']),
			                'tounge' => mysqli_real_escape_string($this->Connection,$_POST['tounge']),
			                'Observation' => mysqli_real_escape_string($this->Connection,$_POST['Observation'])
			                // 'Date' => $timetamp
			              ];
		     	$updata = $this->model->UpdateData('consults',$updateData,['consult_id'=>$this->model->htmlValidation($_POST['consult_id'])],$and);
		   
		    	if($updata['Code'] == 1){
		    		 unset($_SESSION['admitpatient_consults']);
		    		 
		    		  if($_SESSION['type'][0]== 'doctor'){
		    		       $url = $this->base_url.'patient/completed';
							  header("Location: $url");
		    		 }else{
		    		 			 unset($_SESSION['admitpatient_consults']);
		    		 	     $url = $this->base_url.'admission/admission_pending';
				 			       header("Location: $url");
		    		 }
		    		 
		    	}
				}
		      
		      
    		 
    		 
		include 'views/admission/consultform.php';
}

  function add_chiefcop_liste(){
	$pid =$_POST['pid'];
	// echo "dfdfd";exit;
	 $sql="SELECT * FROM complains WHERE pid = $pid AND DATE_FORMAT(complains.date,'%Y-%m-%d') = CURDATE()";
 	 $chiefCEx= $this->model->Select_chief_C($sql);
 	 $data['data'] = $chiefCEx['Data'];
 	 $c_array = json_decode(json_encode($data), true);
 	 echo json_encode($c_array);

} 

  function add_chif(){
			$insert_data = [
			                'pid' => mysqli_real_escape_string($this->Connection,$_POST['pid']),
			                'observation' => mysqli_real_escape_string($this->Connection,$_POST['observation']),
			                'obs_count' => mysqli_real_escape_string($this->Connection,$_POST['obs_count']),
			                'obs_dmy' => mysqli_real_escape_string($this->Connection,$_POST['obs_dmy']),
			                'caseid' => mysqli_real_escape_string($this->Connection,$_POST['caseid']),
			                // 'Date' => $timetamp
			              ];
		 $insertEx= $this->model->InsertData('complains',$insert_data);
		 $data['message'] = $insertEx['Message'];
 	   $array = json_decode(json_encode($data), true);
		echo json_encode($array);
}

  function select_chiefcomplains(){
          $id =$_POST['id'];
         	$sql ="SELECT * FROM `complains` WHERE id =$id";
	        $Alldata = $this->model->Select($sql);
    		  $array=$Alldata['Data'][0]; 
	 	echo json_encode($array);
}

  function update_chiefcomplains(){
	           $id = $_POST['id'];
             $update_data = [
			                'observation' => $_POST['observation'],
			                'obs_count' => $_POST['obs_count'],
			                'obs_dmy' => $_POST['obs_dmy'],
			                // 'Date' => $timetamp
			              ];
			        
		      $updata = $this->model->UpdateData($this->table3,$update_data,['id'=>$this->model->htmlValidation($id)],$and);

		echo json_encode($updata);
}

  function delete_chiefcomplains(){
	$deleteEx= $this->model->Delete($this->table3,['id'=>$this->model->htmlValidation($_POST['id'][1])],$and);
	$data['Code'] = $deleteEx;
	echo json_encode($data);
}

  function admission_pending(){
    	include 'views/admission/admission_pending.php';
  }
  function admission_panding_json(){
					// $sql="SELECT practices.id,practices.pid,patients.pmshid,patients.contact,upper(concat (patients.pfname,' ',patients.pmname,' ',patients.plname)) as Name,patients.age,patients.gender,DATE_FORMAT(practices.date,'%d-%m-%Y')as date, practices.caseid,practices.status FROM practices INNER JOIN patients ON practices.pid = patients.pid WHERE DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE() and (practices.status = 'admit') order by practices.caseid ASC";
					$sql="SELECT practices.id,practices.pid,patients.pmshid,patients.contact,upper(concat (patients.pfname,' ',patients.pmname,' ',patients.plname)) as Name,patients.age,patients.gender,DATE_FORMAT(practices.date,'%d-%m-%Y')as date, practices.caseid,practices.status,c.`consult_id` FROM practices JOIN patients ON practices.pid = patients.pid left join consults c on c.`caseid` = practices.`id` where practices.`status`='admit'";
	
 	 $pcasesEx= $this->model->Select_admission($sql);
 	 $data['data'] = $pcasesEx['Data'];
 	 $array = json_decode(json_encode($data), true);
 	 echo json_encode($array);
  	
  }
  
  function admission(){
  	$case_id=$_GET['case_id'];
  	$pid=$_GET['p_id'];
  	
	 	$sql="SELECT patients.pid,patients.contact,upper(concat (patients.pfname,' ',patients.pmname,' ',patients.plname)) as Name,patients.age,patients.gender,DATE_FORMAT(practices.date,'%d-%m-%Y')as date,practices.caseid,practices.id,patients.address,patients.pmshid,practices.id FROM patients INNER JOIN practices ON patients.pid = practices.pid WHERE practices.pid=$pid ORDER BY practices.id DESC LIMIT 1";
	 	
	 	     $Alldata = $this->model->Select($sql);
    		 $_SESSION['admitpatientinfo']=$Alldata['Data'][0];
    		 
    		 //InsertData admission form
    		 if(isset($_POST['Save'])){
    		 	
			  		 	$date=$_POST['doa'];
			  		 	$pr_id=$_POST['id_pr'];
			        $date_convat=date("Y-m-d", strtotime($date) );
			  		 	$time=$_POST['hour'].":".$_POST['min']." ".$_POST['ampm'];
    		 		$insert_data_admiss = [
			                'pid' => mysqli_real_escape_string($this->Connection,$_POST['pid']),
			                'caseid' => mysqli_real_escape_string($this->Connection,$pr_id),
			                'referred_to' => mysqli_real_escape_string($this->Connection,$_POST['Referred_To']),
			                'room_type' => mysqli_real_escape_string($this->Connection,$_POST['roomtype']),
			                'deposit' => mysqli_real_escape_string($this->Connection,$_POST['deposit']),
			                'time_of_admission' => mysqli_real_escape_string($this->Connection,$time),
			                'date_of_admission' => mysqli_real_escape_string($this->Connection,$date_convat),
			                'mediclaim' => mysqli_real_escape_string($this->Connection,$_POST['mediclaim']),
			                'bed_no' => mysqli_real_escape_string($this->Connection,$_POST['bedno']),
			                'provisional_diagnosis' => mysqli_real_escape_string($this->Connection,$_POST['pro_diagnosis']),
			                'remark' => mysqli_real_escape_string($this->Connection,$_POST['Remark'])
			                // 'Date' => $timetamp
			              ];
			              // echo"<pre>";
			              // print_r($_POST);
			              // print_r($insert_data_admiss);exit;
			         $insertEx= $this->model->InsertData('admissions',$insert_data_admiss);
			         
    		 	     if($insertEx['Code'] == 1){
                  	$update_array=[
    		                            'status' => mysqli_real_escape_string($this->Connection,'inhospital'),
    		                           ];
               $updata_array = $this->model->UpdateData('practices',$update_array,['id'=>$this->model->htmlValidation($_POST['id_pr'])],$and);
    		        if($updata_array['Code'] == 1){
    		        	    unset($_SESSION['admitpatientinfo']);
							     	  $url = $this->base_url.'admission/admission_pending';
							 		  	header("Location: $url");
    		            }
							     }else{
							     	  $url = $this->base_url.'admission/admission?p_id='.$pid;
							 			header("Location: $url");
							     }
    		 }
    		 
    		 //UpdateData admission form
    		 if(isset($_GET['admission_id'])){
    		 	     $admission_id=$_GET['admission_id'];
    		 	 	   $sql="SELECT * FROM `admissions` WHERE admissions.admission_id=".$admission_id;
				 	     $sel_data = $this->model->Select($sql);
			    		 $_SESSION['select_edit_data']=$sel_data['Data'][0];
			    
    		 }
    		 //Views admission info
    		 if(isset($_GET['admission_id_view'])){
    		 	      $admission_id=$_GET['admission_id_view'];
    		 	 	  	$sql="SELECT * FROM `admissions` WHERE admissions.admission_id=".$admission_id;
				 	      $sel_data = $this->model->Select($sql);
			    		  $_SESSION['select_view_data']=$sel_data['Data'][0];
			    
    		 }
    		 
    		 if(isset($_POST['Update'])){
    		
    		      $admission_id=$_SESSION['select_edit_data']->admission_id;
    		 		  $date=$_POST['doa'];
			        $date_convat=date("Y-m-d", strtotime($date) );
			  		 	$time=$_POST['hour'].":".$_POST['min']." ".$_POST['ampm'];
    		 		  $update_data_admiss = [
			                'referred_to' => mysqli_real_escape_string($this->Connection,$_POST['Referred_To']),
			                'room_type' => mysqli_real_escape_string($this->Connection,$_POST['roomtype']),
			                'deposit' => mysqli_real_escape_string($this->Connection,$_POST['deposit']),
			                'time_of_admission' => mysqli_real_escape_string($this->Connection,$time),
			                'date_of_admission' => mysqli_real_escape_string($this->Connection,$date_convat),
			                'mediclaim' => mysqli_real_escape_string($this->Connection,$_POST['mediclaim']),
			                'bed_no' => mysqli_real_escape_string($this->Connection,$_POST['bedno']),
			                'provisional_diagnosis' => mysqli_real_escape_string($this->Connection,$_POST['pro_diagnosis']),
			              ];
			            $update_data_admiss_Ex = $this->model->UpdateData('admissions',$update_data_admiss,['admission_id'=>$this->model->htmlValidation($admission_id)],$and);
			            
			             if($update_data_admiss_Ex['Code'] == 1){
			             	unset($_SESSION['select_edit_data']);
			             	unset($_SESSION['admitpatientinfo']);
							     	  $url = $this->base_url.'admission/admission_history';
							 		  	header("Location: $url");
							     }else{
							     	  $url = $this->base_url.'admission/admissionp_id='.$pid.'&admission_id='.$admission_id;
							 			header("Location: $url");
							     }
    		 	
    		 }
     
      	if($_GET['cancel']){
  	           		unset($_SESSION['select_edit_data']);
			            unset($_SESSION['admitpatientinfo']);
							     	  $url = $this->base_url.'admission/admission_history';
							 		  	header("Location: $url");
           	}  
      	if($_POST['Close']){
      		// echo "Close";exit;
  	           		unset($_SESSION['select_edit_data']);
			            unset($_SESSION['admitpatientinfo']);
			            unset($_SESSION['select_view_data']);
							     	  $url = $this->base_url.'admission/admission_history';
							 		  	header("Location: $url");
           	}  
    		 
  		include 'views/admission/admissionform.php';
  	
  }
  
  
  function admission_history(){
    	include 'views/admission/admission_history.php';
  }
  function admission_history_json(){
					$sql="SELECT upper(concat (p.pfname,' ',p.pmname,' ',p.plname)) as Name,p.age, p.`gender`, p.`contact`,date_format(a.`date_of_admission`,'%d-%m-%Y') AS date, a.`referred_to`,a.`admission_id`,a.caseid,m.`status`, m.`pid`,m.`id` FROM practices m join patients p on p.`pid`= m.`pid` join admissions a on a.`caseid`=m.`id` where m.`status`='discharge' or m.`status`='inhospital' order by a.`date_of_admission` desc";
		
		// $sql="SELECT c.`caseid`,m.`id`,m.`caseid`,upper(concat (p.pfname,' ',p.pmname,' ',p.plname)) as Name,p.age, p.`gender`, p.`contact`,m.`status`, m.`pid`,m.`id`,c.`consult_id` FROM practices m join patients p on m.`pid`=p.`pid` left join consults c on c.`caseid` =m.`id` where m.`status`='admit'";	
		
 	 $pcasesEx= $this->model->Select_admission($sql);
 	 $data['data'] = $pcasesEx['Data'];
 	 $array = json_decode(json_encode($data), true);
 	 echo json_encode($array);
  }	
  
  function patient_pending_admit(){
	$value = $_POST['q'];
		$sql="SELECT upper(concat(v.pfname,' ',v.pmname,' ',v.plname)) as Name,v.`pid` , v.pmshid FROM ". $this->table."  v WHERE concat(v.pfname,' ',v.pmname,' ',v.plname, '') LIKE '$value%' or v.contact like '%$value%'or pmshid like '%$value%' ORDER BY v.pfname";
		
  	 $selectEx= $this->model->Select_pending_admit($sql);
	 	 $data['data'] = $selectEx['Data'];
 	   $array = json_decode(json_encode($data), true);
 	  echo json_encode($array);
} 
function add_pending_admit(){
	// echo "add_pending_admit";exit;
    	$id = $_GET['pid'];
         if(!empty($id)){
         		// selecte of pbirth_date for patients
              	$sqlsle="SELECT patients.pbirth_date FROM `patients` WHERE pid=$id";
      		    	$sqlsleEx= $this->model->select_add_admit($sqlsle);
              	$array=$sqlsleEx['Data'];
				        $dateOfBirth=$array[0]->pbirth_date;
				        $today=date('Y-m-d');
				        $diff = date_diff(date_create($dateOfBirth), date_create($today));
				        $newage=$diff->format('%y');
				        $udatearr=[
									          'age' => mysqli_real_escape_string($this->Connection,$newage),
				                  ];
				                  // print_r($udatearr);exit;
				         // UpdateData patient gae
									$upd_age = $this->model->UpdateData($this->table,$udatearr,['pid'=>$this->model->htmlValidation($id)],$and);
        
          
          if($upd_age['Code'] == 1){
         	// selectmaxid of caseid
         	     $where="DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE()";
	            $mselEx= $this->model->selectmaxid($this->table1,'caseid',$where);

		              if($mselEx['Code'] == 1){
		                $caseid =	$row = $mselEx['Data'];
	                  $caseid=$caseid+1;
		              }else{
		                $caseid=1;
		              }
          //makeing current date time
		          $t=time();
							$timetamp=date("Y-m-d h:i:sa",$t);
					//InsertData array
			  			$insert_data = [
			                'pid' => $id,
			                'caseid' =>$caseid,
			                'date' => $timetamp,
			                'status' => 'admit'
			              ];
        
         // InsertData function call
			  	 $insertEx= $this->model->InsertData($this->table1,$insert_data);
			  	 
				     if($insertEx['Code'] == 1){
				     	  $url = $this->base_url.'admission/admission_pending';
				 		  	header("Location: $url");
				     }else{
				     	  $url = $this->base_url.'admission/admission_pending';
				 			header("Location: $url");
				     }
          }
         }
       }
  
  
}

