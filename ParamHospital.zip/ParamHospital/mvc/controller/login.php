<?php
date_default_timezone_set('Asa/Kolkata');
session_start();
class login {
	private $conectar;
	private $Connection;
	private $base_url;


	function __construct() {

		require_once __DIR__ . "/../core/Conectar.php";
		require_once __DIR__ . "/../model/login_model.php";
		$this->conectar = new Conectar();
		$this->model = new login_model();
		$this->base_url = base_url;
		$this->Connection = $this->conectar->Connection();
	}

	function login() {

		if (isset($_POST['login'])) {

			$email = mysqli_real_escape_string($this->Connection, $_POST['email']);
			$pass = mysqli_real_escape_string($this->Connection, $_POST['pass']);
			$loginEx = $this->model->LogingData($email, $pass);
			$_SESSION['user_data']=$loginEx;
			$array[]=$loginEx['Data'];
			$type[] =$array[0]->status;
			$_SESSION['type']=$type;
		
			if (!empty($loginEx['Data'])) {
				// $root = (!empty($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/';
				$url = $this->base_url.'index/index';
				// $url = $this->base_url.'index/index?type='.$type[0];
				header("Location: $url");

			} else {
				$_SESSION['login_err'] = $loginEx['Message'];
			}
		}


		include 'views/login/login.php';
	}
	function Logout() {
		unset($_SESSION['login_err']);
		unset($_SESSION['user_data']);
		unset($_SESSION['type']);
		$url = $this->base_url.'login/login';
		header("Location: $url");

	}

	function forgot_password() {
		include 'views/login/forgot_password.php';
		// $url = $this->base_url.'login/forgot_password';
		//echo $url;
		// exit;
		// header("Location: $url");
	}
}
?>