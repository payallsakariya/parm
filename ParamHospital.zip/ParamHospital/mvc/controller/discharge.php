<?php
date_default_timezone_set('Asa/Kolkata');
session_start();

class discharge{

	  public $table = "patients";
     public $table1 = "practices";
     public $table2 = "prescriptions";
     public $table3 = "complains";
		 private $conectar;
     private $Connection;
     private $base_url;
		
							    function __construct() {
							        require_once  __DIR__ . "/../core/Conectar.php";
                      require_once  __DIR__ . "/../model/discharge_model.php";
                      $this->conectar=new Conectar();
									    $this->model=new discharge_model();
									    $this->base_url = base_url;
									    $this->Connection=$this->conectar->Connection();
						       }
	
 function discharge_pending(){
		include 'views/discharge/pendingdischarge.php';
}

  function discharge_panding_json(){
					// $sql="SELECT practices.id,practices.pid,patients.pmshid,patients.contact,upper(concat (patients.pfname,' ',patients.pmname,' ',patients.plname)) as Name,patients.age,patients.gender,DATE_FORMAT(practices.date,'%d-%m-%Y')as date, practices.caseid,practices.status FROM practices INNER JOIN patients ON practices.pid = patients.pid WHERE DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE() and (practices.status = 'admit') order by practices.caseid ASC";
					$sql="SELECT r.`caseid`,p.pmshid,upper(concat(p.pfname,' ',p.pmname,' ',p.plname)) as Name, p.age, p.`gender`, p.`contact`,date_format(a.`date_of_admission`,'%d-%m-%Y') as date,r.`pid`, r.`status`,r.`id` FROM practices r join patients p on p.`pid`=r.`pid` join admissions a on a.`caseid`= r.`id` where r.`status`='inhospital'";
	
 	 $pcasesEx= $this->model->Select_dischrge($sql);
 	 $data['data'] = $pcasesEx['Data'];
 	 $array = json_decode(json_encode($data), true);
 	 echo json_encode($array);
  	
  }
  
 function discharge_patient(){
 	$pid=$_GET['p_id'];
 	$p_id=$_GET['pid'];
 	
 	if($pid){
 		$status='inhospital';
 		$pid=$pid;
 	}else{
 		$status='discharge';
 		$pid=$p_id;
 	}
 	// echo $pid;
 	// echo "discharge_patient";exit;
 	
	 	// $sql="SELECT practices.id,patients.pid,patients.contact,upper(concat (patients.pfname,' ',patients.pmname,' ',patients.plname)) as Name,patients.age,patients.gender,DATE_FORMAT(practices.date,'%d-%m-%Y')as date,practices.caseid,practices.id FROM patients INNER JOIN practices ON patients.pid = practices.pid WHERE practices.pid=$pid ORDER BY practices.id DESC LIMIT 1";
	 	
	 	 $query ="SELECT p.`pmshid`,upper(concat (p.pfname,' ',p.pmname,' ',p.plname)) as Name,p.`address`,p.`contact`,p.age, p.`gender`,date_format(a.`date_of_admission`,'%d-%m-%Y'),a.`provisional_diagnosis`,date_format(r.`date`,'%l:%i %p'),r.`pid`,r.id, r.`status`,a.`admission_id`, a.`caseid`, a.`date_of_admission`,a.`time_of_admission` FROM practices r join patients p on p.`pid`=r.`pid` join admissions a on a.`caseid`=r.`id` where r.`status`='$status' and r.pid=$pid ORDER BY r.id DESC LIMIT 1";
// echo $query;exit;

	 	     $Alldata = $this->model->Select($query);
	 	     //echo "<pre>";
	 	     //print_r($Alldata);exit;
    		 $_SESSION['dischargepatient']=$Alldata['Data'][0];
    		 
    		 
    		 if(isset($_POST['Save'])){
    		 	// echo "<pre>";
    		 	// print_r($_POST);exit;
    		 	$time=$_POST['hour'].':'.$_POST['min'].' '.$_POST['ampm'];
    		 	$followup=$_POST['followupday'].' '.$_POST['followdmy'];
    		 	$up_id=$_POST['tid'];
    		 	$dischargedate=date("Y-m-d", strtotime($_POST['date_dt']));
    		 	$formatdate=date("Y-m-d", strtotime($_POST['f_date']));
    		 	
    		 		$insert_dis_data = [
			                'pid' => mysqli_real_escape_string($this->Connection,$_POST['pid']),
			                'dischargeid' => mysqli_real_escape_string($this->Connection,$_POST['admission_id']),
			                'formatdate' => mysqli_real_escape_string($this->Connection,$formatdate),
			                'dischargedate' => mysqli_real_escape_string($this->Connection,$dischargedate),
			                'dischargetime' => mysqli_real_escape_string($this->Connection,$time),
			                'operated' => mysqli_real_escape_string($this->Connection,$_POST['operated']),
			                'consultant' => mysqli_real_escape_string($this->Connection,$_POST['consultant']),
			                't' => mysqli_real_escape_string($this->Connection,$_POST['t']),
			                'p' => mysqli_real_escape_string($this->Connection,$_POST['p']),
			                'bp' => mysqli_real_escape_string($this->Connection,$_POST['bp']),
			                'r' => mysqli_real_escape_string($this->Connection,$_POST['r']),
			                'rbs' => mysqli_real_escape_string($this->Connection,$_POST['rbs']),
			                'spo2' => mysqli_real_escape_string($this->Connection,$_POST['spo2']),
			                'condition_on_dis' => mysqli_real_escape_string($this->Connection,$_POST['pat_cnd_dis']),
			                'investigation_detail_dis' => mysqli_real_escape_string($this->Connection,$_POST['inv_det_dis']),
			                'summary' => mysqli_real_escape_string($this->Connection,$_POST['dis_summary']),
			                'advice_on_dis' => mysqli_real_escape_string($this->Connection,$_POST['advice_dis']),
			                'remark' => mysqli_real_escape_string($this->Connection,$_POST['remark']),
			                'follow_up_after' => mysqli_real_escape_string($this->Connection,$followup),
			                'caseid' => mysqli_real_escape_string($this->Connection,$up_id)
			              ];
			        // print_r($insert_dis_data);exit;
		 $insertEx= $this->model->InsertData('discharges',$insert_dis_data);
		 
		  if($insertEx['Code'] == 1){
		    	$update_data=[
			                'status' =>'discharge',
			              ];
			              // $and="id = $up_id";
		    	$updata = $this->model->UpdateData($this->table1,$update_data,['id'=>$this->model->htmlValidation($_POST['caseid'])],$and);
		    	
		    	if($updata['Code'] == 1){
		    		  unset($_SESSION['dischargepatient']);
		    		  $url = $this->base_url.'discharge/discharge_pending';
				 			  header("Location: $url");
		    	}
				}else{
			          $url = $this->base_url.'discharge/discharge_patient?p_id='.$pid;
				 			  header("Location: $url");
				}
    		 }
    		 
    		 //UpdateData admission form
    		 if(isset($_GET['discharge_id'])){
    		 	      $discharge_id=$_GET['discharge_id'];
    		 	 	  	$sql="SELECT * FROM `discharges` WHERE discharges.dischargeid=".$discharge_id;
				 	      $sel_data = $this->model->Select($sql);
			    		  $_SESSION['select_dis_edit_data']=$sel_data['Data'][0];
			    
    		 }
    		 //Views admission info
    		 if(isset($_GET['discharge_id_view'])){
    		 	      $discharge_id=$_GET['discharge_id_view'];
    		 	 	  	$sql="SELECT * FROM `discharges` WHERE discharges.dischargeid=".$discharge_id;
				 	      $sel_data = $this->model->Select($sql);
			    		  $_SESSION['select_dis_view_data']=$sel_data['Data'][0];
			    
    		 }
    		 //Close views detels
    		 if(isset($_POST['close'])){
			    		 	unset($_SESSION['dischargepatient']);
			    		 	unset($_SESSION['select_dis_view_data']);
			    		 	$url = $this->base_url.'discharge/discharge_history';
				 			  header("Location: $url");
    		 }
    		 
    		  if(isset($_POST['Update'])){
    		  	// echo "Update";exit;
    		            $dischargeid=$_SESSION['select_dis_edit_data']->dischargeid;
    		            $time=$_POST['hour'].':'.$_POST['min'].' '.$_POST['ampm'];
    		 	          $followup=$_POST['followupday'].' '.$_POST['followdmy'];
    		 	          // $up_id=$_POST['tid'];
    		         	  $dischargedate=date("Y-m-d", strtotime($_POST['date_dt']));
    		          	$formatdate=date("Y-m-d", strtotime($_POST['f_date']));
    		 		  $update_data_dis = [
			                'formatdate' => mysqli_real_escape_string($this->Connection,$formatdate),
			                'dischargedate' => mysqli_real_escape_string($this->Connection,$dischargedate),
			                'dischargetime' => mysqli_real_escape_string($this->Connection,$time),
			                'operated' => mysqli_real_escape_string($this->Connection,$_POST['operated']),
			                'consultant' => mysqli_real_escape_string($this->Connection,$_POST['consultant']),
			                't' => mysqli_real_escape_string($this->Connection,$_POST['t']),
			                'p' => mysqli_real_escape_string($this->Connection,$_POST['p']),
			                'bp' => mysqli_real_escape_string($this->Connection,$_POST['bp']),
			                'r' => mysqli_real_escape_string($this->Connection,$_POST['r']),
			                'rbs' => mysqli_real_escape_string($this->Connection,$_POST['rbs']),
			                'spo2' => mysqli_real_escape_string($this->Connection,$_POST['spo2']),
			                'condition_on_dis' => mysqli_real_escape_string($this->Connection,$_POST['pat_cnd_dis']),
			                'investigation_detail_dis' => mysqli_real_escape_string($this->Connection,$_POST['inv_det_dis']),
			                'summary' => mysqli_real_escape_string($this->Connection,$_POST['dis_summary']),
			                'advice_on_dis' => mysqli_real_escape_string($this->Connection,$_POST['advice_dis']),
			                'remark' => mysqli_real_escape_string($this->Connection,$_POST['remark']),
			                'follow_up_after' => mysqli_real_escape_string($this->Connection,$followup)
			              ];
			            $update_data_dis_Ex = $this->model->UpdateData('discharges',$update_data_dis,['dischargeid'=>$this->model->htmlValidation($dischargeid)],$and);
			            
			             if($update_data_dis_Ex['Code'] == 1){
			             	unset($_SESSION['select_dis_edit_data']);
			             	unset($_SESSION['dischargepatient']);
							     	  $url = $this->base_url.'discharge/discharge_history';
							 		  	header("Location: $url");
							     }else{
							     	  $url = $this->base_url.'discharge/discharge_patient?'.$pid.'=5&discharge_id='.$dischargeid;
							 			header("Location: $url");
							     }
    		 	
    		 }
    		 

 	include 'views/discharge/dischargeform.php';
 
 } 
 
 function discharge_pdf(){
 	$pfd_id = $_GET['discharge_pdf_id'];
 	$pid = $_GET['pid'];
 	$sqll="SELECT upper(concat (p.pfname,' ',p.pmname,' ',p.plname)) as Name, p.age,p.`gender`,date_format(a.`date_of_admission`,'%d-%m-%Y') as a_date, a.`time_of_admission`, d.`diagnosis`, d.`advice_on_dis`, d.`investigation_detail_dis`, d.`remark`, d.`condition_on_dis`,d.`id`, d.`caseid`, d.`dischargeid`, p.`pmshid`,p.`address`, date_format(d.`dischargedate`,'%d-%m-%Y') as dis_date,d.`summary`,date_format(d.`formatdate`,'%d-%m-%Y') as format_date,d.`follow_up_after`,d.`t`,d.`p`,d.`r`,d.`bp`,d.`rbs`,d.`spo2`, d.`dischargetime` ,a.`referred_to` FROM discharges d join admissions a on a.`admission_id`=d.`dischargeid` join practices m on d.`caseid`=m.`id` join patients p on m.`pid`=p.`pid` where d.`dischargeid`='$pfd_id'";
 	
 	       $Alldata = $this->model->Select($sqll);
    		 $_SESSION['dis_data_1']=$Alldata['Data'][0];
 	
 	       $treat_sql="SELECT t.`dischargeid`, t.`treat` FROM treat_inhosps t where t.`dischargeid`='$pfd_id'";
 	
 	       $All_data = $this->model->Select($treat_sql);
    		 $_SESSION['treat_data']=$All_data['Data'];
 	
			 	$sql="SELECT * FROM `medicine_discharges` WHERE dischargeid='$pfd_id'";
			 	$All_data_m = $this->model->Select($sql);
    		 $_SESSION['medicine_data']=$All_data_m['Data'];
    		 //echo "<pre>";
    		 //print_r($_SESSION);exit;
 	
 	include 'views/discharge/pdf_discharge.php';
 }
 
  function add_teart(){
			$insert_data = [
			                'pid' => mysqli_real_escape_string($this->Connection,$_POST['pid']),
			                'treat' => mysqli_real_escape_string($this->Connection,$_POST['treat']),
			                'caseid' => mysqli_real_escape_string($this->Connection,$_POST['caseid']),
			                'dischargeid' => mysqli_real_escape_string($this->Connection,$_POST['admission_id']),
			              ];
			        // print_r($insert_data);exit;
		 $insertEx= $this->model->InsertData('treat_inhosps',$insert_data);
		 $data['message'] = $insertEx['Message'];
 	   $array = json_decode(json_encode($data), true);
		echo json_encode($array);
}

 function add_discharge_tear_liste(){
	$pid =$_POST['pid'];
	$caseid =$_POST['id'];
	 $sql="SELECT treat_inhosps.id,treat_inhosps.treat,treat_inhosps.pid,treat_inhosps.caseid,treat_inhosps.dischargeid FROM `treat_inhosps` LEFT JOIN admissions ON admissions.admission_id = treat_inhosps.dischargeid WHERE treat_inhosps.pid = $pid and treat_inhosps.caseid=$caseid";
 	 $chiefCEx= $this->model->Select_tear_list($sql);
 	 $data['data'] = $chiefCEx['Data'];
 	 $c_array = json_decode(json_encode($data), true);
 	 echo json_encode($c_array);

} 

  function select_treat(){
          $id =$_POST['id'];
         	$sql ="SELECT * FROM `treat_inhosps` WHERE id =$id";
	        $Alldata = $this->model->Select($sql);
    		  $array=$Alldata['Data'][0]; 
	 	echo json_encode($array);
}

  function update_treat(){
	           $id = $_POST['id'];
             $update_data = [
			                 'treat' => mysqli_real_escape_string($this->Connection,$_POST['treat']),
			              ];
			        
		      $updata = $this->model->UpdateData('treat_inhosps',$update_data,['id'=>$this->model->htmlValidation($id)],$and);

		echo json_encode($updata);
}

  function delete_treat(){
	$deleteEx= $this->model->Delete('treat_inhosps',['id'=>$this->model->htmlValidation($_POST['id'][1])],$and);
	$data['Code'] = $deleteEx;
	echo json_encode($data);
}


  function add_madicine(){
			$insert_data = [
			                'pid' => mysqli_real_escape_string($this->Connection,$_POST['pid']),
			                'medicine' => mysqli_real_escape_string($this->Connection,$_POST['medicine']),
			                'advice' => mysqli_real_escape_string($this->Connection,$_POST['advice']),
			                'morning' => mysqli_real_escape_string($this->Connection,$_POST['moring']),
			                'noon' => mysqli_real_escape_string($this->Connection,$_POST['noon']),
			                'night' => mysqli_real_escape_string($this->Connection,$_POST['night']),
			                'tab_spoon' => mysqli_real_escape_string($this->Connection,$_POST['size']),
			                'days' => mysqli_real_escape_string($this->Connection,$_POST['days']),
			                'caseid' => mysqli_real_escape_string($this->Connection,$_POST['caseid']),
			                'dischargeid' => mysqli_real_escape_string($this->Connection,$_POST['admission_id']),
			              ];
			        // print_r($insert_data);exit;
		 $insertEx= $this->model->InsertData('medicine_discharges',$insert_data);
		 $data['message'] = $insertEx['Message'];
 	   $array = json_decode(json_encode($data), true);
		echo json_encode($array);
}

 function add_discharge_madicine_liste(){
	$pid =$_POST['pid'];
  $caseid =$_POST['id'];
	 $sql="SELECT medicine_discharges.id,medicine_discharges.medicine,concat(medicine_discharges.morning,',',medicine_discharges.noon,',',medicine_discharges.night,',',medicine_discharges.tab_spoon) as qty,medicine_discharges.days,medicine_discharges.advice,medicine_discharges.pid,medicine_discharges.caseid,medicine_discharges.dischargeid FROM medicine_discharges LEFT JOIN admissions ON admissions.admission_id = medicine_discharges.dischargeid WHERE medicine_discharges.pid = $pid and medicine_discharges.caseid=$caseid";
 	 $chiefCEx= $this->model->Select_madicine_list($sql);
 	 $data['data'] = $chiefCEx['Data'];
 	 $c_array = json_decode(json_encode($data), true);
 	 echo json_encode($c_array);

} 

  function select_madicine(){
          $id =$_POST['id'];
         	$sql ="SELECT * FROM `medicine_discharges` WHERE id =$id";
	        $Alldata = $this->model->Select($sql);
    		  $array=$Alldata['Data'][0]; 
	 	echo json_encode($array);
}

  function update_madicine(){
	           $id = $_POST['id'];
	           //echo $id;
             $update_data = [
			                 'medicine' => mysqli_real_escape_string($this->Connection,$_POST['medicine']),
			                'advice' => mysqli_real_escape_string($this->Connection,$_POST['advice']),
			                'morning' => mysqli_real_escape_string($this->Connection,$_POST['moring']),
			                'noon' => mysqli_real_escape_string($this->Connection,$_POST['noon']),
			                'night' => mysqli_real_escape_string($this->Connection,$_POST['night']),
			                'tab_spoon' => mysqli_real_escape_string($this->Connection,$_POST['size']),
			                'days' => mysqli_real_escape_string($this->Connection,$_POST['days']),
			              ];
			        
		      $updata = $this->model->UpdateData('medicine_discharges',$update_data,['id'=>$this->model->htmlValidation($id)],$and);

		echo json_encode($updata);
}

  function delete_madicine(){
	$deleteEx= $this->model->Delete('medicine_discharges',['id'=>$this->model->htmlValidation($_POST['id'][1])],$and);
	$data['Code'] = $deleteEx;
	echo json_encode($data);
}

 function discharge_history(){
		include 'views/discharge/dischargehistory.php';
}

  function discharge_history_json(){
						
		$sql="SELECT  upper(concat (p.pfname,' ',p.pmname,'',p.plname)) as Name,p.age, p.`gender`, p.`contact`
,date_format(a.`date_of_admission`,'%d-%m-%Y') as admit_date,  date_format(d.`dischargedate`,'%d-%m-%Y') as discharge_date,m.`status`, m.`pid`,m.`id` , d.`dischargeid`,d.`operated`
FROM practices m join patients p on m.`pid`=p.`pid` join admissions a on a.`caseid`=m.`id` join discharges d on d.`dischargeid`= a.`admission_id` where m.`status`='discharge' order by d.`dischargedate`desc";			

 	 $pcasesEx= $this->model->Select_dischrge($sql);
 	 $data['data'] = $pcasesEx['Data'];
 	 $array = json_decode(json_encode($data), true);
 	 //print_r($array);exit;
 	 echo json_encode($array);
  	
  }


  
}

