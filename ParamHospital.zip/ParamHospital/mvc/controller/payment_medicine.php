<?php
date_default_timezone_set('Asa/Kolkata');
session_start();
class payment_medicine {
     public $table = "patients";
     public $table1 = "practices";
     public $table2 = "prescriptions";
		 private $conectar;
     private $Connection;
     private $base_url;
		
							    function __construct() {
							        require_once  __DIR__ . "/../core/Conectar.php";
                      require_once  __DIR__ . "/../model/payment_madicine_model.php";
                      $this->conectar=new Conectar();
									    $this->model=new payment_madicine_model();
									    $this->base_url = base_url;
									    $this->Connection=$this->conectar->Connection();
						       }
						       
  //add patint data
function patient(){
		
	  	  if(isset($_POST['Submit'])){
	  	  	$type = $_SESSION['type'][0];
	  	        //pmshid makeing code
		  	       $mselEx= $this->model->selectmaxid($this->table,'pid',$where);
		              if($mselEx['Code'] == 1){
		                $lastid =	$row = $mselEx['Data'];
	                  $lastid=$lastid+1;
										$lastid = str_pad($lastid,5, '0', STR_PAD_LEFT);
										$currentyear=  date("y");
										$pmshid='PMSH'.$currentyear.$lastid;
		              }else{
		                $lastid=1;
										$lastid = str_pad($lastid,5, '0', STR_PAD_LEFT);
										$currentyear=  date("y");
										$pmshid='PMSH'.$currentyear.$lastid;
		              }
	  	  	
					//date format change DD/MM/YYYY To YYYY/MM/DD
								$orgDate = $_POST['dob'];
								$date = str_replace('-"', '/', $orgDate);
								$newDate = date("Y/m/d", strtotime($date));
					//makeing current date time
		          $t=time();
							$timetamp=date("Y-m-d h:i:sa",$t);			
								

          //creat array for insert data in database
			  			$insert_data = [
			                'pmshid' => $pmshid,
			                'contact' => $_POST['phone'],
			                'pfname' => $_POST['fname'],
			                'pmname' => $_POST['mname'],
			                'plname' => $_POST['lname'],
			                'age' => $_POST['age'],
			                'bloodgroup' => $_POST['bloodgroup'],
			                'pbirth_date ' => $newDate,
			                'gender	' => $_POST['gender'],
			                'religion	' => $_POST['religion'],
			                'postal_code' => $_POST['postalcode'],
			                'address	' => $_POST['address'],
			                'medical_history	' => $_POST['mhistory'],
			                'date	' => $timetamp
			              ];
	              // InsertData function call
						  	 $insertEx= $this->model->InsertData($this->table,$insert_data);
							     if($insertEx['Code'] == 1){
							     	  $url = $this->base_url.'index/index?type='.$type;
							 		  	header("Location: $url");
							     }else{
							     	  $url = $this->base_url.'patient/patient';
							 			header("Location: $url");
							     }
	  	}
include 'views/patient/patient.php';		
 }

function edit_patient(){
				$pid = $_GET['p_id'];
				$type= $_SESSION['type'][0];

  if($type == 'staff'){
	    $Alldata = $this->model->SelectAllData($this->table,['pid'=>$this->model->htmlValidation($pid)]);
 }
     
	    // Convert stdClass object to array in PHP [duplicate]
        $_SESSION['EditPatient'] = $Alldata['Data'][0];
       if(isset($_POST['edit'])){
      
					//date format change DD/MM/YYYY To YYYY/MM/DD
								$orgDate = $_POST['dob'];
								$date = str_replace('-"', '/', $orgDate);
								$newDate = date("Y/m/d", strtotime($date));

          //UPdate array for pudate data in database
			  			$update_data = [
			                'pmshid' => mysqli_real_escape_string($this->Connection,$_POST['pmhid']),
			                'contact' => mysqli_real_escape_string($this->Connection,$_POST['phone']),
			                'pfname' => mysqli_real_escape_string($this->Connection,$_POST['fname']),
			                'pmname' => mysqli_real_escape_string($this->Connection,$_POST['mname']),
			                'plname' => mysqli_real_escape_string($this->Connection,$_POST['lname']),
			                'age' => mysqli_real_escape_string($this->Connection,$_POST['age']),
			                'bloodgroup' => mysqli_real_escape_string($this->Connection,$_POST['bloodgroup']),
			                'pbirth_date ' => mysqli_real_escape_string($this->Connection,$newDate),
			                'gender	' => mysqli_real_escape_string($this->Connection,$_POST['gender']),
			                'religion	' => mysqli_real_escape_string($this->Connection,$_POST['religion']),
			                'postal_code' => mysqli_real_escape_string($this->Connection,$_POST['postalcode']),
			                'address	' => mysqli_real_escape_string($this->Connection,$_POST['address']),
			                'medical_history	' => mysqli_real_escape_string($this->Connection,$_POST['mhistory'])
			              ];
	         // Update function call
				$upd_data = $this->model->UpdateData($this->table,$update_data,['pid'=>$this->model->htmlValidation($pid)],$and);
						  	 	
				  //redirect page
				     if($upd_data['Code'] == 1){
					     	  unset($_SESSION['EditPatient']);
					     	  $url = $this->base_url.'patient/pending_cases';
					 		  	header("Location: $url");
				     }else{
					     	  $url = $this->base_url.'patient/edit_patient';
					 			  header("Location: $url");
				     }
	  	}
	  	
	 	
	include 'views/patient/patient.php';		
} 
   
function pending_cases(){
		include 'views/patient/pending_cases.php';
   }
   
   
function pending_cases_json(){
	$type =$_SESSION['type'];
	  $sql="SELECT patients.pid,patients.pmshid,patients.contact,upper(concat (patients.pfname,' ',patients.pmname,' ',patients.plname)) as Name,patients.age,patients.gender,patients.paypending,DATE_FORMAT(practices.date,'%d-%m-%Y')as date, DATE_FORMAT(practices.date,'%l:%i-%p ')as time,practices.caseid,practices.payment FROM ".$this->table." INNER JOIN ".$this->table1." ON patients.pid = practices.pid WHERE DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE() and practices.charge is NULL and practices.status = 'consult' ORDER BY practices.date DESC";
 	 $pcasesEx= $this->model->Select_pending_cases($sql);
 	 //print_r($pcasesEx);
 	 $data['data'] = $pcasesEx['Data'];
 	 //print_r($data['data']);
 	 $array = json_decode(json_encode($data), true);
 	 //print_r($array);exit;
 	 echo json_encode($array);
}



function DoctorEditPatient(){
	echo "medicine";exit;
	
				$pid = $_GET['p_id'];
				$type= $_SESSION['type'][0];
				  	$sql="SELECT patients.pid,patients.pmshid,patients.contact,upper(concat (patients.pfname,' ',patients.pmname,' ',patients.plname)) as Name,patients.age,patients.gender,DATE_FORMAT(practices.date,'%Y-%m-%d')as date, DATE_FORMAT(practices.date,'%l:%i-%p ')as time,practices.caseid FROM patients INNER JOIN practices ON patients.pid = practices.pid WHERE DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE() && practices.pid=".$pid;
     	
    		 $Alldata = $this->model->Select_pending_cases($sql);
    		 $_SESSION['DEditpatient']=$Alldata['Data'][0];
    		
    		//doctor calncel 
    if($_POST['Sv_cancel']){
    	// echo $_GET['p_id'];
	       $deleteEx= $this->model->Delete($this->table2,['pid'=>$this->model->htmlValidation($_GET['p_id'])],$and);
    	
		    	if($deleteEx){
					 	 $url = $this->base_url.'patient/pending_cases';
					 	 header("Location: $url");
		    	}
	 } 		 
    		 
    	//save data in database	 
   if($_POST['D_save']){
		    $pid=$_GET['p_id'];
	  	 	$D_udate=[
	  	 		          'charge' => mysqli_real_escape_string($this->Connection,$_POST['charge']),
		                'disease' => mysqli_real_escape_string($this->Connection,$_POST['disease']),
		                'medicine' => mysqli_real_escape_string($this->Connection,$_POST['medicine']),
		                'status' => mysqli_real_escape_string($this->Connection,'payment')
		              ];
		          
		              $and="date_format(date,'%d-%m-%Y')=date_format(now(),'%d-%m-%Y')";
	         // Update function call
						$upd_D_data = $this->model->UpdateData($this->table1,$D_udate,['pid'=>$this->model->htmlValidation($pid)],$and);
				  //redirect page
				    if($upd_D_data['Code'] == 1){
				    	// echo"up";exit;
				    		$payget_info = $_SESSION['DEditpatient'];
   	            $caseid = $payget_info->caseid;
   	            $name = $payget_info->Name;
				    	  	$pay_insert=[
	  	 		          'pid' => mysqli_real_escape_string($this->Connection,$pid),
	  	 		          'caseid' => mysqli_real_escape_string($this->Connection,$caseid),
	  	 		          'name' => mysqli_real_escape_string($this->Connection,$name),
	  	 		          'charge' => mysqli_real_escape_string($this->Connection,$_POST['charge']),
		              ];
				   $upd_pay_data = $this->model->InsertData('payments_history',$pay_insert);    	
				    	if($upd_pay_data){
						    	  unset($_SESSION['DEditpatient']);
						    	  $url = $this->base_url.'patient/pending_cases';
								  	header("Location: $url");
				    	}
				    }else{
						    	  $url = $this->base_url.'patient/DoctorEditPatient?p_id='.$pid;
									  header("Location: $url");
				    }
	}
	
	//staff not updat than cancel
	 if($_POST['Upd_cancel']){
			 	 $url = $this->base_url.'patient/completed';
			 	 header("Location: $url");
	 }
	
    		 
    if($_GET['casetype'] == 'complet'){
		// $sqltype="SELECT practices.pid,practices.charge,practices.disease,practices.medicine FROM `practices` WHERE pid =8 AND DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE()";
		$option="practices.pid,practices.charge,practices.disease,practices.medicine";
		$pid=$_GET['p_id'];
		$where="DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE()";
		$sqltypeEx = $this->model->Select($option,$this->table1,$where,$pid);
		 $_SESSION['update_patient_info']=$sqltypeEx['Data'][0];
		 //print_r($_SESSION['update_patient_info']);exit;
	}
    	
   //staff update complet cases 		 
   if(isset($_POST['up_date'])){
		$pid=$_GET['p_id'];
		$updatedata = [
						         'charge' => mysqli_real_escape_string($this->Connection,$_POST['charge']),
		                'disease' => mysqli_real_escape_string($this->Connection,$_POST['disease']),
		                'medicine' => mysqli_real_escape_string($this->Connection,$_POST['medicine'])
						      ];
						      $and="date_format(date,'%d-%m-%Y')=date_format(now(),'%d-%m-%Y')";
	      // Update function call
		        $upddata = $this->model->UpdateData($this->table1,$updatedata,['pid'=>$this->model->htmlValidation($pid)],$and);
		 
					   if($upddata['Code'] == 1){
					   	echo "test";exit;
                   //updat payments history
		              $charge=$_POST['charge'];
		              $sql="UPDATE payments_history SET charge = '$charge' WHERE pid = '$pid' AND date_format(date_time,'%d-%m-%Y')=date_format(now(),'%d-%m-%Y')";
		        $pay_up = $this->model->Update_Sql($sql);
		             if($pay_up){
						     	  	unset($_SESSION['update_patient_info']);
							     	  $url = $this->base_url.'patient/completed';
							 		  	header("Location: $url");
		             }
				     }else{
						     	  $url = $this->base_url.'patient/DoctorEditPatient?p_id='.$pid."&casetype=complet";
						 		   	header("Location: $url");
				     }
					
				} 		 
   
	 //form save
	 //if(isset($_POST['D_Edit'])){
	 //	$pid=$_GET['p_id'];
	 //	$D_udate=[
	 //		          'charge' => mysqli_real_escape_string($this->Connection,$_POST['charge']),
  //               'disease' => mysqli_real_escape_string($this->Connection,$_POST['disease']),
  //               'medicine' => mysqli_real_escape_string($this->Connection,$_POST['medicine']),
  //               'status' => mysqli_real_escape_string($this->Connection,'payment')
  //             ];
  //             // print_r($D_udate);
  //             $and="date_format(date,'%d-%m-%Y')=date_format(now(),'%d-%m-%Y')";
  //     // Update function call
		// 		$upd_D_data = $this->model->UpdateData($this->table1,$D_udate,['pid'=>$this->model->htmlValidation($pid)],$and);
		//   //redirect page
		//     if($upd_D_data['Code'] == 1){
		    	
		// 		    	  unset($_SESSION['DEditpatient']);
		// 		    	  $url = $this->base_url.'patient/pending_cases';
		// 				  	header("Location: $url");
		//     }else{
		// 		    	  $url = $this->base_url.'patient/DoctorEditPatient?p_id='.$pid;
		// 					  header("Location: $url");
		//     }
	 //}
	 
	 
	 
	   if($_GET['casetype'] == 'payments'){
	   	
							$pid=$_GET['p_id'];
							$sqlpay="SELECT practices.pid,practices.disease,practices.medicine,patients.paypending ,practices.charge,practices.payment FROM patients INNER JOIN practices ON patients.pid = practices.pid WHERE practices.pid = $pid AND DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE()";
							
							$sqltypeEx = $this->model->Select_completed_cases($sqlpay);
							// print_r($sqltypeEx);exit;
							$array=$sqltypeEx['Data'][0];
							$disease=$array->disease;
							$medicine=$array->medicine;
							
							$paymoney=$array->payment;
							$charge=$array->charge;
							$payPanding=$array->paypending;
							
							
							
							if($paymoney == 0.00){
						    	$total_fee=$payPanding+$charge;
							}else{
								$total_fee=$payPanding;
							}
					
							$dataarray=['charge'=>$charge,'payPanding'=>$payPanding,'total_fee'=>$total_fee,'disease'=>$disease,'medicine'=>$medicine,'paymoney'=>$paymoney];
						
							 $_SESSION['pay_inof']=$dataarray;
						}
	
	  // first time pay
		  if(isset($_POST['pay_ments'])){
							$pid = $_GET['p_id'];
							$total=$_SESSION['pay_inof']['total_fee'];
							$pay_fess = $_POST['pay'];
							$pay_panding = $total - $pay_fess;
							// $pay_panding = $total - $pay_fess;
						if($pay_panding<0){
							$pay_panding =0.00;
						}
					$sql="UPDATE patients INNER JOIN practices ON patients.pid =practices.pid SET patients.paypending = $pay_panding, practices.payment = $pay_fess WHERE patients.pid = $pid AND DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE()";
					$sqlEx = $this->model->Update_Sql($sql);
					
					if($sqlEx['Code'] == 1){
						$pay_up=[
		                'total_fees' => mysqli_real_escape_string($this->Connection,$total),
		                'pay' => mysqli_real_escape_string($this->Connection,$pay_fess),
		                'paypending' => mysqli_real_escape_string($this->Connection,$pay_panding)
							];
							  
						 $and="date_format(date_time,'%d-%m-%Y')=date_format(now(),'%d-%m-%Y')";
	      // Update function call
		        $upddata = $this->model->UpdateData('payments_history',$pay_up,['pid'=>$this->model->htmlValidation($pid)],$and);
		        if($upddata){
						     	  	unset($_SESSION['pay_inof']);
						     	  $url = $this->base_url.'patient/completed';
						 		  	header("Location: $url");
		        }
				     }else{
						     	  $url = $this->base_url.'patient/DoctorEditPatient?p_id='.$pid."&casetype=payments";
						 		   	header("Location: $url");
				     }
						
					}
		//pay update
			if(isset($_POST['pay_update'])){
				$payInfo=$_SESSION['pay_inof'];
				$pay= $_POST['pay'];
				$payamout =$payInfo['paymoney'];
				$total_fees =$payInfo['total_fee'];
				$payPanding =$payInfo['payPanding'];
				$pandingamout=($payamout - $pay);
				$totalpayment=($payamout + $pay);
		
					$sql="UPDATE patients INNER JOIN practices ON patients.pid =practices.pid SET patients.paypending = $pandingamout, practices.payment = $totalpayment WHERE patients.pid = $pid AND DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE()";

					$sqlEx = $this->model->Update_Sql($sql);
					
					if($sqlEx['Code'] == 1){
						$pay_up=[
		                'pay' => mysqli_real_escape_string($this->Connection,$totalpayment),
		                'paypending' => mysqli_real_escape_string($this->Connection,$pandingamout),
							];
							  
						 $and="date_format(date_time,'%d-%m-%Y')=date_format(now(),'%d-%m-%Y')";
	      // Update function call
		        $upddata = $this->model->UpdateData('payments_history',$pay_up,['pid'=>$this->model->htmlValidation($pid)],$and);
		        if($upddata){
						     	  	unset($_SESSION['pay_inof']);
						     	  $url = $this->base_url.'patient/completed';
						 		  	header("Location: $url");
		        }
				     }else{
						     	  $url = $this->base_url.'patient/DoctorEditPatient?p_id='.$pid."&casetype=payments";
						 		   	header("Location: $url");
				     }

			}		
				
				if(isset($_POST['pay_cancel'])){
						$pid = $_GET['p_id'];
							$pay_Panding=$_SESSION['pay_inof']['total_fee'];
							
					$sql="UPDATE patients SET patients.paypending = $pay_Panding WHERE patients.pid = $pid";
					$sqlEx = $this->model->Update_Sql($sql);
					
					if($sqlEx['Code'] == 1){
						$pay_cancle=[
		                'total_fees' => mysqli_real_escape_string($this->Connection,$pay_Panding),
		                'paypending' => mysqli_real_escape_string($this->Connection,$pay_Panding)
							];
							  
						 $and="date_format(date_time,'%d-%m-%Y')=date_format(now(),'%d-%m-%Y')";
	      // Update function call
		        $updata = $this->model->UpdateData('payments_history',$pay_cancle,['pid'=>$this->model->htmlValidation($pid)],$and);
		        if($updata){
						     	  unset($_SESSION['pay_inof']);
						     	  $url = $this->base_url.'patient/completed';
						 		  	header("Location: $url");
		        }
				     }else{
						     	  $url = $this->base_url.'patient/DoctorEditPatient?p_id='.$pid."&casetype=payments";
						 		   	header("Location: $url");
				     }
					
					 $url = $this->base_url.'patient/completed';
          header("Location: $url");
				}
	
			
	include 'views/patient/madicine.php';
}

function pay_select(){
	
	
}


function delete_patient(){
	
	$deleteEx= $this->model->Delete($this->table1,['pid'=>$this->model->htmlValidation($_GET['pid'])]);
	
			if($deleteEx == 1){
				?>
					        <script type="text/javascript">
					        	 //alert("Data delete ssuccessfully.");
					        	 window.location.href = 'pending_cases';
					        </script>
				<?php
				}else{
				?>
				       	<script type="text/javascript">
					        	 alert("'Somthing went!,please try again later'.");
					        	 window.location.href = 'pending_cases';
					        </script>
					<?php
				}

}
function patient_pending_cases(){
	$value = $_POST['q'];
		$sql="SELECT upper(concat(v.pfname,' ',v.pmname,' ',v.plname)) as Name,v.`pid` , v.pmshid FROM ". $this->table."  v WHERE concat(v.pfname,' ',v.pmname,' ',v.plname, '') LIKE '$value%' or v.contact like '%$value%'or pmshid like '%$value%' ORDER BY v.pfname";
		
  	 $selectEx= $this->model->Select_pending_cases($sql);
	 	 $data['data'] = $selectEx['Data'];
 	   $array = json_decode(json_encode($data), true);
 	  echo json_encode($array);
} 

//insert Data in practices table (cll selct2 ajex pending_cases.php file)
function add_pending_cases(){
    	$id = $_GET['pid'];
         if(!empty($id)){
         		// selecte of pbirth_date for patients
              	$sqlsle="SELECT patients.pbirth_date FROM `patients` WHERE pid=$id";
      		    	$sqlsleEx= $this->model->select_madicine($sqlsle);
              	$array=$sqlsleEx['Data'];
				        $dateOfBirth=$array[0]->pbirth_date;
				        $today=date('Y-m-d');
				        $diff = date_diff(date_create($dateOfBirth), date_create($today));
				        $newage=$diff->format('%y');
				        $udatearr=[
									          'age' => mysqli_real_escape_string($this->Connection,$newage),
				                  ];
				         // UpdateData patient gae
									$upd_age = $this->model->UpdateData($this->table,$udatearr,['pid'=>$this->model->htmlValidation($id)],$and);
        
          
          if($upd_age['Code'] == 1){
         	// selectmaxid of caseid
         	     $where="DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE()";
	            $mselEx= $this->model->selectmaxid($this->table1,'caseid',$where);

		              if($mselEx['Code'] == 1){
		                $caseid =	$row = $mselEx['Data'];
	                  $caseid=$caseid+1;
		              }else{
		                $caseid=1;
		              }
          //makeing current date time
		          $t=time();
							$timetamp=date("Y-m-d h:i:sa",$t);
					//InsertData array
			  			$insert_data = [
			                'pid' => $id,
			                'caseid' =>$caseid,
			                'date' => $timetamp
			              ];
        
         // InsertData function call
			  	 $insertEx= $this->model->InsertData($this->table1,$insert_data);
			  	 
				     if($insertEx['Code'] == 1){
				     	  $url = $this->base_url.'patient/pending_cases';
				 		  	header("Location: $url");
				     }else{
				     	  $url = $this->base_url.'patient/pending_cases';
				 			header("Location: $url");
				     }
          }
         }
       }
      
      
function madicine_prescriptions_add(){
	$pid =$_GET['pid'];
	 $sql="SELECT prescriptions.id,prescriptions.medicine,prescriptions.morning,prescriptions.afternoon,prescriptions.night,prescriptions.Date,prescriptions.description FROM prescriptions WHERE pid = $pid AND DATE_FORMAT(prescriptions.date,'%Y-%m-%d') = CURDATE()";
 	 $madicineEx= $this->model->select_madicine($sql);
 	 $data['data'] = $madicineEx['Data'];
 	 $m_array = json_decode(json_encode($data), true);
 	 echo json_encode($m_array);

}   

function delete_madicine(){
					$deleteEx= $this->model->Delete($this->table2,['id'=>$this->model->htmlValidation($_POST['id'][0])]);
					$data['Code'] = $deleteEx;
	echo json_encode($data);
}

function completed(){

	include 'views/patient/completed.php';	
}
function completed_cases_json(){
	$type =$_SESSION['type'][0];
	
	if($type== 'doctor'){
					$sql="SELECT practices.pid,patients.pmshid,patients.contact,upper(concat (patients.pfname,' ',patients.pmname,' ',patients.plname)) as Name,patients.age,patients.gender,patients.paypending,DATE_FORMAT(practices.date,'%d-%m-%Y')as date, DATE_FORMAT(practices.date,'%l:%i-%p ')as time,practices.caseid,practices.charge,practices.medicine,practices.status,patients.pid,practices.payment FROM ".$this->table1." INNER JOIN ".$this->table." ON practices.pid = patients.pid WHERE DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE() and (practices.status = 'admit' or  practices.status = 'payment') order by practices.caseid desc";
	}else{
		  $sql="SELECT practices.pid,patients.pmshid,patients.contact,upper(concat (patients.pfname,' ',patients.pmname,' ',patients.plname)) as Name,patients.age,patients.gender,patients.paypending,DATE_FORMAT(practices.date,'%d-%m-%Y')as date, DATE_FORMAT(practices.date,'%l:%i-%p ')as time,practices.caseid,practices.charge,practices.medicine,practices.status,patients.pid,practices.payment FROM ".$this->table1." INNER JOIN ".$this->table." ON practices.pid = patients.pid WHERE DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE() and (practices.status = 'payment') order by practices.caseid desc";
	}
	
	  
	  
 	 $pcasesEx= $this->model->Select_completed_cases($sql);
 	 $data['data'] = $pcasesEx['Data'];
 	 $array = json_decode(json_encode($data), true);
 	 echo json_encode($array);
}

 function Add_madicins(){

	  	  	$pid=$_POST['pid'];
	  	  	 $morning=$_POST['Morning'];
	  	  	 $afternoon=$_POST['Afternoon'];
	  	  	 $night=$_POST['Night'];
	  	  	 $t=time();
					 $timetamp=date("Y-m-d",$t);
	  	  	 
	  	  	 	$insert_data = [
			                'pid' => $pid,
			                'medicine' => $_POST['med_name'],
			                'description' => $_POST['description'],
			                'morning' => $morning,
			                'afternoon' => $afternoon,
			                'night' => $night,
			                'Date' => $timetamp
			              ];
			              $insertEx= $this->model->InsertData('prescriptions',$insert_data);
			              $insertEx= $this->model->InsertData('complains',$insert_data);
									  $data['message'] = $insertEx['Message'];
								 	  $array = json_decode(json_encode($data), true);
										echo json_encode($array);
	  	  
 	
 }
 
 function selecet_madicins(){
 	    
			  	  	$mid=$_POST['id'];
			  	  	$sql="SELECT * FROM `prescriptions` WHERE id =$mid";
			  	  	$selEx= $this->model->select_madicine_update($sql);
			  	  	$array=$selEx['Data'][0];
			  	  	$morning=explode(',',$array->morning);
			  	  	$afternoon=explode(',',$array->afternoon);
			  	  	$night=explode(',',$array->night);
			  	  $moring_s=$morning[0];
			  	  $moring_t=$morning[1];
			  	  $afternoon_s=$afternoon[0];
			  	  $afternoon_t=$afternoon[1];
			  	  $night_s=$night[0];
			  	  $night_t=$night[1];
			  	  
			  	  $alldata =['morning'=>$moring_s,'breakfast'=>$moring_t,'afternoon'=>$afternoon_s,'lunch'=>$afternoon_t,'night'=>$night_s,'dinner'=>$night_t,'id' =>$array->id ,'description' =>$array->description,'medicine' =>$array->medicine ];
			  	  
			  	  	 echo json_encode($alldata);
	  	  
 }
 
 function update_madicine(){

 		       $mid=$_POST['id'];
	  	  	 $morning=$_POST['Morning'];
	  	  	 $afternoon=$_POST['Afternoon'];
	  	  	 $night=$_POST['Night'];
 		$update_m_data = [
						                'medicine' => mysqli_real_escape_string($this->Connection,$_POST['med_name']),
						                'morning' => mysqli_real_escape_string($this->Connection,$morning),
						                'afternoon' => mysqli_real_escape_string($this->Connection,$afternoon),
						                'night' => mysqli_real_escape_string($this->Connection,$night),
						                'description' => mysqli_real_escape_string($this->Connection,$_POST['description'])
						              ];
						 $upd_m_data = $this->model->UpdateData('prescriptions',$update_m_data,['id'=>$this->model->htmlValidation($mid)],$and);
				  echo json_encode($upd_m_data);
 }
}

?>
