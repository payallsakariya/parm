<?php 
include 'views/css.php';
$data1=$_SESSION['dis_data_1'];
$medicine=$_SESSION['medicine_data'];
$arr=$_SESSION['treat_data'];
$rreat = (array) $arr;
$medicines = (array) $medicine;
$rears=[];
$mad=[];
$keys=[];
//echo "<pre>";
foreach ($rreat as $key=>$val){
	array_push($rears,$rreat[$key]->treat);
		// echo $rreat[$key]->treat;
}

foreach ($medicines as $key=>$val){
	array_push($keys,$medicines[$keys]);
}
$count=count($keys);
// print_r($medicines);
// print_r($rreat);
// exit;

?>
<html>
<head>
<style>
div{
	font-family: Verdana;
    font-size: 14pt;
}
table,td {
    border: 1px solid black;
    border-collapse: collapse;
}
.padding{
	padding-left: 50%;
	margin-right: 300px;
}
</style>
</head>
<body style="font-family: Verdana;font-size: 14pt;">
	 <div class="tm_container">
    <div class="tm_invoice_wrap">
	<div>
		<center>
		<br><br>
			<div>
				<a href="javascript:window.print()" class="tm_invoice_btn tm_color1">
				 <i class="fa fa-print"style="font-size:36px"  aria-hidden="true" title="print"></i></a>
			<a id="tm_download_btn" class="tm_invoice_btn tm_color2">
	         <i class="fa fa-download" style="font-size:36px" title="Download"></i></a>
		</div>
		<div  id="tm_download_section">
		<br><b><u>DISCHARGE CARD</u></b><br><br>
		<table width="70%" style="" cellpadding="5">
			<caption style="text-align:right">Date :- <?php echo $data1->dis_date ?></caption>
			<tr>
				<td align="left" colspan="2"><b>PMSH Id No. :- </b><?php echo $data1->dis_date ?></td>
			</tr>
			<tr>
				<td><b>Patient  Name :-  </b><?php echo $data1->Name ?></td>
				<td><b>Age/Gender :-  </b><?php echo $data1->age ."/". $data1->gender; ?></td>
			</tr>
			<tr>
				<td align="left" colspan="2"><b>Address :- </b><?php echo $data1->address ?></td>
			</tr>
			<tr>
				<td><b>DOA :-</b> <?php echo $data1->a_date ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <b>
					    Time :- </b><?php echo $data1->time_of_admission ?></td>
				<td><b>DOD :-</b> <?php echo $data1->dis_date ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <b>
					      Time :- </b><?php echo $data1->dischargetime ?></td>
			</tr>
				<tr>
				<td><b>Diagnosis :-   </b><?php echo $data1->diagnosis ?></td>
				<td><b>Treating Doctor :- </b><?php echo $data1->referred_to ?></td>
			</tr>
			<tr>
				<td align="left" colspan="2"><b>Remark</b><?php echo $data1->remark ?></td>
			</tr>
			<tr>
				<td align="left" colspan="2"><b>Treatment Given During Hospitalisation :-  </b>
				     <span>&nbsp;&nbsp; &nbsp; &nbsp;</span><?php 
				     foreach ($rears as $val){
				     	echo $val.', ';
				     }
				     ?></td>
			</tr>
			<tr>
					<td align="left" colspan="2">
						<span><b>Vitals On Discharge :-</b> </span><br />
            <span>T :- <?php echo $data1->t ?>&#8457; &nbsp; &nbsp; P :- <?php echo $data1->p ?> /min  &nbsp;&nbsp; &nbsp;
            R :- <?php echo $data1->r ?> /min  &nbsp;&nbsp; &nbsp; 
            BP :- <?php echo $data1->bp ?> /mmHg &nbsp;&nbsp; &nbsp;
            RBS :-<?php echo $data1->rbs ?>  &nbsp;&nbsp; &nbsp;SPO2 :- <?php echo $data1->spo2 ?>% </span></td>
      </tr>
      <tr>
				<td align="left" colspan="2"><b>Discharge Summary :-  </b><?php echo $data1->summary ?>
				     <span>&nbsp;&nbsp; &nbsp; &nbsp;</span></td>
			</tr>
      <tr>
				<td align="left" colspan="2"><b>Treatment On Discharge  :-  </b><?php 
				for($i=0;$i<$count;$i++){
	echo  "<br>Madicine :-  ".$medicines[$i]->medicine." ,  Morning :-  ".$medicines[$i]->morning." , Noon :-  ".$medicines[$i]->noon. " Naght :- ".$medicines[$i]->night." Tab/Spoon :- ".$medicines[$i]->tab_spoon." Days :-".$medicines[$i]->days."  Advice :- ".$medicines[$i]->advice."<br>";

		} ?>
				     <span>&nbsp;&nbsp; &nbsp; &nbsp;</span></td>
			</tr>
      <tr>
				<td align="left" colspan="2"><b>Patient Condition On Discharge  :-  </b><?php echo $data1->condition_on_dis ?>
				     <span>&nbsp;&nbsp; &nbsp; &nbsp;</span></td>
			</tr>
      <tr>
				<td align="left" colspan="2"><b>Investigation Detail On Discharge  :-  </b><?php echo $data1->investigation_detail_dis ?>
				     <span>&nbsp;&nbsp; &nbsp; &nbsp;</span></td>
			</tr>
      <tr>
				<td align="left" colspan="2"><b>Advice On Discharge  :-  </b><?php echo $data1->advice_on_dis ?>
				     <span>&nbsp;&nbsp; &nbsp; &nbsp;</span></td>
			</tr>
      <tr>
				<td align="left" colspan="2"><b>Follow Up After  :-  </b><?php echo $data1->follow_up_after ?>
				     <span>&nbsp;&nbsp; &nbsp; &nbsp;</span></td>
			</tr>
			
		</table><br><br>
		<div>
		<p align="right" class="cellpadding"><b>Authorised Signatory </b></p>
		</div>
		</center>
		</div>
	</div>

	  <div class="tm_invoice_btns">
        <a href="javascript:window.print()" class="tm_invoice_btn tm_color1">
          <!--<span class="tm_btn_icon">-->
            <!--<svg xmlns="http://www.w3.org/2000/svg" class="ionicon" viewBox="0 0 6900 6900"><path d="M384 368h24a40.12 40.12 0 0040-40V168a40.12 40.12 0 00-40-40H104a40.12 40.12 0 00-40 40v160a40.12 40.12 0 0040 40h24" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/><rect x="128" y="240" width="256" height="208" rx="24.32" ry="24.32" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/><path d="M384 128v-24a40.12 40.12 0 00-40-40H168a40.12 40.12 0 00-40 40v24" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/><circle cx="392" cy="184" r="24" fill='currentColor'/></svg>-->
            
          <!--</span>-->
          <!--<i class="fa fa-print tm_btn_text" aria-hidden="true">Print</i>-->
          <!--<span class="tm_btn_text">Print</span>-->
        </a>
        <!--<button id="tm_download_btn" class="tm_invoice_btn tm_color2">-->
        <!--  <span class="tm_btn_icon">-->
        <!--    <svg xmlns="http://www.w3.org/2000/svg" class="ionicon" viewBox="0 0 512 512"><path d="M320 336h76c55 0 100-21.21 100-75.6s-53-73.47-96-75.6C391.11 99.74 329 48 256 48c-69 0-113.44 45.79-128 91.2-60 5.7-112 35.88-112 98.4S70 336 136 336h56M192 400.1l64 63.9 64-63.9M256 224v224.03" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/></svg>-->
        <!--  </span>-->
        <!--  <span class="tm_btn_text">Download</span>-->
        <!--</button>-->
      </div>
</div>
</div>
</body>
<?php
include 'views/footer.php';
?>
</html>
<script>
// 	(function ($) {
//   'use strict';

//   $('#tm_download_btn').on('click', function () {
//   	console.log('heelooo');
//     var downloadSection = $('#tm_download_section');
//     var cWidth = downloadSection.width();
//     var cHeight = downloadSection.height();
//     var topLeftMargin = 0;
//     var pdfWidth = cWidth + topLeftMargin * 2;
//     var pdfHeight = pdfWidth * 1.5 + topLeftMargin * 2;
//     var canvasImageWidth = cWidth;
//     var canvasImageHeight = cHeight;
//     var totalPDFPages = Math.ceil(cHeight / pdfHeight) - 1;

//     html2canvas(downloadSection[0], { allowTaint: true }).then(function (
//       canvas
//     ) {
//       canvas.getContext('2d');
//       var imgData = canvas.toDataURL('image/png', 1.0);
//       var pdf = new jsPDF('p', 'pt', [pdfWidth, pdfHeight]);
//       pdf.addImage(
//         imgData,
//         'PNG',
//         topLeftMargin,
//         topLeftMargin,
//         canvasImageWidth,
//         canvasImageHeight
//       );
//       for (var i = 1; i <= totalPDFPages; i++) {
//         pdf.addPage(pdfWidth, pdfHeight);
//         pdf.addImage(
//           imgData,
//           'PNG',
//           topLeftMargin,
//           -(pdfHeight * i) + topLeftMargin * 0,
//           canvasImageWidth,
//           canvasImageHeight
//         );
//       }
//       pdf.save('download.pdf');
//     });
//   });

// })(jQuery);
</script>
	

