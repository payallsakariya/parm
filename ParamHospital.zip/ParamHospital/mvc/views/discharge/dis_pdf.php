<html>
	<?php include 'views/css.php'; ?>
<head>
<style>
body {font-family: Verdana;
    font-size: 14pt;
}


td{
    text-align: left;
    border: 0.1mm solid #000000;
}
.div{
    text-align: left;
    border: 0.1mm solid #000000;
}
.center{
	text-align: center;
}
/*@page {*/
/*margin-top: 4cm;*/
/*}*/
</style>
</head>
<div class="">
		    <div class="content">
		        <div class="row">
		         <div class="col-lg-11 offset-lg-1">
		                <div class="table-responsive">
		                	<br><br><br>
		                				<center>
					                  <div class="col-sm-4">
					                    <div class="center pl-6">
					                        <label><b><u>DISCHARGE CARD</u></b></label>
					                    </div>
					                </div>
					                </center><br><br>
					                <table><tr>
					                	<td width="50%" style="color:#0000BB;">
					                		<span style="font-weight:Bold; font-size: 12pt;"></span></td>
                             <td width="10%" style="text-align: left; " style="font-size:10pt">
                              <b>Date &nbsp; :- </b>&nbsp;&nbsp;
                             </td>
                         </tr></table>
                         <sethtmlpageheader name="myheader" value="on" show-this-page="1" />
                         <table class="items" width="100%" style="font-size: 10pt; border-collapse: collapse;" cellpadding="5">
													<tr>
													  <td align="left" colspan="2"><b>PMSH Id No. :- </b></td></tr>
                           <tr>
                              <td align="left"><b>Patient  Name :- </b></td>
                              <td align="left"><b>Age/Gender :-</b></td></tr>
                           <tr><td align="left" colspan="2"> <b>Address :- </b></td></tr>
                           <tr><td align="left"><b>DOA :-</b>  30-9-3&nbsp;&nbsp; &nbsp;  <b>Time :-</b>
                                </td><td align="left"><b>DOD :-</b>&nbsp;&nbsp; &nbsp; <b>Time :- </b>
                              </td></tr><tr><td align="left"><b>Diagnosis :-</b>
                              </td><td align="left"><b>Treating Doctor :-</b>
                              </td></tr><tr><td align="left" colspan="2"><b>Remark :-</b>
                              </td></tr><tr><td align="left" colspan="2"><span><b>Treatment Given During Hospitalisation :- </b>  </span>
                              <br /><span>&nbsp;&nbsp; &nbsp; &nbsp;</span>
                              </td>
															</tr>
															<tr>
															<td align="left" colspan="2"><span><b>Vitals On Discharge :-</b> </span><br />
															<span>T :- 32&#8457;  P :- 54 /min R :- 65 /min BP :- 65 /mmHg RBS:-76 SPO2:- 76% </span>
                         </td></tr><tr>
													<td align="left" colspan="2"><span><b>Discharge Summary :-</b> </span><br />
													</tr><tr>
													<td align="left" align="left" colspan="2"><span><b>Treatment On Discharge :-</b>  </span>
													<span><br /><span>
														&nbsp;&nbsp; &nbsp; &nbsp; teart &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;treat &nbsp;&nbsp;
														&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 
														&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 
														&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;    treat&nbsp;&nbsp; 
														&nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp; Days </span>
												</td></tr><tr><td align="left" colspan="2"><b>Patient Condition On Discharge :-</b>
												</td></tr><tr><td align="left" colspan="2"><b>Investigation Detail On Discharge :-</b>
												</td></tr><tr>
													<td align="left" colspan="2"><span><b>Advice On Discharge :-</b> </span><br />
													<span> nl2br($r[7])</span></td></tr><tr>
                         <td align="left" colspan="2"><span><b>Follow Up After </b></span></td></tr>
													</table> <br/><br/><div align="right"><div><br/><br/><br/><br/>
		<div align="right"><b>Authorised Signatory </b>													
													<br><br>
					                <center>
					                	
               </center>
		    		</div>
		     </div>
      </div>
  </div>
</div>
<div class="content">
		        <div class="row">
		         <div class="col-lg-11 offset-lg-1">
                   <caption style="text-align:right">date</caption>
					      <table class="items" width="100%" style="font-size: 10pt; border-collapse: collapse;" cellpadding="5">
              							<tr><td><b>PMSH Id No. :- </b></td><td></td></tr>		
              							<tr><td ><b>Patient  Name :- </b></td>
              								<td><b>Age/Gender :- :- </b></td></tr>
              								<tr><td>Address :-</td></tr>
              					
								      
              </table>
              </div>
              </div>
              </div>

	<?php include 'views/footer.php'; ?>
</html>
<BR><BR>