<?php
$discharge_pateint = $_SESSION['dischargepatient'];
$edit_dis_info=$_SESSION['select_dis_edit_data'];
$dis_view_info = $_SESSION['select_dis_view_data'];
if(!empty($dis_view_info)){
	$readonly='readonly';
	$disabled='disabled';
	$hidden='hidden';
  $edit_dis_info =	$dis_view_info;
}
// echo "<pre>";
// print_r($discharge_pateint);
// print_r($edit_dis_info);exit;
include 'views/header.php'; ?>
 <style>
				.bg{
					background-color: #0fa7c9;
					color: #fff;
				}
				.bd{
				border: 1px solid #ced4da;
				}
				.form_controt{
					    /*border-radius: 0;*/
					    /*border-style: solid*/
					        font-weight: 400;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    
    box-shadow: none;
    padding: 10px;
    /*border-color: #eb666682;*/
    font-size: 12px;
    min-height: 40px;
				}
		.time{
    font-weight: 400;
    line-height: 1;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    
    box-shadow: none;
    padding: 10px;
    /*border-color: #eb666682;*/
    font-size: 12px;
    min-height: 40px;
				}
				.table{
					color: #403939;
				}
			</style>
<div class="page-wrapper">
		    <div class="content">
		        <div class="row">
		         <div class="col-lg-11 offset-lg-1">
		         	<div class="row">
		            <div class="col-lg-12 offset-lg-12">
		                <h4 class="page-title">Discharge Form</h4>
		            </div>
		        </div>
		         <div class="row">
		                  <div class="col-md-12">
		                      <div class="table-responsive">
		                      	<table id="tbl" class="table display" style="width:100%" >
		                          <!--<table class="table table-border table-striped custom-table datatable mb-0 " id="tbl">-->
		                              <thead>
		                                  <tr class="bg"></tr>
		                                  <tr class="bg">
		                                      <th scope="col">PMSH Id</th>
		                                      <th scope="col">Patient Name</th>
		                                      <th scope="col">Age</th>
		                                      <th scope="col">Gender</th>
		                                      <th scope="col">Address</th>
		                                      <th scope="col">Diagnosis</th>
		                                      <th scope="col">Date of  Admission</th>
		                                      <th scope="col">Time of Admission</th>
		                                      <th></th>
		                                      <th></th>
		                                  </tr>
		                              </thead>
		                              <tbody>
		                              	<tr>
		                              	<td><?php echo $discharge_pateint->pmshid; ?></td>
		                              	<td><?php echo $discharge_pateint->Name; ?></td>
                                   <td><?php echo $discharge_pateint->age; ?></td>
		                              	<td><?php echo $discharge_pateint->gender; ?></td>
		                              	<td><?php echo $discharge_pateint->address; ?></td>
		                              	<td><?php echo $discharge_pateint->provisional_diagnosis; ?></td>
		                              	<td><?php echo $discharge_pateint->date_of_admission; ?></td>
		                              	<td><?php echo $discharge_pateint->time_of_admission; ?></td>
		                              	 <td><input type="text"  id="pid" name="pid" size="2" readonly 
										                    value="<?php echo $discharge_pateint->pid;?>" hidden></td>
											           	       <td><input type="text"  id="caseid" name="caseid" size="2" readonly
											           	       value="<?php echo $discharge_pateint->caseid;?>" hidden>
											           	       <input type="text"  id="date" name="date" size="1" readonly
											           	       value="<?php echo $discharge_pateint->date;?>" hidden>
											           	       <input type="text"  id="admission_id" name="admission_id" size="1" readonly
											           	       value="<?php echo $discharge_pateint->admission_id;?>" hidden>
											           	       <input type="text"  id="tid" name="tid" size="1" readonly
											           	       value="<?php echo $discharge_pateint->id;?>" hidden>
											           	       </td>
		                              	</tr>
		                              </tbody>
		                        </table>
					    			   </div>
				             </div>
				          </div><br><br>
		          <form  method="post">
		          			                              	 <td><input type="text"  id="pid" name="pid" size="2" readonly 
										                    value="<?php echo $discharge_pateint->pid;?>" hidden></td>
											           	       <td><input type="text"  id="caseid" name="caseid" size="2" readonly
											           	       value="<?php echo $discharge_pateint->caseid;?>" hidden>
											           	       <input type="text"  id="date" name="date" size="1" readonly
											           	       value="<?php echo $discharge_pateint->date;?>" hidden>
											           	       <input type="text"  id="admission_id" name="admission_id" size="1" readonly
											           	       value="<?php echo $discharge_pateint->admission_id;?>" hidden>
											           	       <input type="text"  id="tid" name="tid" size="1" readonly
											           	       value="<?php echo $discharge_pateint->id;?>" hidden>
											           	       </td>
			          <div class="row">
			          	
			          	   <?php  if($edit_dis_info){ 
				          // print_r($edit_dis_info);
				          	$format_date_convat=date("d-m-Y", strtotime($edit_dis_info->formatdate));
				          	$dis_date_convat=date("d-m-Y", strtotime($edit_dis_info->dischargedate));
				          ?>
				         
				             <div class="col-sm-4">
			                 	 <label for="f_date">Format Date</label>
			                 	 <!--<input class="form-control bd" type="f_date" id="f_date" name="f_date"-->
			                   <!--     value="">-->
			                    <input type="text" class="form-control datetimepicker bd" 
			                    name="f_date"id="f_date" value="<?php echo $format_date_convat;?>" <?php echo $readonly; ?>>
			                </div>
			                 <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="date_dt">Date of Discharge/Transfers</label>
			                        
			                        <!--<input class="form-control bd"  type="date" name="date_dt"  id="date_dt" value="" />-->
			                        <input type="text" class="form-control datetimepicker bd" 
			                        name="date_dt"id="date_dt" value="<?php echo $dis_date_convat; ?>"  <?php echo $readonly; ?> >
			                    </div>
			                </div>
			                <?php 
			                //$time=date('h:i:a');
			                	$time=date('h:i:a', strtotime($edit_dis_info->dischargetime));
			                $arr=explode(':',$time);
			                $follow_up_after=$edit_dis_info->follow_up_after;
			                $fua_arr=explode(' ',$follow_up_after);
			                ?>
			                 <div class="col-sm-4">
			                 	<label for=""> Time of Discharge  </label>
			                    <div class="form-group">
																	 <select name="hour" class="bd time bd" <?php echo $disabled ?>>
															     <option value="01" <?php if($arr[0] == '01'){echo 'Selected'; } ?> >01</option>
															     <option value="02" <?php if($arr[0] == '02'){echo 'Selected'; } ?>>02</option>
															     <option value="03" <?php if($arr[0] == '03'){echo 'Selected'; } ?>>03</option>
															     <option value="04" <?php if($arr[0] == '04'){echo 'Selected'; } ?>>04</option>
															     <option value="05" <?php if($arr[0] == '05'){echo 'Selected'; } ?>>05</option>
															     <option value="06" <?php if($arr[0] == '06'){echo 'Selected'; } ?>>06</option>
															     <option value="07" <?php if($arr[0] == '07'){echo 'Selected'; } ?>>07</option>
															     <option value="08" <?php if($arr[0] == '08'){echo 'Selected'; } ?>>08</option>
															     <option value="09" <?php if($arr[0] == '09'){echo 'Selected'; } ?>>09</option>
															     <option value="10" <?php if($arr[0] == '10'){echo 'Selected'; } ?>>10</option>
															     <option value="11" <?php if($arr[0] == '11'){echo 'Selected'; } ?>>11</option>
															     <option value="12" <?php if($arr[0] == '12'){echo 'Selected'; } ?>>12</option>
																</select>
															    
															   <!----------min..........------------->
															    <select name="min" class="bd time bd" <?php echo $disabled ?>>
															     <option value="00" <?php if($arr[1] == '00'){echo 'Selected'; } ?>>00</option>
															     <option value="01" <?php if($arr[1] == '01'){echo 'Selected'; } ?>>01</option>
															     <option value="02" <?php if($arr[1] == '02'){echo 'Selected'; } ?>>02</option>
															     <option value="03" <?php if($arr[1] == '03'){echo 'Selected'; } ?>>03</option>
															     <option value="04" <?php if($arr[1] == '04'){echo 'Selected'; } ?>>04</option>
															     <option value="05" <?php if($arr[1] == '05'){echo 'Selected'; } ?>>05</option>
															     <option value="06" <?php if($arr[1] == '06'){echo 'Selected'; } ?>>06</option>
															     <option value="07" <?php if($arr[1] == '07'){echo 'Selected'; } ?>>07</option>
															     <option value="08" <?php if($arr[1] == '08'){echo 'Selected'; } ?>>08</option>
															     <option value="09" <?php if($arr[1] == '09'){echo 'Selected'; } ?>>09</option>
															
															    <?php
																for($i=10;$i<=59;$i++)
																{?>
															    <option value=<?php echo $i?> <?php if($arr[1] == $i){echo 'Selected'; }?>><?php echo $i?></option>
															    <?php } ?>
																</select>
															    
															    
															   <!----------min..........------------->
															   <select name="ampm" class="bd time bd" <?php echo $disabled ?>>
															     <option value="AM" <?php if($arr[2] == 'am'){echo 'Selected'; } ?>>AM</option>
															     <option value="PM" <?php if($arr[2] == 'pm'){echo 'Selected'; } ?>>PM</option>
															</select>
																		                     
			                    </div>
			                </div>
			                
			                <div class="form-group col-sm-4">
			                        <label for="operated">Operated</label><span class="text-danger pl-2">*</span>
			                        <select name="operated" id="operated" class=" form-control bd" <?php echo $disabled ?>>
														    <option value="No" <?php if($edit_dis_info->operated == 'No'){echo 'Selected'; } ?>>No</option>
														    <option value="Yes" <?php if($edit_dis_info->operated == 'Yes'){echo 'Selected'; } ?> >Yes</option>
														    </select>
			                    </div>
			                    <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="consultant">Consultant</label>
			                        <input class="form-control bd" type="text" id="consultant" name="consultant"
			                        value="<?php echo $edit_dis_info->consultant ?>"  <?php echo $readonly; ?>>
			                    </div>
			                </div>
			         </div>
		        <hr>
		        <h2>Summary</h2>
		        <hr><br>
		        <div class="row">
		        	<div class="col-md-12">
		        		<label for="vod">Vital On Discharge</label>
		        	</div>
		         <div class="col-sm-4">
                  <div class="form-group">
                      <label for="t" class="control-label">T</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="t" id="t"  size="20"
									        value="<?php echo $edit_dis_info->t ?>" <?php echo $readonly; ?> >&#8457;
                  </div>
              </div>
              <div class="col-sm-4">
                  <div class="form-group">
                  	&nbsp;&nbsp;&nbsp;&nbsp;
                      <label for="p" class="control-label">P</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="p" id="p"  size="20"
									        value="<?php echo $edit_dis_info->p ?>" <?php echo $readonly; ?>>/min
                  </div>
              </div>
                <div class="col-sm-4">
                  <div class="form-group">
                  	&nbsp;&nbsp;&nbsp;&nbsp;
                      <label for="bp" class="control-label">BP</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="bp" id="bp"  size="20"
									        value="<?php echo $edit_dis_info->bp ?>" <?php echo $readonly; ?> >mmHg;
                  </div>
              </div>
              
               <div class="col-sm-4">
                  <div class="form-group">
                      <label for="r" class="control-label">R</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="r" id="r"  size="20"
									        value="<?php echo $edit_dis_info->r ?>"  <?php echo $readonly; ?>>/min
                  </div>
              </div>
              
               <div class="col-sm-4">
                  <div class="form-group">
                      <label for="rbs" class="control-label">RBS</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="rbs" id="rbs"  size="20"
									        value="<?php echo $edit_dis_info->rbs ?>"  <?php echo $readonly; ?>>mg/dl
                  </div>
              </div>
              
             
              
               <div class="col-sm-4">
                  <div class="form-group">
                      <label for="spo2" class="control-label">SPO2</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="spo2" id="spo2"  size="20" 
									        value="<?php echo $edit_dis_info->spo2 ?>" <?php echo $readonly; ?>> %
                  </div>
              </div><br><br>
              
               <div class="col-sm-6">
	                    <div class="form-group">
	                        <label for="pat_cnd_dis">Patient Condition On Discharge </label>
	                        <input class="form-control bd" type="text" id="pat_cnd_dis"
	                        name="pat_cnd_dis" value="<?php echo $edit_dis_info->condition_on_dis ?>"  <?php echo $readonly; ?>> 
	                    </div>
			          </div>
			          
               <div class="col-sm-6">
	                    <div class="form-group">
	                        <label for="inv_det_dis">Investigation Detail On Discharge </label>
	                        <input class="form-control bd" type="text" id="inv_det_dis" 
	                        name="inv_det_dis" value="<?php echo $edit_dis_info->investigation_detail_dis ?>"  <?php echo $readonly; ?>>
	                    </div>
			          </div>
               <div class="form-group col-sm-6">
                      <label for="dis_summary">Discharge Summary</label>
                      <textarea class="form-control bd" id="dis_summary" 
                      name="dis_summary"rows="3"  <?php echo $readonly; ?>><?php echo $edit_dis_info->summary ?></textarea>
                  </div>
               <div class="form-group col-sm-6">
                      <label for="advice_dis">Advice On Discharge</label>
                      <textarea class="form-control bd" id="advice_dis" name="advice_dis"rows="3" <?php echo $readonly; ?>>
                      	<?php echo $edit_dis_info->advice_on_dis ?>
                      </textarea>
                  </div>
               <div class="form-group col-sm-6">
                      <label for="remark">Remark</label>
                      <textarea class="form-control bd" id="remark" name="remark"rows="3" <?php echo $readonly; ?>>
                      	<?php echo $edit_dis_info->remark ?>
                      </textarea>
                  </div>
               <div class="form-group col-sm-4">
                      <label for="followupday">Follow Up After</label>
                    <div><input class="bd" type="text" name="followupday"  size="10" 
                          value="<?php echo $fua_arr[0] ?>" <?php echo $readonly; ?> >
											<select name="followdmy"  class="bd" <?php echo $disabled ?> >
											    <option value="Days" <?php if($fua_arr[1] == 'Days') {echo 'Selected';} ?>>Days</option>
											    <option value="Month" <?php if($fua_arr[1] == 'Month') {echo 'Selected';} ?>>Month</option>
											    </select>
											</td></div>
                  </div>
              </div>
              
              
                 <table align=center class="table display" id="Treatmentadd" style="width:100%" >
											   <thead>Treatment in Hospitalisation</thead>
											   <?php if($hidden){ 
						              }else{
						              	?>
						              <tbody>
											       <td>Treatment Given During Hospitalisation &nbsp; <input class="bd form_controt tgdh" 
											         type="text"  name="tgdh" id="tgdh" size="33"> 
											       <td><input class="bd form_controt treat_id" 
											         type="text"  name="treat_id" id="treat_id"  value=""  hidden> 
											     	 <td class="pt-4"><input type="button" name="up_Trt_in_hosppital"  
												        id="up_Trt_in_hosppital" class="up_Trt_in_hosppital" value="Update" hidden="hidden"></td>
											   	   <td class="pt-4"><input type="button" name="add_Trt_in_hosppital"  
											   	     id="add_Trt_in_hosppital" class="add_Trt_in_hosppital" value="Add"></td>
													 	</tbody>	
						              	<?php
						              }
						              ?>
											   		
										 </table>
			 
		        <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                        	<table id="treatment_name" class="table display table" style="width:100%">
                             <!--<table class="table table-border table-striped custom-table datatable mb-0 " id="tbl">-->
                                <thead>
                                    <tr style="background-color:#ddd">
                                        <th scope="col">Treatment</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
				     </div>
				     <br><br>
				     
				      	<table align=center class="table display form-group" id="Treatmentadd" 
				      	      style="width:100%" style="min-height: 374px; color: #495057">
											   <thead>Treatment On Discharge</thead>
											    <?php if($hidden){ 
						              }else{
						              	?>
						              	<tbody>
											   			<tr>
											         <td>Medicine&nbsp;
											             <input class="bd form_controt medicine" type="text"  name="Medicine" 
											             id="Medicine" size="30"> 
											       </td>
											        <td>
												          Advice&nbsp;
												          <input class="bd form_controt advice" type="text"  
												          name="Advice" id="Advice" size="30"></td>
												          </tr>
															   <tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
															   Qty&nbsp;&nbsp;
															        <select name="sel1" id="moring" class="bd form_controt c_DMY moring" >
															            <option value="0" id="target">0</option>
															           <option value="1">1</option>
															        </select>
															        <select name="sel2" id="noon" class="bd form_controt c_DMY noon">
															            <option value="0" id="target">0</option>
															           <option value="1">1</option>
															        </select>
															        <select name="sel3" id="night" class="bd form_controt c_DMY night">
															            <option value="0" id="target">0</option>
															           <option value="1">1</option>
															        </select>
															        <select name="sel4" id="size" class="bd form_controt c_DMY size">
															            <option value="Tab" id="target">Tab</option>
															           <option value="Spoon">Spoon</option>
															        </select>
															 <!--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-->
															       <td> &nbsp;&nbsp;
															       days&nbsp;&nbsp; 
															        <input class="bd form_controt day" type="text" name="days" id="days" size="25"></td>
															        </td>
															         <td><input class="bd form_controt madicin_id" 
											         type="text"  name="madicin_id" id="madicin_id"  value="" hidden=""> 
															        	<td class="pt-4"><input type="button" name="up_madicine_on_discharge"  
															        	id="up_madicine_on_discharge" class="up_madicine_on_discharge" value="Update" hidden="hidden"></td>
																	   	<td class="pt-4"><input type="button" name="add_madicine_on_discharge"  
																	   	id="add_madicine_on_discharge" class="add_madicine_on_discharge" value="Add"></td>
															        </tr>
											

													 	</tbody>
						              	<?php
						              }
						              ?>
											   		
										 </table>
			 
		        <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                        	<table id="madicine_name" class="table display table" style="width:100%">
                             <!--<table class="table table-border table-striped custom-table datatable mb-0 " id="tbl">-->
                                <thead>
                                    <tr style="background-color:#ddd">
                                        <th scope="col">Medicine</th>
                                        <th scope="col">Advice</th>
                                        <th scope="col">Qty</th>
                                        <th scope="col">Days</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
				     </div> 
				     <?php if($dis_view_info){ ?>
				           <div class="text-center">
						         	<!--<input type="submit" name="Save" value="Save" id="Save" class="btn btn-primary ">-->
			                <input type="submit" name="close" value="close" id="close" class="btn btn-danger close-btn1 ">
			         </div>
			         <?php }else {
			         	?>
			         	<div class="text-center">
						         	<input type="submit" name="Update" value="Update" id="Update" class="btn btn-primary ">
			                <input type="submit" name="cancel_up" value="cancel" id="cancel_up" class="btn btn-danger cancel-btn1 ">
			         </div>
			         	<?php
			         } ?>
				          <?php
			          	   }else{
			          	   	?>
			          	   	    <div class="col-sm-4">
			                 	 <label for="f_date">Format Date</label>
			                 	 <!--<input class="form-control bd" type="f_date" id="f_date" name="f_date"-->
			                   <!--     value="">-->
			                    <input type="text" class="form-control datetimepicker bd" name="f_date"id="f_date" value="<?php echo date('d-m-Y');?>">
			                </div>
			                 <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="date_dt">Date of Discharge/Transfers</label>
			                        
			                        <!--<input class="form-control bd"  type="date" name="date_dt"  id="date_dt" value="" />-->
			                        <input type="text" class="form-control datetimepicker bd" name="date_dt"id="date_dt" value="<?php echo date('d-m-Y');?>">
			                    </div>
			                </div>
			                <?php  $time=date('h:i:a');
			                $arr=explode(':',$time);
			                ?>
			                 <div class="col-sm-4">
			                 	<label for=""> Time of Discharge  </label>
			                    <div class="form-group">
																	 <select name="hour" class="bd time bd">
															     <option value="01" <?php if($arr[0] == '01'){echo 'Selected'; } ?> >01</option>
															     <option value="02" <?php if($arr[0] == '02'){echo 'Selected'; } ?>>02</option>
															     <option value="03" <?php if($arr[0] == '03'){echo 'Selected'; } ?>>03</option>
															     <option value="04" <?php if($arr[0] == '04'){echo 'Selected'; } ?>>04</option>
															     <option value="05" <?php if($arr[0] == '05'){echo 'Selected'; } ?>>05</option>
															     <option value="06" <?php if($arr[0] == '06'){echo 'Selected'; } ?>>06</option>
															     <option value="07" <?php if($arr[0] == '07'){echo 'Selected'; } ?>>07</option>
															     <option value="08" <?php if($arr[0] == '08'){echo 'Selected'; } ?>>08</option>
															     <option value="09" <?php if($arr[0] == '09'){echo 'Selected'; } ?>>09</option>
															     <option value="10" <?php if($arr[0] == '10'){echo 'Selected'; } ?>>10</option>
															     <option value="11" <?php if($arr[0] == '11'){echo 'Selected'; } ?>>11</option>
															     <option value="12" <?php if($arr[0] == '12'){echo 'Selected'; } ?>>12</option>
																</select>
															    
															   <!----------min..........------------->
															    <select name="min" class="bd time bd" >
															     <option value="00" <?php if($arr[1] == '00'){echo 'Selected'; } ?>>00</option>
															     <option value="01" <?php if($arr[1] == '01'){echo 'Selected'; } ?>>01</option>
															     <option value="02" <?php if($arr[1] == '02'){echo 'Selected'; } ?>>02</option>
															     <option value="03" <?php if($arr[1] == '03'){echo 'Selected'; } ?>>03</option>
															     <option value="04" <?php if($arr[1] == '04'){echo 'Selected'; } ?>>04</option>
															     <option value="05" <?php if($arr[1] == '05'){echo 'Selected'; } ?>>05</option>
															     <option value="06" <?php if($arr[1] == '06'){echo 'Selected'; } ?>>06</option>
															     <option value="07" <?php if($arr[1] == '07'){echo 'Selected'; } ?>>07</option>
															     <option value="08" <?php if($arr[1] == '08'){echo 'Selected'; } ?>>08</option>
															     <option value="09" <?php if($arr[1] == '09'){echo 'Selected'; } ?>>09</option>
															
															    <?php
																for($i=10;$i<=59;$i++)
																{?>
															    <option value=<?php echo $i?> <?php if($arr[1] == $i){echo 'Selected'; }?>><?php echo $i?></option>
															    <?php } ?>
																</select>
															    
															    
															   <!----------min..........------------->
															   <select name="ampm" class="bd time bd">
															     <option value="AM" <?php if($arr[2] == 'am'){echo 'Selected'; } ?>>AM</option>
															     <option value="PM" <?php if($arr[2] == 'pm'){echo 'Selected'; } ?>>PM</option>
															</select>
																		                     
			                    </div>
			                </div>
			                
			                <div class="form-group col-sm-4">
			                        <label for="operated">Operated</label><span class="text-danger pl-2">*</span>
			                        <select name="operated" id="operated" class=" form-control bd" >
														    <option value="No">No</option>
														    <option value="Yes">Yes</option>
														    </select>
			                    </div>
			                    <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="consultant">Consultant</label>
			                        <input class="form-control bd" type="text" id="consultant" name="consultant"
			                        value="">
			                    </div>
			                </div>
			         </div>
		        <hr>
		        <h2>Summary</h2>
		        <hr><br>
		        <div class="row">
		        	<div class="col-md-12">
		        		<label for="vod">Vital On Discharge</label>
		        	</div>
		         <div class="col-sm-4">
                  <div class="form-group">
                      <label for="t" class="control-label">T</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="t" id="t"  size="20"
									        value="" >&#8457;
                  </div>
              </div>
              <div class="col-sm-4">
                  <div class="form-group">
                  	&nbsp;&nbsp;&nbsp;&nbsp;
                      <label for="p" class="control-label">P</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="p" id="p"  size="20"
									        value="" >/min
                  </div>
              </div>
                <div class="col-sm-4">
                  <div class="form-group">
                  	&nbsp;&nbsp;&nbsp;&nbsp;
                      <label for="bp" class="control-label">BP</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="bp" id="bp"  size="20"
									        value="" >mmHg;
                  </div>
              </div>
              
               <div class="col-sm-4">
                  <div class="form-group">
                      <label for="r" class="control-label">R</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="r" id="r"  size="20"
									        value="" >/min
                  </div>
              </div>
              
               <div class="col-sm-4">
                  <div class="form-group">
                      <label for="rbs" class="control-label">RBS</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="rbs" id="rbs"  size="20"
									        value="" >mg/dl
                  </div>
              </div>
              
             
              
               <div class="col-sm-4">
                  <div class="form-group">
                      <label for="spo2" class="control-label">SPO2</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="spo2" id="spo2"  size="20"
									        value="" > %
                  </div>
              </div><br><br>
              
               <div class="col-sm-6">
	                    <div class="form-group">
	                        <label for="pat_cnd_dis">Patient Condition On Discharge </label>
	                        <input class="form-control bd" type="text" id="pat_cnd_dis" name="pat_cnd_dis">
	                    </div>
			          </div>
			          
               <div class="col-sm-6">
	                    <div class="form-group">
	                        <label for="inv_det_dis">Investigation Detail On Discharge </label>
	                        <input class="form-control bd" type="text" id="inv_det_dis" name="inv_det_dis">
	                    </div>
			          </div>
               <div class="form-group col-sm-6">
                      <label for="dis_summary">Discharge Summary</label>
                      <textarea class="form-control bd" id="dis_summary" name="dis_summary"rows="3"></textarea>
                  </div>
               <div class="form-group col-sm-6">
                      <label for="advice_dis">Advice On Discharge</label>
                      <textarea class="form-control bd" id="advice_dis" name="advice_dis"rows="3"></textarea>
                  </div>
               <div class="form-group col-sm-6">
                      <label for="remark">Remark</label>
                      <textarea class="form-control bd" id="remark" name="remark"rows="3"></textarea>
                  </div>
               <div class="form-group col-sm-4">
                      <label for="followupday">Follow Up After</label>
                    <div><input class="bd" type="text" name="followupday"  size="10"  >
											<select name="followdmy"  class="bd">
											    <option value="Days">Days</option>
											    <option value="Month">Month</option>
											    </select>
											</td></div>
                  </div>
              </div>
              
              
              <table align=center class="table display" id="Treatmentadd" style="width:100%" >
											   <thead>Treatment in Hospitalisation</thead>
											   		<tbody>
											       <td>Treatment Given During Hospitalisation &nbsp; <input class="bd form_controt tgdh" 
											         type="text"  name="tgdh" id="tgdh" size="33"> 
											       <td><input class="bd form_controt treat_id" 
											         type="text"  name="treat_id" id="treat_id"  value=""  hidden> 
											     	 <td class="pt-4"><input type="button" name="up_Trt_in_hosppital"  
												        id="up_Trt_in_hosppital" class="up_Trt_in_hosppital" value="Update" hidden="hidden"></td>
											   	   <td class="pt-4"><input type="button" name="add_Trt_in_hosppital"  
											   	     id="add_Trt_in_hosppital" class="add_Trt_in_hosppital" value="Add"></td>
													 	</tbody>
										 </table>
			 
		        <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                        	<table id="treatment_name" class="table display table" style="width:100%">
                             <!--<table class="table table-border table-striped custom-table datatable mb-0 " id="tbl">-->
                                <thead>
                                    <tr style="background-color:#ddd">
                                        <th scope="col">Treatment</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
				     </div>
				     <br><br>
				     
				      	<table align=center class="table display form-group" id="Treatmentadd" style="width:100%" style="min-height: 374px; color: #495057">
											   <thead>Treatment On Discharge</thead>
											   		<tbody>
											   			<tr>
											         <td>Medicine&nbsp;
											             <input class="bd form_controt medicine" type="text"  name="Medicine" id="Medicine" size="30"> 
											       </td>
											        <td>
												          Advice&nbsp;
												          <input class="bd form_controt advice" type="text"  
												          name="Advice" id="Advice" size="30"></td>
												          </tr>
															   <tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
															   Qty&nbsp;&nbsp;
															        <select name="sel1" id="moring" class="bd form_controt c_DMY moring">
															            <option value="0" id="target">0</option>
															           <option value="1">1</option>
															        </select>
															        <select name="sel2" id="noon" class="bd form_controt c_DMY noon">
															            <option value="0" id="target">0</option>
															           <option value="1">1</option>
															        </select>
															        <select name="sel3" id="night" class="bd form_controt c_DMY night">
															            <option value="0" id="target">0</option>
															           <option value="1">1</option>
															        </select>
															        <select name="sel4" id="size" class="bd form_controt c_DMY size">
															            <option value="Tab" id="target">Tab</option>
															           <option value="Spoon">Spoon</option>
															        </select>
															 <!--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-->
															       <td> &nbsp;&nbsp;
															       days&nbsp;&nbsp; 
															        <input class="bd form_controt day" type="text" name="days" id="days" size="25"></td>
															        </td>
															         <td><input class="bd form_controt madicin_id" 
											         type="text"  name="madicin_id" id="madicin_id"  value="" hidden=""> 
															        	<td class="pt-4"><input type="button" name="up_madicine_on_discharge"  
															        	id="up_madicine_on_discharge" class="up_madicine_on_discharge" value="Update" hidden="hidden"></td>
																	   	<td class="pt-4"><input type="button" name="add_madicine_on_discharge"  
																	   	id="add_madicine_on_discharge" class="add_madicine_on_discharge" value="Add"></td>
															        </tr>
											

													 	</tbody>
										 </table>
			 
		        <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                        	<table id="madicine_name" class="table display table" style="width:100%">
                             <!--<table class="table table-border table-striped custom-table datatable mb-0 " id="tbl">-->
                                <thead>
                                    <tr style="background-color:#ddd">
                                        <th scope="col">Medicine</th>
                                        <th scope="col">Advice</th>
                                        <th scope="col">Qty</th>
                                        <th scope="col">Days</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
				     </div>
				      <div class="text-center">
						         	<input type="submit" name="Save" value="Save" id="Save" class="btn btn-primary ">
			                <input type="button" name="cancel" value="cancel" id="cancel" class="btn btn-danger cancel-btn1 ">
			         </div>
			          	   	<?php
			          	   }
				          ?>
			                
			             
				    
              
            </form>
		     </div>
		          
		          
		          
		        </div>
		          <div id="del_treatment" class="modal fade delete-modal" role="dialog">
						    <div class="modal-dialog modal-dialog-centered">
						        <div class="modal-content">
						            <div class="modal-body text-center">
						            	<input type="text" id="del_c" name="del_c" value="" hidden="">
						                <img src="../assets/img/sent.png" alt="" width="50" height="46">
						                <h3>Are you sure want to delete this ?</h3>
						                <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
						                     <button type="button" class="btn btn-danger deletecdata" id="del_modal"><a href="#"  data-dismiss="modal">Delete</a></button>
						                </div>
						            </div>
						        </div>
						    </div>
						</div> 
						
		          <div id="del_madicine" class="modal fade delete-modal" role="dialog">
						    <div class="modal-dialog modal-dialog-centered">
						        <div class="modal-content">
						            <div class="modal-body text-center">
						            	<input type="text" id="del_M" name="del_M" value="" hidden="" >
						                <img src="../assets/img/sent.png" alt="" width="50" height="46">
						                <h3>Are you sure want to delete this ?</h3>
						                <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
						                     <button type="button" class="btn btn-danger deleteMdata" id="del_modal">
						                     	<a href="#"  data-dismiss="modal">Delete</a></button>
						                </div>
						            </div>
						        </div>
						    </div>
						</div> 
		    </div>
		  </div>
		  
		  
		  
		  
<?php include 'views/footer.php'; ?>
<script>
 $(document).ready(function() {
  	views_dis_tear();
 	views_dis_madicine();
 	//datepicker future date diseble start
		        var today = new Date();
		        $('#date_dt,#f_date').datepicker({
				            dateFormat: 'dd-mm-yy ',
				            autoclose:true,
				            changeMonth: true,
				            changeYear: true,
				            endDate: "today",
				            maxDate: today,
				             setDate : new Date(),
                    autoclose : true
				          }).on('changeDate', function (ev) {
				               $(this).datepicker('hide');
				      });
//End
				     
				     
				    // start Datepicker all key process stops(diseble)       
				        $('#date_dt').keyup(function () {
				        	$('#date_dt').keypress(
											  function(event){
											   event.preventDefault();
											});
				          })  
		        //End datepicker 
		        
		       
   
 	
 	
 	
  function views_dis_tear(){
   	  	 var	pid = document.getElementById("pid").value;
   	  	 var	id = document.getElementById("tid").value;
   	  	  var data ={
		   	    	'pid' : pid,
		   	    	'id' : id,
		   	    }
		   	    var t= $('#treatment_name').DataTable({
				    		processing: true,
					    	serverSide : false,
					    	 searchable: false,
				          orderable: false,
					    	ajax: {
					    		url: 'add_discharge_tear_liste',
					    		type: 'POST',
					    		 data : data,
							 	 	  		 datatype :"json",
					    	},
					    	
					    	
					    	columns: [
					    		// {data: 'id'},
					    		{data: 'treat'},
					    		{data: ''},
					    		],
					    		 columnDefs: [
					    	{
									"targets": -1,
									"data": "pid",
									"render": function ( data, type, row, meta ) {
									return "<td class='text-right'><div class='dropdown dropdown-action'><a href='#' class='action-icon dropdown-toggle' data-toggle='dropdown' aria-expanded='false'><i class='fa fa-ellipsis-v'></i></a><div class='dropdown-menu dropdown-menu-right'><button type='button' value='"+row.id+"' class='dropdown-item edit_c'><i class='fa fa-pencil m-r-5'></i> Edit</button><a class='dropdown-item deletecdata' href='#' data-toggle='modal' data-target='#del_treatment' data-dataid="+row.id+"><i class='fa fa-trash-o m-r-5'></i>Delete</a></div></div></td>";
									}
									}
									]
	    	
			});
			
			
 		  }	
 		  
  function views_dis_madicine(){
   	  	 var	pid = document.getElementById("pid").value;
   	  	  var	id = document.getElementById("tid").value;
   	  	  var data ={
		   	    	'pid' : pid,
		   	    	'id' : id
		   	    }
		   	    console.log(data);
		   	    console.log('data');
		   	    var t= $('#madicine_name').DataTable({
				    		processing: true,
					    	serverSide : false,
					    	 searchable: false,
				          orderable: false,
					    	ajax: {
					    		url: 'add_discharge_madicine_liste',
					    		type: 'POST',
					    		 data : data,
							 	 	  		 datatype :"json",
					    	},
					    	
					    	
					    	columns: [
					    		// {data: 'id'},
					    		{data: 'medicine'},
					    		{data: 'advice'},
					    		{data: 'qty'},
					    		{data: 'days'},
					    		{data: ''},
					    		],
					    		 columnDefs: [
					    	{
									"targets": -1,
									"data": "pid",
									"render": function ( data, type, row, meta ) {
									return "<td class='text-right'><div class='dropdown dropdown-action'><a href='#' class='action-icon dropdown-toggle' data-toggle='dropdown' aria-expanded='false'><i class='fa fa-ellipsis-v'></i></a><div class='dropdown-menu dropdown-menu-right'><button type='button' value='"+row.id+"' class='dropdown-item edit_m'><i class='fa fa-pencil m-r-5'></i> Edit</button><a class='dropdown-item deleteMdata' href='#' data-toggle='modal' data-target='#del_madicine' data-dataid="+row.id+"><i class='fa fa-trash-o m-r-5'></i>Delete</a></div></div></td>";
									}
									}
									]
	    	
			});
			
			
 		  }	
 	
 	
 	//add Treatment Given During Hospitalisation
	  $(document).on('click', '.add_Trt_in_hosppital',function(e){
				   	e.preventDefault();
				   	 var	pid = document.getElementById("pid").value;
				   	 var	caseid = document.getElementById("caseid").value;
				   	 var	admission_id = document.getElementById("admission_id").value;
		   	    var data ={
		   	    	'treat' : $('.tgdh').val(),
		   	    	'pid' : pid,
		   	    	'caseid' : caseid,
		   	    	'admission_id' : admission_id,
		   	    }
		   	    $.ajaxSetup({
							    headers: {
							        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
							    }
							});
		   	   
		   	    $.ajax({
				 	  		 type :'POST',
				 	  		 url :'add_teart',
				 	  		 data : data,
				 	  		 datatype :"datatype",
				 	  		 success: function(response){
				 	  		 	 $('.tgdh').val("");
		   	           $('#treatment_name').DataTable().ajax.reload();

				 	  		 } 
				 	  	})
		   });
	//End
	
	// update select Treatment Given During Hospitalisation
	   $(document).on('click', '.edit_c',function(e){
				   	e.preventDefault();
				   	var id = $(this).val();
				   	var data ={
		   	    	           'id' : id,
		   	              }
		   	              
				   	 $.ajax({
				 	  		 type :'POST',
				 	  		 url :'select_treat',
				 	  		 //cache : false,
				 	  		 data : data,
				 	  		 datatype :"datatype",
				 	  		 success: function(response){
				 	  		 	var t = JSON.parse(response);
				 	  		 	// console.log(t['obs_count']);
				 	  		 	// console.log(response);
				 	  		 	 $('.tgdh').val(t['treat']);
		   	          $('.treat_id').val(t['id']);
		   	          // $('.cid').val(t['id']);
		   	          // $('#obdmy1'). val(t['obs_dmy']); 
		   	          $(".add_Trt_in_hosppital").hide();
		   	           $(".up_Trt_in_hosppital").removeAttr('hidden');
		   	          $('#treatment_name').DataTable().ajax.reload();

				 	  		 } 
				 	  	})
		    });
  //End
		 
		 
	//update resonse and  update data
     $(document).on('click', '.up_Trt_in_hosppital',function(e){
						   	e.preventDefault();
				   	    var data ={
				   	    	'treat' : $('.tgdh').val(),
				   	    	'id' : $('.treat_id').val(),
				   	    }
				   	   
				   	    $.ajax({
					 	 	  		 type :'POST',
					 	 	  		 url :'update_treat',
					 	 	  		 data : data,
					 	 	  		 datatype :"datatype",
					 	 	  		 success: function(response){
					 	 	  		 	// console.log(response);
					 	 	  		 	$('.tgdh').val("");
				   	          $('.treat_id').val("");
				   	          $(".add_Trt_in_hosppital").show();
				   	          $(".up_Trt_in_hosppital").attr('hidden', 'hidden');
				   	          $('#treatment_name').DataTable().ajax.reload();
		
					 	 	  		 } 
					 	 	  	})
		        });
	//End    
 
  //delete data  Treatment Given During Hospitalisation
     $(document).on("click","a.deletecdata",function(e){
			     	  e.preventDefault();
		  		  delete_c_id = $(this).data('dataid');
		  		  	$('#del_c').val(delete_c_id);
		  		  // console.log(delete_c_id)
      });

	  $(document).on("click","button.deletecdata",function(){
	            	var id = $('#del_c').val();
					  	 var	pid = document.getElementById("pid").value;
					    const delet_id=[pid,id];
                $.ajaxSetup({
							        headers: {
							                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
							             }
							    });
							    
					  	  $.ajax({
							 	 	  		 type :'POST',
							 	 	  		 url :"delete_treat",
							 	 	  		 cache : false,
							 	 	  		 data : {'id':delet_id},
							 	 	  		 success: function(Code){
							 	 	  		 	// console.log(Code);
							 	 	  		 	 $(".deletecdata").attr('data-dismiss', 'modal');
							 	 	  		 	$('#treatment_name').DataTable().ajax.reload();
							 	 	  		 } 
							 	 	  	})
          });
      //End    
      
      
   
  	//add medicine
	  $(document).on('click', '.add_madicine_on_discharge',function(e){
				   	e.preventDefault();
				   	 var	pid = document.getElementById("pid").value;
				   	 var	caseid = document.getElementById("caseid").value;
				   	 var	admission_id = document.getElementById("admission_id").value;
		   	    var data ={
		   	    	'medicine' : $('.medicine').val(),
		   	    	'advice' : $('.advice').val(),
		   	    	'moring' : $('.moring').val(),
		   	    	'noon' : $('.noon').val(),
		   	    	'night' : $('.night').val(),
		   	    	'size' : $('.size').val(),
		   	    	'days' : $('.day').val(),
		   	    	'pid' : pid,
		   	    	'caseid' : caseid,
		   	    	'admission_id' : admission_id,
		   	    }
		   	    $.ajaxSetup({
							    headers: {
							        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
							    }
							});
		   	   
		   	    $.ajax({
				 	  		 type :'POST',
				 	  		 url :'add_madicine',
				 	  		 data : data,
				 	  		 datatype :"datatype",
				 	  		 success: function(response){
				 	  		 	 $('.medicine').val("");
				 	  		 	 $('.advice').val("");
				 	  		 	 $('.day').val("");
				 	  		 	 $("#moring").val($("#target option:first").val());
				 	  		 	 $("#noon").val($("#target option:first").val());
				 	  		 	 $("#night").val($("#target option:first").val());
				 	  		 	 $("#size").val($("#target option:first").val());
		   	           $('#madicine_name').DataTable().ajax.reload();

				 	  		 } 
				 	  	})
		   });
	//End
	
	// update medicine
	   $(document).on('click', '.edit_m',function(e){
				   	e.preventDefault();
				   	var id = $(this).val();
				   	var data ={
		   	    	           'id' : id,
		   	              }
		   	             console.log(data); 
				   	 $.ajax({
				 	  		 type :'POST',
				 	  		 url :'select_madicine',
				 	  		 //cache : false,
				 	  		 data : data,
				 	  		 datatype :"datatype",
				 	  		 success: function(response){
				 	  		 	var t = JSON.parse(response);
				 	  		 	 $('.medicine').val(t['medicine']);
		   	          $('.madicin_id').val(t['id']);
		   	          $('.advice').val(t['advice']);
		   	          $('.day').val(t['days']);
		   	          $('#moring'). val(t['morning']); 
		   	          $('#noon'). val(t['noon']); 
		   	          $('#night'). val(t['night']); 
		   	          $('#size'). val(t['tab_spoon']); 
		   	          $(".add_madicine_on_discharge").hide();
		   	           $(".up_madicine_on_discharge").removeAttr('hidden');
		   	          $('#madicine_name').DataTable().ajax.reload();

				 	  		 } 
				 	  	})
		    });
  //End
		 
		 
	//update resonse and  update medicine data
     $(document).on('click', '.up_madicine_on_discharge',function(e){
						   	e.preventDefault();
				   	    var data ={
				   	    'medicine' : $('.medicine').val(),
					   	    'advice' : $('.advice').val(),
					   	    'moring' : $('.moring').val(),
					   	    	'noon' : $('.noon').val(),
					   	     'night' : $('.night').val(),
					   	    	'size' : $('.size').val(),
					   	    	'days' : $('.day').val(),
				   	    	    'id' : $('.madicin_id').val(),
				   	    }
				   	   console.log(data);
				   	    $.ajax({
					 	 	  		 type :'POST',
					 	 	  		 url :'update_madicine',
					 	 	  		 data : data,
					 	 	  		 datatype :"datatype",
					 	 	  		 success: function(response){
					 	 	  		 	// console.log(response);
					 	 	  		 	 $('.medicine').val("");
						 	  		 	 $('.advice').val("");
						 	  		 	 $('.day').val("");
						 	  		 	 $("#moring").val($("#target option:first").val());
						 	  		 	 $("#noon").val($("#target option:first").val());
						 	  		 	 $("#night").val($("#target option:first").val());
						 	  		 	 $("#size").val($("#target option:first").val());
					   	         $(".add_madicine_on_discharge").show();
					   	         $(".up_madicine_on_discharge").attr('hidden', 'hidden');
					   	         $('#madicine_name').DataTable().ajax.reload();
		
					 	 	  		 } 
					 	 	  	})
		        });
	//End    
 
  //delete medicine data
     $(document).on("click","a.deleteMdata",function(e){
			     	  e.preventDefault();
		  		  delete_c_id = $(this).data('dataid');
		  		  	$('#del_M').val(delete_c_id);
		  		  // console.log(delete_c_id)
      });

	  $(document).on("click","button.deleteMdata",function(){
	            	var id = $('#del_M').val();
					  	 var	pid = document.getElementById("pid").value;
					    const delet_id=[pid,id];
                $.ajaxSetup({
							        headers: {
							                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
							             }
							    });
							    
					  	  $.ajax({
							 	 	  		 type :'POST',
							 	 	  		 url :"delete_madicine",
							 	 	  		 cache : false,
							 	 	  		 data : {'id':delet_id},
							 	 	  		 success: function(Code){
							 	 	  		 	// console.log(Code);
							 	 	  		 	 $(".deleteMdata").attr('data-dismiss', 'modal');
							 	 	  		 	$('#madicine_name').DataTable().ajax.reload();
							 	 	  		 } 
							 	 	  	})
          });
      //End        
      
	
 });
</script>