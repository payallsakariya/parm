<?php 

include 'views/header.php';
?>
<style>
	.icon{
		color: #607580;
	}
</style>
 <input type="text"  id="types" name="types" size="2" readonly value="<?php echo $_SESSION['type'][0]; ?>" hidden>
<!--<body>-->
<!--    <div class="main-wrapper">-->

        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-8 col-6">
                        <h4 class="page-title">Discharge Panding</h4>
                    </div>
                </div>
                
            
            <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table id="tbl_dis_charge" class="table table-border table-striped custom-table ">
                                <thead>
                                  <tr>
                                  	<th class="text-right">Action</th>
                                        <!--<th>#</th>-->
                                        <th>Case No</th>
                                        <th>Date</th>
                                        <th>Name</th>
                                        <th>Age</th>
                                        <th>Gender</th>
                                        <th>Phone</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                 <div id="del_admission" class="modal fade delete-modal" role="dialog">
						    <div class="modal-dialog modal-dialog-centered">
						        <div class="modal-content">
						            <div class="modal-body text-center">
						            	<input type="text" id="del_a" name="del_a" value="" hidden="">
						                <img src="../assets/img/sent.png" alt="" width="50" height="46">
						                <h3>Are you sure want to delete this ?</h3>
						                <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
						                    <!--<button type="button" class="btn btn-danger deletecdata" id="del_modal">Delete</button>-->
						                     <button type="button" class="btn btn-danger deletecdata" id="del_modal"><a href="#"  data-dismiss="modal">Delete</a></button>
						                </div>
						            </div>
						        </div>
						    </div>
						</div> 
            </div>
        </div>
<?php
include 'views/footer.php'; ?>

<!-- patients23:19-->

</html>
<script>
$(document).ready(function(){
	
	var t= $('#tbl_dis_charge').DataTable({
    		processing: true,
	    	serverSide : false,
	    	ajax: {
	    		url: 'discharge_panding_json',
	    		type: 'POST',
	    	},
	    
	    	columnDefs: [
            {
                searchable: false,
                orderable: false,
                targets: 0,
            },
        ],
	    	columns: [
	    		
	    		{data: 'pid'},
	    		// {data: 'caseid'},
	    		{data: 'pmshid'},
	    		{data: 'date'},
	    		{data: 'Name'},
	    		{data: 'age'},
	    		{data: 'gender'},
	    		{data: 'contact'},
	    	
	    		],
	    		
	    		
	     columnDefs: [
	     	{
					"targets": 0,
					"data": "pid",
					"render": function ( data, type, row, meta ) {
					console.log(row);
								// return "<td class='text-right'><a class='dropdown-item' href='AdmitPatient?p_id="+data+"&&case_id="+row.caseid+"'>Dicharge</a></td>";	
						return "<td><a href='discharge_patient?p_id="+data+"'><i class='fa fa-sign-out m-l-5 icon' title='Dicharge'></i></a></td>";
					}
	     	}
					]
			});	
	 
})
	  
</script>
				