<?php
include 'views/header.php';
$report_type = $_GET['report_type'];
if($report_type == 'daily'){
	 $hahind ='Daily Report';
}elseif($report_type == 'consultation'){
	$hahind ='Consultation Report';
}else{
	$hahind= 'Discharge Report';
}
?>
 <style>
				.bd{
				border: 1px solid #ced4da;
			 height: 36px!important;
				}
			</style>
<div class="page-wrapper">
		    <div class="content">
		        <div class="row">
		         <div class="col-lg-11 offset-lg-1">
		         	<div class="row">
		            <div class="col-lg-12 offset-lg-12">
		                <h4 class="page-title"><?php echo $hahind ?></h4>
		                <input type="text" value="<?php echo $report_type; ?>" id="report_type" name="report_type" hidden>
		            </div>
		        </div>
		        
		          <form  method="post" id="form1">
		        <div class="row">
		               <div class="col-sm-3">
			                 	 <label for="patient">Patient</label>
			                    <select name="patient" id="patient" class="form-control bd select2" 
			                    style="height: 30" >
														  
												  </select>
			               </div>
		                <div class="col-sm-3">
			                 	 <label for="from_date">from Date</label>
			                    <input type="text" class="form-control datetimepicker bd date_picker" 
			                    name="from_date" id="from_date" value ="<?php echo date('d-m-Y');?>">
			               </div>
			             
			              <div class="col-sm-3">
			                 	 <label for="to_date">To Date</label>
			                    <input type="text" class="form-control datetimepicker bd date_picker" 
			                    name="to_date" id="to_date" value="<?php echo date('d-m-Y');?>">
			                </div> 
			               <div class="col-sm-2 col-md-3 pt-4">
			               	<input type="button" name="search" id="search" value="Search" size="4">
                    </div> 
              </div>
            </form>
		        </div>
		    </div>
		    <br><br>
		         <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                        	<table id="tbl" class="table display" style="width:100%">
                                <thead>
                                    <tr>
                                    	<th scope="col">Name</th>
                                        <th scope="col">Age</th>
                                        <th scope="col">Gender</th>
                                    	<?php if($report_type == 'daily'){ ?>
                                        <th scope="col">Date</th>
                                        <th scope="col">Time</th>
                                        <th scope="col">Fees Charged</th>
                                        <?php }elseif ($report_type == 'consultation') {?>
                                         <th scope="col">CONSULTDATE</th>
                                         <th scope="col">DIAGNOSIS</th>
                                         <th scope="col">Action</th>
																				<?php
                                        }else{ ?>
                                         <th scope="col">DISCHARGEDATE</th>
                                         <th scope="col">DIAGNOSIS</th>
                                         <th scope="col">OPERATED</th>
                                          <th scope="col">Action</th>
                                        <?php } ?>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
		  </div>
		  
		 </div> 
		  
		  
<?php include 'views/footer.php'; ?>
<script>
 $(document).ready(function() {
 	var report_type = $('#report_type').val();
 	if(report_type == 'daily'){
 		var columns1 =  [
	    		{data: 'Name'},
	    		{data: 'age'},
	    		{data: 'gender'},
	    		{data: 'date'},
	    		{data: 'time'},
	    		{data: 'charge'},
	    		]
	    		columnDefs1= " ";
 	}else if(report_type == 'consultation'){
 		var columns1 =  [
	    		{data: 'Name'},
	    		{data: 'age'},
	    		{data: 'gender'},
	    		{data: 'date'},
	    		{data: 'provisional_diagnosis'},
	    		{data: 'pid'},
	    	
	    		]
	    	var	columnDefs1=[
	    	{
					"targets": -1,
					"data": "pid",
					"render": function (data, type, row, meta ) {
				return "<td class='text-right'><a href='../admission/firstconsulatationpdf?pdf_id="+row.consult_id+"&pid="+row.pid+"'><i class='fa fa-file-pdf-o m-r-5' title='Firstconsulatation'></i></a></td>";
					}
					}
					]
 	}else{
 		var columns1 =  [
	    		{data: 'Name'},
	    		{data: 'age'},
	    		{data: 'gender'},
	    		{data: 'dischargedate'},
	    		{data: 'diagnosis'},
	    		{data: 'operated'},
	    		{data: 'dischargeid'},
	    	
	    		]
	    		
	   var	columnDefs1=[
	    	{
					"targets": -1,
					"data": "admission_id",
					"render": function (data, type, row, meta ) {
				return "<td class='text-right'><a href='../discharge/discharge_pdf?pid="+row.pid+"&discharge_pdf_id="+data+"'><i class='fa fa-file-pdf-o m-l-5 icon pdf'  title='PDF'></i></a></td>";
					}
					}
					] 		
 	}
 	
 	$('#search').on('click',function(){
 	$('#tbl').DataTable().clear().destroy();
 		var pid = $('#patient').val();
 		var from_date = $('#from_date').val();
 		var to_date = $('#to_date').val();
 		var report_type = $('#report_type').val();
 		var data = {
 			'pid' :pid,
 			'form_date' :from_date,
 			'to_date' :to_date,
 			'report_type' :report_type,
 		}
 //console.log(data);
 		 	var t= $('#tbl').DataTable({
 		 		  "columnDefs": [{ 
		      "targets": -1, 
		      "orderable": false
        }],
 		 		  dom: 'Bfrtip',
 		 		 buttons: [
            // 'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdfHtml5',
        ],
    		processing: true,
	    	serverSide : false,
	    	"ordering": false,
	    	ajax: {
	    		url: 'report_Daily_json',
	    		type: 'POST',
	    		data :data,
	    	},
	    
	    	columnDefs: [
            {
                searchable: false,
                orderable: false,
                targets: 0,
            },
        ],
	    	columns:columns1,
	    	columnDefs:columnDefs1,
	    	 
 		 	});
 	} )
 	//datepicker future date diseble start
		        var today = new Date();
		        $('.date_picker').datepicker({
				            dateFormat: 'dd-mm-yy ',
				            autoclose:true,
				            changeMonth: true,
				            changeYear: true,
				            endDate: "today",
				            maxDate: today,
				             setDate : new Date(),
                    autoclose : true
				          }).on('changeDate', function (ev) {
				               $(this).datepicker('hide');
				      });
//End
				// $('#patient').css('height', '30');	 
			
		$("#patient").select2({
					 placeholder: 'Select a patient',
					 //height: 'resolve',
					 allowClear: true,
				    ajax: {
				      url: "patient_name",
				      type: 'POST',
				      dataType: 'json',
				      data: 
				      (params) => {
				        return {
				          q: params.term,
				        }
				      },
				      processResults: (data, params) => {
				        const results = data.data.map(data => {
				          return {
				            text: data.Name+"("+data.pmshid+")",
				            id: data.pid,
				            pmshid: data.pmshid,
				          };
				        });
				        return {
				          results: results,
				        }
				      },
				    },
				  });			  
 	
 });
</script>