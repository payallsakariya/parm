<!-- forgot-password24:03-->
<head>
   	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<link rel="shortcut icon" type="image/x-icon" href="../../assets/img/favicon.ico">
	<title> PARAM MULTISPECIALITY HOSPITAL
	</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/font-awesome.min.css">
	<!--<link rel="stylesheet" type="text/css" href="../assets/css/select2.min.css">-->
	<link rel="stylesheet" type="text/css" href="../assets/css/style.css">
	<!--//datepicker-->
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	
	<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">

<link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />

<!--<select class="select2" style="width: 100%;"></select>-->
</head>

<body>