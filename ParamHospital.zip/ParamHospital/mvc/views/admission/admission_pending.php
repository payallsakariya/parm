<?php 

include 'views/header.php';
?>
<style>
	.icon{
		color: #607580;
	}
</style>
 <input type="text"  id="types" name="types" size="2" readonly value="<?php echo $_SESSION['type'][0]; ?>" hidden>
<!--<body>-->
<!--    <div class="main-wrapper">-->

        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-8 col-6">
                        <h4 class="page-title">Admission Panding</h4>
                    </div>
                </div>
                  <div class="row filter-row">
                    <div class="col-sm-4 col-md-5">
                    	<?php 
                    if($_SESSION['type'][0]=='staff'){
                    	?>
                        <div class="form-group form-focus">
		                      <select id="admission" name="admission" style="width:100%" class="form-control floating select2">
		                      </select>
                            <input type="hidden" name="pid"  id="pid" />
                        </div>
                        <?php }?>
                    </div>
                </div>
            
            <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table id="tbl_A" class="table table-border table-striped custom-table ">
                                <thead>
                                  <tr>
                                  	<th class="text-right">Action</th>
                                        <th>#</th>
                                        <th>Case No</th>
                                        <th>Date</th>
                                        <th>Name</th>
                                        <th>Age</th>
                                        <th>Gender</th>
                                        <th>Phone</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                 <div id="del_admission" class="modal fade delete-modal" role="dialog">
						    <div class="modal-dialog modal-dialog-centered">
						        <div class="modal-content">
						            <div class="modal-body text-center">
						            	<input type="text" id="del_a" name="del_a" value="" hidden="">
						                <img src="../assets/img/sent.png" alt="" width="50" height="46">
						                <h3>Are you sure want to delete this ?</h3>
						                <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
						                    <!--<button type="button" class="btn btn-danger deletecdata" id="del_modal">Delete</button>-->
						                     <button type="button" class="btn btn-danger deletecdata" id="del_modal"><a href="#"  data-dismiss="modal">Delete</a></button>
						                </div>
						            </div>
						        </div>
						    </div>
						</div> 
            </div>
        </div>
<?php
include 'views/footer.php'; ?>

<!-- patients23:19-->

</html>
<script>
$(document).ready(function(){
	
	// Start select2 admission ajax call
				 $("#admission").select2({
					 placeholder: 'Select Patient For Admit', 
				    ajax: {
				      url: "patient_pending_admit",
				      type: 'POST',
				      dataType: 'json',
				      data: 
				      (params) => {
				        return {
				          q: params.term,
				        }
				      },
				      processResults: (data, params) => {
				        const results = data.data.map(data => {
				          return {
				            text: data.Name+"("+data.pmshid+")",
				            id: data.pid,
				            pmshid: data.pmshid,
				          };
				        });
				        return {
				          results: results,
				        }
				      },
				    },
				  });
				  
				  
				 $("#admission").on("change",function(){
				 var pid = document.getElementById("admission").value;
				 
				 location.href = "add_pending_admit?pid="+pid;

				 })  
				 
		//End		 
	
	var t= $('#tbl_A').DataTable({
    		processing: true,
	    	serverSide : false,
	    	ajax: {
	    		url: 'admission_panding_json',
	    		type: 'POST',
	    	},
	    
	    	columnDefs: [
            {
                searchable: false,
                orderable: false,
                targets: 0,
            },
        ],
	    	columns: [
	    		
	    		{data: 'pid'},
	    		{data: 'caseid'},
	    		{data: 'pmshid'},
	    		{data: 'date'},
	    		{data: 'Name'},
	    		{data: 'age'},
	    		{data: 'gender'},
	    		{data: 'contact'},
	    	
	    		],
	    		
	    		
	     columnDefs: [
	     	{
					"targets": 0,
					"data": "pid",
					"render": function ( data, type, row, meta ) {
						console.log(row);
						if(row.consult_id == null){
								return "<td class='text-right'><a class='dropdown-item' href='AdmitPatient?p_id="+data+"&case_id="+row.caseid+"'>Consut</a></td>";	
						}else{
				   	// return "<td class='text-right'><div class='dropdown dropdown-action'><a href='#' class='action-icon dropdown-toggle' data-toggle='dropdown' aria-expanded='false'><i class='fa fa-ellipsis-v'></i></a><div class='dropdown-menu dropdown-menu-right'><a class='dropdown-item'href='admission?p_id="+data+"'><i class='fa fa-plus m-r-5'></i> Admission</a><a class='dropdown-item'href='AdmitPatient?updeta_p_id="+row['pid']+"'><i class='fa fa-pencil m-r-5'></i> consut_update</a></div></div></td>";
				   	
				   	return "<td><a href='admission?p_id="+data+"'><i class='fa fa-plus m-l-5 icon' title='Admission'></i></a><a href='AdmitPatient?updeta_p_id="+row['pid']+"'><i class='fa fa-pencil m-l-5 icon' title='consut_update' ></i></a></td>";
				   		
					}
					}
	     	}
					]
			});	
			
			
					// return "<td class='text-right'><div class='dropdown dropdown-action'><a href='#' class='action-icon dropdown-toggle' data-toggle='dropdown' aria-expanded='false'><i class='fa fa-ellipsis-v'></i></a><div class='dropdown-menu dropdown-menu-right'><a class='dropdown-item' href='admission?case_id="+data+"'><i class='fa  m-r-5'></i>Admission</a><a class='dropdown-item deletecdata' href='#' data-toggle='modal' data-target='#del_admission' data-dataid="+row.pid+"><i class='fa fa-trash-o m-r-5'></i>Delete</a></div></div></td>";
			
		    //delete data
		     $(document).on("click","a.deletecdata",function(e){
					     	  e.preventDefault();
				  		  delete_a_id = $(this).data('dataid');
				  		  	$('#del_a').val(delete_a_id);
				  		  console.log(delete_a_id)
	        });
	  
	  	  $(document).on("click","button.deletecdata",function(){
	  	            	var id = $('#del_a').val();
							  	 var	pid = document.getElementById("pid").value;
							    const delet_id=[pid,id];
							    // var id = $(this).attr( "id" )
							  	 //console.log(delet_id);
                    $.ajaxSetup({
									        headers: {
									                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
									             }
									    });
									    
							  	  $.ajax({
									 	 	  		 type :'POST',
									 	 	  		 //"delete_admission",
									 	 	  		 url :"delete_chiefcomplains",
									 	 	  		 cache : false,
									 	 	  		 data : {'id':delet_id},
									 	 	  		 success: function(Code){
									 	 	  		 	// console.log(Code);
									 	 	  		 	 $(".del_admission").attr('data-dismiss', 'modal');
									 	 	  		 	// $('#chiefcomplains').DataTable().ajax.reload();
									 	 	  		 	// $("#del_chiefcomplains").modal("hide");
									 	 	  		  
									 	 	  		 } 
									 	 	  	})
              });
              
	 
})
	  
</script>
				