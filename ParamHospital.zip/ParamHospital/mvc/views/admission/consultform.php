<?php 
$admit_pateint_update =$_SESSION['admitpatient_consults'];
// echo "<pre>";
// print_r($admit_pateint_update);exit;
$admit_pateint=$_SESSION['admitpatient'];

include 'views/header.php'; ?>
 <style>
				.bg{
					background-color: #0fa7c9;
					color: #fff;
				}
				.bd{
				border: 1px solid #ced4da;
				}
				.form_controt{
					    /*border-radius: 0;*/
					    /*border-style: solid*/
					        font-weight: 400;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    
    box-shadow: none;
    padding: 10px;
    /*border-color: #eb666682;*/
    font-size: 14px;
    min-height: 40px;
				}
			</style>
<div class="page-wrapper">
		    <div class="content">
		        <div class="row">
		            <div class="col-lg-8 offset-lg-2">
		                <h4 class="page-title">Consultation Form</h4>
		            </div>
		        </div>
		        
		        <div class="row">
		         <div class="col-lg-8 offset-lg-2">
		          <form  method="post">
			         <div class="row">
		                  <div class="col-md-12">
		                      <div class="table-responsive">
		                      	<table id="tbl" class="table display" style="width:100%" >
		                          <!--<table class="table table-border table-striped custom-table datatable mb-0 " id="tbl">-->
		                              <thead>
		                                  <tr class="bg">
		                                      <th scope="col">Patient Name</th>
		                                      <th scope="col">Age</th>
		                                      <th scope="col">Gender</th>
		                                      <th scope="col">Contact</th>
		                                      <th scope="col">Format Date</th>
		                                      <th></th>
		                                      <th></th>
		                                  </tr>
		                              </thead>
		                              <tbody>
		                              	<tr>
		                              	<td><?php echo $admit_pateint->Name; ?></td>
                                   <td><?php echo $admit_pateint->age; ?></td>
		                              	<td><?php echo $admit_pateint->gender; ?></td>
		                              	<td><?php echo $admit_pateint->contact; ?></td>
		                              	<td><?php echo $admit_pateint->date; ?></td>
		                              	 <td><input type="text"  id="pid" name="pid" size="2" readonly 
										                    value="<?php echo $admit_pateint->pid;?>" hidden></td>
											           	       <td><input type="text"  id="caseid" name="caseid" size="2" readonly
											           	       value="<?php echo $admit_pateint->caseid;?>" hidden>
											           	       <input type="text"  id="date" name="date" size="1" readonly
											           	       value="<?php echo $admit_pateint->date;?>" hidden>
											           	       <input type="text"  id="s_id" name="s_id" size="1" readonly
											           	       value="<?php echo $admit_pateint->id;?>" hidden>
											           	       </td>
		                              	</tr>
		                              </tbody>
		                        </table>
					    			   </div>
				             </div>
				          </div>
				          <?php 
				          if($admit_pateint_update){
				          	 //print_r($admit_pateint_update);
				          ?>
				            <div class="row">
			                  <div class="col-sm-6">
			                    <div class="form-group">
			                        <label for="past_history">Past History</label>
			                        <input class="form-control bd" type="text" id="past_history" name="past_history" 
			                           value="<?php echo $admit_pateint_update->past_history; ?>">
			                    </div>
			                </div>
			                
			                 <div class="col-sm-6">
			                    <div class="form-group">
			                        <label for="personal_history">Personal History </label>
			                        <input class="form-control bd" type="text" id="personal_history" name="personal_history"
			                        value="<?php echo $admit_pateint_update->personal_history; ?>">
			                    </div>
			                </div>
			                 <div class="col-sm-6">
			                    <div class="form-group">
			                        <label for="family_history">Family History </label>
			                        <input class="form-control bd" type="text" id="family_history" name="family_history"
			                        value="<?php echo $admit_pateint_update->family_history; ?>">
			                    </div>
			                </div>
			                 <div class="col-sm-6">
			                    <div class="form-group">
			                        <label for="Allergy">Allergy </label>
			                        <input class="form-control bd" type="text" id="Allergy" name="Allergy"
			                        value="<?php echo $admit_pateint_update->alergy; ?>">
			                    </div>
			                </div>
			                 <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="Provisional_Diag">Provisional Diagnosis</label><span class="text-danger pl-2">*</span>
			                        <input class="form-control bd" type="text" id="Provisional_Diag" name="Provisional_Diag" 
			                        value="<?php echo $admit_pateint_update->provisional_diagnosis; ?>" required="">
			                    </div>
			                </div>
			                 <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="Charge">Charge </label>
			                        <input class="form-control bd" type="text" id="Charge" name="Charge"
			                        value="<?php echo $admit_pateint_update->charge; ?>">
			                    </div>
			                </div>
			                 <div class="form-group">
			                        <label for="suggestion">Suggestion</label>
			                        <textarea class="form-control bd" id="suggestion" name="suggestion"rows="3">
			                        	<?php echo $admit_pateint_update->suggestion; ?></textarea>
			                    </div>
			                 <div class="col-sm-12">
			                 	 <label for="address">Observation</label>
			                   <!-- <div class="form-group">-->
			                 
	                     <!--<textarea class="form_controt bd col-8 pt-3" id="Observation" name="Observation"rows=""></textarea>-->
			                   <!-- </div>-->
			                </div>
			                 <div class="form-group col-6">
									        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="t" class="control-label">T</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="t" id="t" 
									        value="<?php echo $admit_pateint_update->t; ?>" >&#8457;
									    </div>
									    
									     <div class="form-group col-6">
									        <label for="bp" class="control-label">BP </label>&nbsp;
									       <input class="bd form_controt" type="text"  name="bp" id="bp" 
									       value="<?php echo $admit_pateint_update->bp; ?>" >mmHg
									    </div>
									    
									    
									    <div class="form-group col-6">
									        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="p" class="control-label">P</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="p" id="p"
									        value="<?php echo $admit_pateint_update->p; ?>">/min
									    </div>
									    
									     <div class="form-group col-6">
									        <label for="rs" class="control-label">RS</label>&nbsp;
									       <input class="bd form_controt" type="text"  name="rs" id="rs" 
									       value="<?php echo $admit_pateint_update->rs; ?>">
									    </div>
			                 <div class="form-group col-6">
									        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="r" class="control-label">R</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="r" id="r" 
									        value="<?php echo $admit_pateint_update->r; ?>">/min
									    </div>
									     <div class="form-group col-6">
									        <label for="pa" class="control-label">P/A</label>&nbsp;
									      <input class="bd form_controt" type="text"  name="pa" id="pa" 
									      value="<?php echo $admit_pateint_update->pa; ?>">
									    </div>
									   
									    
									    <div class="form-group col-6">
									       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="lname" class="control-label">RBS</label>&nbsp;
									      <input class="bd form_controt" type="text"  name="rbs" id="rbs" 
									      value="<?php echo $admit_pateint_update->rbs; ?>" >mg/dl
									    </div>
									    <div class="form-group col-6">
									        <label for="cvs" class="control-label">CVS</label>&nbsp;
									      <input class="bd form_controt" type="text"  name="cvs" id="cvs"
									      value="<?php echo $admit_pateint_update->cvs; ?>">
									    </div>
			                 <div class="form-group col-6">
									        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="cns" class="control-label">CNS</label>&nbsp;
									       <input class="bd form_controt" type="text"  name="cns" id="cns"
									       value="<?php echo $admit_pateint_update->cns; ?>">
									    </div>
									     <div class="form-group col-6">
									        <label for="spo2" class="control-label">Spo2</label>&nbsp;
                           <input class="bd form_controt" type="text"  name="spo2" id="spo2" 
                           value="<?php echo $admit_pateint_update->spo2; ?>">%
									    </div>
									    <div class="form-group col-6">
									        <label for="tounge" class="control-label">Tounge</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="tounge" id="tounge"
									        value="<?php echo $admit_pateint_update->tounge; ?>">
									    </div>
	                    <div class="form-group col-12 ">
	                        <!--<label for="address" class=" col-4 pb-6">Notas</label>-->
	                      Notis &nbsp;<textarea class="form_controt bd col-8 pt-3 ml-2" id="Observation" name="Observation" rows="">
	                       	<?php echo $admit_pateint_update->Observation; ?></textarea>
	                    </div>
	                    <input type="text" id="consult_id" name="consult_id" size="1" 
	                    value="<?php echo $admit_pateint_update->consult_id;?>" hidden>
			         </div>
				          <?php
				          }else {
				          	// echo "else";
				          ?>
				            <div class="row">
			                  <div class="col-sm-6">
			                    <div class="form-group">
			                        <label for="past_history">Past History</label>
			                        <input class="form-control bd" type="text" id="past_history" name="past_history">
			                    </div>
			                </div>
			                
			                 <div class="col-sm-6">
			                    <div class="form-group">
			                        <label for="personal_history">Personal History </label>
			                        <input class="form-control bd" type="text" id="personal_history" name="personal_history" >
			                    </div>
			                </div>
			                 <div class="col-sm-6">
			                    <div class="form-group">
			                        <label for="family_history">Family History </label>
			                        <input class="form-control bd" type="text" id="family_history" name="family_history">
			                    </div>
			                </div>
			                 <div class="col-sm-6">
			                    <div class="form-group">
			                        <label for="Allergy">Allergy </label>
			                        <input class="form-control bd" type="text" id="Allergy" name="Allergy">
			                    </div>
			                </div>
			                 <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="Provisional_Diag">Provisional Diagnosis</label><span class="text-danger pl-2">*</span>
			                        <input class="form-control bd" type="text" id="Provisional_Diag" name="Provisional_Diag"  required="">
			                    </div>
			                </div>
			                 <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="Charge">Charge </label>
			                        <input class="form-control bd" type="text" id="Charge" name="Charge">
			                    </div>
			                </div>
			                 <div class="form-group">
			                        <label for="suggestion">Suggestion</label>
			                        <textarea class="form-control bd" id="suggestion" name="suggestion"rows="3"></textarea>
			                    </div>
			                 <div class="col-sm-12">
			                 	 <label for="address">Observation</label>
			                   <!-- <div class="form-group">-->
			                 
	                     <!--<textarea class="form_controt bd col-8 pt-3" id="Observation" name="Observation"rows=""></textarea>-->
			                   <!-- </div>-->
			                </div>
			                 <div class="form-group col-6">
									        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="t" class="control-label">T</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="t" id="t" >&#8457;
									    </div>
									    
									     <div class="form-group col-6">
									        <label for="bp" class="control-label">BP </label>&nbsp;
									       <input class="bd form_controt" type="text"  name="bp" id="bp" >mmHg
									    </div>
									    
									    <div class="form-group col-6">
									        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="p" class="control-label">P</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="p" id="p" >/min
									    </div>
									    
									     <div class="form-group col-6">
									        <label for="rs" class="control-label">RS</label>&nbsp;
									       <input class="bd form_controt" type="text"  name="rs" id="rs" >
									    </div>
			                 <div class="form-group col-6">
									        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="r" class="control-label">R</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="r" id="r" >/min
									    </div>
									     <div class="form-group col-6">
									        <label for="pa" class="control-label">P/A</label>&nbsp;
									      <input class="bd form_controt" type="text"  name="pa" id="pa" >
									    </div>
									   
									    <div class="form-group col-6">
									       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="lname" class="control-label">RBS</label>&nbsp;
									      <input class="bd form_controt" type="text"  name="rbs" id="rbs" >mg/dl
									    </div>
									    <div class="form-group col-6">
									        <label for="cvs" class="control-label">CVS</label>&nbsp;
									      <input class="bd form_controt" type="text"  name="cvs" id="cvs" >
									    </div>
			                 <div class="form-group col-6">
									        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="cns" class="control-label">CNS</label>&nbsp;
									       <input class="bd form_controt" type="text"  name="cns" id="cns" >
									    </div>
									     <div class="form-group col-6">
									        <label for="spo2" class="control-label">Spo2</label>&nbsp;
                           <input class="bd form_controt" type="text"  name="spo2" id="spo2" >%
									    </div>
									    <div class="form-group col-6">
									        <label for="tounge" class="control-label">Tounge</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="tounge" id="tounge" >
									    </div>
	                    <div class="form-group col-12 ">
	                        <!--<label for="address">Suggestion</label>-->
	                       <textarea class="form_controt bd col-8 pt-3" id="Observation" name="Observation"rows=""></textarea>
	                    </div>
	                     <input type="text" id="consult_id" name="consult_id" size="1" 
	                    value="<?php echo $admit_pateint_update->consult_id;?>" hidden>
			         </div>
				          
				          <?php
				          }
				          ?>
				        
				     
			         
							    <!--<form method="post">-->
		        	<!-- <div class="form-group">-->
									<table align=center class="table display" id="Chiefadd" style="width:100%">
											   <thead>Chief complains of</thead>
											   		<tbody>
											         <td>C/o<input class="bd form_controt obs_type" type="text"  name="ob1" id="ob1" size="33"> 
											        <input class="cid" type="text"  name="cid" id="cid" size="1" hidden=""> 
												           	From <input class="bd form_controt obs_count" type="text"  name="obday1" id="obday1" size="6">
															    <select name="obdmy1" id="obdmy1" class="bd form_controt c_DMY">
															    <option value="days" id="target">days</option>
															    <option value="month">month</option>
															    <option value="year">year</option>
															    </select></td>
												<td class="pt-4"><input type="button" name="Chief_updat"  id="Chief_updat" class="Chief_updat" value="Update" hidden="hidden"></td>
											   	<td class="pt-4"><input type="button" name="Chief_add"  id="Chief_add" class="add_chirf" value="Add"></td>

													 	</tbody>
										 </table>
			       <!--  </div>-->
		        <!--</form>-->
		        <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                        	<table id="chiefcomplains" class="table display" style="width:100%">
                             <!--<table class="table table-border table-striped custom-table datatable mb-0 " id="tbl">-->
                                <thead>
                                    <tr style="background-color:#ddd">
                                        <th scope="col">C/O</th>
                                        <th scope="col">Form</th>
                                        <th scope="col">D/M/Y</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
				     </div>
		      
				         <?php 
				          if($admit_pateint_update){
				          	 //print_r($admit_pateint_update);
				          ?>  
							          
			         <div class="text-center">
						         	<input type="submit" name="Update" value="Update" id="Update" class="btn btn-primary ">
			                <input type="button" name="cancel" value="cancel" id="cancel" class="btn btn-danger cancel-btn2">
			         </div>
			         <?php }else{
			         	?>
			         	 <div class="text-center">
						         	<input type="submit" name="Save" value="Save" id="Save" class="btn btn-primary ">
			                <input type="button" name="cancel" value="cancel" id="cancel" class="btn btn-danger cancel-btn1 ">
			         </div>
			         	<?php
			         } ?>
		        </form>
		          </div>
		          
		          
		          
		        </div>
		          <div id="del_chiefcomplains" class="modal fade delete-modal" role="dialog">
						    <div class="modal-dialog modal-dialog-centered">
						        <div class="modal-content">
						            <div class="modal-body text-center">
						            	<input type="text" id="del_c" name="del_c" value="" hidden="">
						                <img src="../assets/img/sent.png" alt="" width="50" height="46">
						                <h3>Are you sure want to delete this ?</h3>
						                <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
						                    <!--<button type="button" class="btn btn-danger deletecdata" id="del_modal">Delete</button>-->
						                     <button type="button" class="btn btn-danger deletecdata" id="del_modal"><a href="#"  data-dismiss="modal">Delete</a></button>
						                </div>
						            </div>
						        </div>
						    </div>
						</div> 
		    </div>
		  </div>
		  
		  
		  
		  
<?php include 'views/footer.php'; ?>
<script>
   $(document).ready(function() {
   	
   	// console.log("ready");
   	views_chiefcomplains();
   	
   	$(document).on("click","input.cancel-btn1",function(){
   		// console.log('cancel_add');
   		 //var	s_id = document.getElementById("consult_id").value;
        window.location ='AdmitPatient?cancel_add';

    });
    
     	$(document).on("click","input.cancel-btn2",function(){
   		 var	s_id = document.getElementById("consult_id").value;
        window.location ='AdmitPatient?cancel_up='+ s_id;

    });
   	
   	  function views_chiefcomplains(){
   	  	 var	pid = document.getElementById("pid").value;
   	  	  var data ={
		   	    	'pid' : pid,
		   	    }
		   	    
		   	    var t= $('#chiefcomplains').DataTable({
				    		processing: true,
					    	serverSide : false,
					    	 searchable: false,
				          orderable: false,
					    	ajax: {
					    		url: 'add_chiefcop_liste',
					    		type: 'POST',
					    		 data : data,
							 	 	  		 datatype :"json",
					    	},
					    	
					    	
					    	columns: [
					    		// {data: 'id'},
					    		{data: 'observation'},
					    		{data: 'obs_count'},
					    		{data: 'obs_dmy'},
					    		{data: ''},
					    		],
					    		 columnDefs: [
					    	{
									"targets": -1,
									"data": "pid",
									"render": function ( data, type, row, meta ) {
									return "<td class='text-right'><div class='dropdown dropdown-action'><a href='#' class='action-icon dropdown-toggle' data-toggle='dropdown' aria-expanded='false'><i class='fa fa-ellipsis-v'></i></a><div class='dropdown-menu dropdown-menu-right'><button type='button' value='"+row.id+"' class='dropdown-item edit_c'><i class='fa fa-pencil m-r-5'></i> Edit</button><a class='dropdown-item deletecdata' href='#' data-toggle='modal' data-target='#del_chiefcomplains' data-dataid="+row.id+"><i class='fa fa-trash-o m-r-5'></i>Delete</a></div></div></td>";
									}
									}
									]
	    	
			});
			 	 	  	
   	  }
   	//add complains in database
		   $(document).on('click', '.add_chirf',function(e){
				   	e.preventDefault();
				   	 var	pid = document.getElementById("pid").value;
				   	 var	caseid = document.getElementById("caseid").value;
				   	// console.log("addd");
		   	    var data ={
		   	    	'observation' : $('.obs_type').val(),
		   	    	'obs_count' : $('.obs_count').val(),
		   	    	'obs_dmy' : $('#obdmy1 :selected').text(),
		   	    	'pid' : pid,
		   	    	'caseid' : caseid,
		   	    }
		   	    
		   	    $.ajaxSetup({
							    headers: {
							        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
							    }
							});
		   	   
		   	    $.ajax({
				 	  		 type :'POST',
				 	  		 url :'add_chif',
				 	  		 data : data,
				 	  		 datatype :"datatype",
				 	  		 success: function(response){
				 	  		 	 $('.obs_type').val("");
		   	           $('.obs_count').val("");
		   	           $("#obdmy1").val($("#target option:first").val());
		   	           $('#chiefcomplains').DataTable().ajax.reload();

				 	  		 } 
				 	  	})
		   });
		   
		    	//Edit selected complains in database
		   $(document).on('click', '.edit_c',function(e){
				   	e.preventDefault();
				   	var id = $(this).val();
				   	var data ={
		   	    	           'id' : id,
		   	              }
				   	 $.ajax({
				 	  		 type :'POST',
				 	  		 url :'select_chiefcomplains',
				 	  		 //cache : false,
				 	  		 data : data,
				 	  		 datatype :"datatype",
				 	  		 success: function(response){
				 	  		 	var t = JSON.parse(response);
				 	  		 	// console.log(t['obs_count']);
				 	  		 	// console.log(response);
				 	  		 	 $('.obs_type').val(t['observation']);
		   	          $('.obs_count').val(t['obs_count']);
		   	          $('.cid').val(t['id']);
		   	          $('#obdmy1'). val(t['obs_dmy']); 
		   	          $(".add_chirf").hide();
		   	           $(".Chief_updat").removeAttr('hidden');
		   	          $('#chiefcomplains').DataTable().ajax.reload();

				 	  		 } 
				 	  	})
		    });
		    
		    
		    //update resonse and  update data
		       $(document).on('click', '.Chief_updat',function(e){
						   	e.preventDefault();
				   	    var data ={
				   	    	'observation' : $('.obs_type').val(),
				   	    	'obs_count' : $('.obs_count').val(),
				   	    	'obs_dmy' : $('#obdmy1 :selected').text(),
				   	    	'id' : $('.cid').val(),
				   	    }
				   	   
				   	    $.ajax({
					 	 	  		 type :'POST',
					 	 	  		 url :'update_chiefcomplains',
					 	 	  		 data : data,
					 	 	  		 datatype :"datatype",
					 	 	  		 success: function(response){
					 	 	  		 	// console.log(response);
					 	 	  		 	$('.obs_type').val("");
				   	          $('.obs_count').val("");
				   	          $("#obdmy1").val($("#target option:first").val());
				   	          $(".add_chirf").show();
				   	          $(".Chief_updat").attr('hidden', 'hidden');
				   	          $('#chiefcomplains').DataTable().ajax.reload();
		
					 	 	  		 } 
					 	 	  	})
		        });
		    
		    
		    //delete data
		     $(document).on("click","a.deletecdata",function(e){
					     	  e.preventDefault();
				  		  delete_s_id = $(this).data('dataid');
				  		  	$('#del_c').val(delete_s_id);
				  		  console.log(delete_s_id)
	        });
	  
	  	  $(document).on("click","button.deletecdata",function(){
	  	            	var id = $('#del_c').val();
							  	 var	pid = document.getElementById("pid").value;
							    const delet_id=[pid,id];
                    $.ajaxSetup({
									        headers: {
									                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
									             }
									    });
									    
							  	  $.ajax({
									 	 	  		 type :'POST',
									 	 	  		 url :"delete_chiefcomplains",
									 	 	  		 cache : false,
									 	 	  		 data : {'id':delet_id},
									 	 	  		 success: function(Code){
									 	 	  		 	// console.log(Code);
									 	 	  		 	 $(".deletecdata").attr('data-dismiss', 'modal');
									 	 	  		 	$('#chiefcomplains').DataTable().ajax.reload();
									 	 	  		 	// $("#del_chiefcomplains").modal("hide");
									 	 	  		  
									 	 	  		 } 
									 	 	  	})
              });
              
   })
 
   
</script>