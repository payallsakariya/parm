<?php 
$admit_pateint_info=$_SESSION['admitpatientinfo'];
$edit_admission_info=$_SESSION['select_edit_data'];
$view_admission_info=$_SESSION['select_view_data'];
if(!empty($view_admission_info)){
  $edit_admission_info =	$view_admission_info;
}
include 'views/header.php'; ?>
 <style>
				.bg{
					background-color: #0fa7c9;
					color: #fff;
				}
				.bd{
				border: 1px solid #ced4da;
				}
				.form_controt{
					    /*border-radius: 0;*/
					    /*border-style: solid*/
					        font-weight: 400;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    
    box-shadow: none;
    padding: 10px;
    /*border-color: #eb666682;*/
    font-size: 14px;
    min-height: 40px;
				}
					.time{
					    /*border-radius: 0;*/
					    /*border-style: solid*/
					        font-weight: 400;
    line-height: 1;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    
    box-shadow: none;
    padding: 10px;
    /*border-color: #eb666682;*/
    font-size: 14px;
    min-height: 40px;
				}
			</style>
<div class="page-wrapper">
		    <div class="content">
		        <div class="row">
		            <div class="col-lg-8 offset-lg-2">
		                <h4 class="page-title">Admission Form</h4>
		            </div>
		        </div>
		        
		        <div class="row">
		         <div class="col-lg-8 offset-lg-2">
		          <form  method="post">
			         <div class="row">
		                  <div class="col-md-12">
		                      <div class="table-responsive">
		                      	<table id="tbl" class="table display" style="width:100%" >
		                          <!--<table class="table table-border table-striped custom-table datatable mb-0 " id="tbl">-->
		                              <thead>
		                                  <tr class="bg">
		                                      <th scope="col">PMH Card Id</th>
		                                      <th scope="col">Patient Name</th>
		                                      <th scope="col">Age</th>
		                                      <th scope="col">Gender</th>
		                                      <th scope="col">Contact</th>
		                                      <th scope="col">Address</th>
		                                      <th></th>
		                                      <th></th>
		                                      
		                                  </tr>
		                              </thead>
		                              <tbody>
		                              	<tr>
		                              	<td><?php echo $admit_pateint_info->pmshid; ?></td>
		                              	<td><?php echo $admit_pateint_info->Name; ?></td>
                                   <td><?php echo $admit_pateint_info->age; ?></td>
		                              	<td><?php echo $admit_pateint_info->gender; ?></td>
		                              	<td><?php echo $admit_pateint_info->contact; ?></td>
		                              	<td><?php echo $admit_pateint_info->address; ?></td>
		                              	 <td><input type="text"  id="pid" name="pid" size="2" readonly 
										                    value="<?php echo $admit_pateint_info->pid;?>" hidden></td>
											           	       <td><input type="text"  id="caseid" name="caseid" size="2" readonly
											           	       value="<?php echo $admit_pateint_info->caseid;?>" hidden>
											           	       <input type="text"  id="id_pr" name="id_pr" size="1" readonly
											           	       value="<?php echo $admit_pateint_info->id;?>" hidden>
											           	       </td>
		                              	</tr>
		                              </tbody>
		                        </table>
					    			   </div>
				             </div>
				          </div>
				          <?php  if($edit_admission_info){ 
				          	// echo "<pre>";
				          	$time=$edit_admission_info->time_of_admission;
				          	$time2=explode(' ',$time);
				          	$time3=explode(':',$time2[0]);
				          	$date_convat=date("d-m-Y", strtotime($edit_admission_info->date_of_admission) );
				          // 	print_r($time2);
				          // 	print_r($time3);
				          // print_r($edit_admission_info);
				          ?>
				          
				           <div class="row">
			                  <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="Referred_To">Referred To</label>
			                        <input class="form-control bd" type="text" id="Referred_To" name="Referred_To" 
			                           value="<?php echo $edit_admission_info->referred_to ?>">
			                    </div>
			                </div>
			                
			                <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="deposit">Deposit</label>
			                        <input class="form-control bd" type="text" id="deposit" name="deposit" 
			                        value="<?php echo $edit_admission_info->deposit ?>" required="">
			                    </div>
			                </div>
			                
			                <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="Allergy">Room Type </label>
			                         <select name="roomtype" id="roomtype" class=" form-control bd" >
															    <option value="General" 
															    <?php if($edit_admission_info->room_type == 'General'){echo 'Selected'; } ?>>General</option>
															    <option value="Special" 
															    <?php if($edit_admission_info->room_type == 'Special'){echo 'Selected'; } ?>>Special</option>
															   <option value="SemiSpecial"
															   <?php if($edit_admission_info->room_type == 'SemiSpecial'){echo 'Selected'; } ?>>SemiSpecial</option>
															    </select>
			                    </div>
			                </div>
			                
			                 <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="bedno">Bed No.</label>
			                        <input class="form-control bd" type="text" id="bedno" name="bedno" 
			                        value="<?php echo $edit_admission_info->bed_no ?>" required="">
			                    </div>
			                </div>
			                 <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="pro_diagnosis">Provisional Diagnosis</label>
			                        <input class="form-control bd" type="text" id="pro_diagnosis" name="pro_diagnosis"
			                        value="<?php echo $edit_admission_info->provisional_diagnosis ?>">
			                    </div>
			                </div>
			                 
			                 <div class="col-sm-4">
			                 	 <label for="Remark">Remark</label>
			                 	 <input class="form-control bd" type="text" id="Remark" name="Remark"
			                        value="<?php echo $edit_admission_info->remark ?>">
			                </div>
			                
			                 <div class="col-sm-4">
			                 	<label for=""> Time of Admission </label>
			                    <div class="form-group">
			                        
		 <select name="hour" class="bd time bd">
     <option value="01" <?php if($time3[0] == '01'){echo 'Selected'; } ?>>01</option>
     <option value="02" <?php if($time3[0] == '02'){echo 'Selected'; } ?>>02</option>
     <option value="03" <?php if($time3[0] == '03'){echo 'Selected'; } ?>>03</option>
     <option value="04" <?php if($time3[0] == '04'){echo 'Selected'; } ?>>04</option>
     <option value="05" <?php if($time3[0] == '05'){echo 'Selected'; } ?>>05</option>
     <option value="06" <?php if($time3[0] == '06'){echo 'Selected'; } ?>>06</option>
     <option value="07" <?php if($time3[0] == '07'){echo 'Selected'; } ?>>07</option>
     <option value="08" <?php if($time3[0] == '08'){echo 'Selected'; } ?>>08</option>
     <option value="09" <?php if($time3[0] == '09'){echo 'Selected'; } ?>>09</option>
     <option value="10" <?php if($time3[0] == '10'){echo 'Selected'; } ?>>10</option>
     <option value="11" <?php if($time3[0] == '11'){echo 'Selected'; } ?>>11</option>
     <option value="12" <?php if($time3[0] == '12'){echo 'Selected'; } ?>>12</option>
	</select>
    
   <!----------min..........------------->
    <select name="min" class="bd time bd" >
     <option value="00" <?php if($time3[1] == '00'){echo 'Selected'; } ?>>00</option>
     <option value="01" <?php if($time3[1] == '01'){echo 'Selected'; } ?>>01</option>
     <option value="02" <?php if($time3[1] == '02'){echo 'Selected'; } ?>>02</option>
     <option value="03" <?php if($time3[1] == '03'){echo 'Selected'; } ?>>03</option>
     <option value="04" <?php if($time3[1] == '04'){echo 'Selected'; } ?>>04</option>
     <option value="05" <?php if($time3[1] == '05'){echo 'Selected'; } ?>>05</option>
     <option value="06" <?php if($time3[1] == '06'){echo 'Selected'; } ?>>06</option>
     <option value="07" <?php if($time3[1] == '07'){echo 'Selected'; } ?>>07</option>
     <option value="08" <?php if($time3[1] == '08'){echo 'Selected'; } ?>>08</option>
     <option value="09" <?php if($time3[1] == '09'){echo 'Selected'; } ?>>09</option>

    <?php
	for($i=10;$i<=59;$i++)
	{?>
    <option value=<?php echo $i ?> <?php if($time3[1] == $i){echo 'Selected'; } ?>><?php echo $i?></option>
    <?php } ?>
	</select>
    
    
   <!----------min..........------------->
   <select name="ampm" class="bd time bd">
     <option value="AM" <?php if($time2[1] == 'AM'){echo 'Selected'; } ?>>AM</option>
     <option value="PM" <?php if($time2[1] == 'PM'){echo 'Selected'; } ?>>PM</option>
</select>
			                     
			                    </div>
			                </div>
			                 <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="doa">Date of Admission </label>
			                        
			                        <input class="form-control bd"  type="text" name="doa"  id="asdate" value="<?php echo $date_convat ?>" />
			                    </div>
			                </div>
			                <div class="form-group col-sm-4">
			                        <label for="Mediclaim">Mediclaim</label><span class="text-danger pl-2">*</span>
			                      <select name="mediclaim" id="mediclaim" class=" form-control bd" >
														   <option value="No"
														       <?php if($edit_admission_info->mediclaim == 'No'){echo 'Selected'; } ?>>No</option>
														    <option value="Yes"
														      <?php if($edit_admission_info->mediclaim == 'Yes'){echo 'Selected'; } ?>>Yes</option>
														    </select>
			                    </div>
			                    
			                
			                 
			         </div>
								<?php if(!empty($view_admission_info)){?>
			         	 <div class="text-center">
						         	<input type="submit" name="Close" value="Close" id="Close" class="btn btn-primary ">
			         </div>
			         <?php }else{?>
				          <div class="text-center">
							         	<input type="submit" name="Update" value="Update" id="Update" class="btn btn-primary ">
				                <input type="button" name="cancel_update" value="cancel" id="cancel_update" class="btn btn-danger cancel-btn3 ">
				         </div>
			         <?php }?>
				          
				          <?php }else{
				          ?>
				          
				           <div class="row">
			                  <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="Referred_To">Referred To</label>
			                        <input class="form-control bd" type="text" id="Referred_To" name="Referred_To" 
			                           value="">
			                    </div>
			                </div>
			                
			                <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="deposit">Deposit</label>
			                        <input class="form-control bd" type="text" id="deposit" name="deposit" 
			                        value="" required="">
			                    </div>
			                </div>
			                
			                <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="Allergy">Room Type </label>
			                         <select name="roomtype" id="roomtype" class=" form-control bd" >
															    <option value="General">General</option>
															    <option value="Special">Special</option>
															     <option value="SemiSpecial">SemiSpecial</option>
															    </select>
			                    </div>
			                </div>
			                
			                 <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="bedno">Bed No.</label>
			                        <input class="form-control bd" type="text" id="bedno" name="bedno" 
			                        value="" required="">
			                    </div>
			                </div>
			                 <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="pro_diagnosis">Provisional Diagnosis</label>
			                        <input class="form-control bd" type="text" id="pro_diagnosis" name="pro_diagnosis"
			                        value="">
			                    </div>
			                </div>
			                 
			                 <div class="col-sm-4">
			                 	 <label for="Remark">Remark</label>
			                 	 <input class="form-control bd" type="text" id="Remark" name="Remark"
			                        value="">
			                </div>
			                
			                 <div class="col-sm-4">
			                 	<label for=""> Time of Admission </label>
			                    <div class="form-group">
			                        
		 <select name="hour" class="bd time bd">
     <option value="01">01</option>
     <option value="02">02</option>
     <option value="03">03</option>
     <option value="04">04</option>
     <option value="05">05</option>
     <option value="06">06</option>
     <option value="07">07</option>
     <option value="08">08</option>
     <option value="09">09</option>
     <option value="10">10</option>
     <option value="11">11</option>
     <option value="12">12</option>
	</select>
    
   <!----------min..........------------->
    <select name="min" class="bd time bd" >
     <option value="00">00</option>
     <option value="01">01</option>
     <option value="02">02</option>
     <option value="03">03</option>
     <option value="04">04</option>
     <option value="05">05</option>
     <option value="06">06</option>
     <option value="07">07</option>
     <option value="08">08</option>
     <option value="09">09</option>

    <?php
	for($i=10;$i<=59;$i++)
	{?>
    <option value=<?php echo $i?>><?php echo $i?></option>
    <?php } ?>
	</select>
    
    
   <!----------min..........------------->
   <select name="ampm" class="bd time bd">
     <option value="AM">AM</option>
     <option value="PM">PM</option>
</select>
			                     
			                    </div>
			                </div>
			                 <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="personal_history">Date of Admission </label>
			                        
			                        <input class="form-control bd"  type="text" name="doa"  id="asdate" value="<?php echo date('d-m-Y');?>" />
			                    </div>
			                </div>
			                <div class="form-group col-sm-4">
			                        <label for="Mediclaim">Mediclaim</label><span class="text-danger pl-2">*</span>
			                        <select name="mediclaim" id="mediclaim" class=" form-control bd" >
														    <option value="No">No</option>
														    <option value="Yes">Yes</option>
														    </select>
			                    </div>
			                    
			                
			                 
			         </div>

			         	 <div class="text-center">
						         	<input type="submit" name="Save" value="Save" id="Save" class="btn btn-primary ">
			                <input type="button" name="cancel" value="cancel" id="cancel" class="btn btn-danger cancel-btn1 ">
			         </div>
				          <?php
				          }
				          
				          
				          ?>
				           
		        </form>
		          </div>
		        </div>
		    </div>
		  </div>
		  
		  
		  
		  
<?php include 'views/footer.php'; ?>
<script>
	 	$(document).on("click","input.cancel-btn1",function(){
	 		// console.log("cancel");
   		 //var	c_id = document.getElementById("consult_id").value;
        window.location ='admission_pending';

    });
    
     	$(document).on("click","input.cancel-btn3",function(){
	 		// console.log("cancel");
   		 //var	c_id = document.getElementById("consult_id").value;
        window.location ='admission?cancel="cancel"';

    });
</script>
	<!--<div class="page-wrapper">-->
		<!--    <div class="content">-->
		<!--      <div class="row">-->
		<!--       <div class="col-lg-12 ">-->
		<!--        <form  method="post">-->
		<!--               <div class="row">-->
		<!--                  <div class="col-md-12">-->
		<!--                      <div class="table-responsive">-->
		                      	<!--<table id="tbl" class="table display" style="width:100%" >-->
		                      	<!--	<th>Division</th>-->
		                      	<!--	<th>Client_type</th>-->
		                      	<!--	<th>qty_to</th>-->
		                      	<!--	<th>qty_from</th>-->
		                      	<!--	<th>SE</th>-->
		                      	<!--	<th>TM</th>-->
		                      	<!--	<th>AM</th>-->
		                      	<!--	<th>Rm</th>-->
		                      	<!--	<th>ZM</th>-->
		                      	<!--	<tr>-->
		                      	<!--		<td class="col-2">34</td>-->
		                      	<!--    <td>434</td>-->
		                      	<!--    <td>434</td>-->
		                      	<!--    <td>434</td>-->
		                      	<!--    <td>434</td>-->
		                      	<!--    <td>434</td>-->
		                      	<!--    <td>434</td>-->
		                      	<!--    <td>434</td>-->
		                      	<!--    <td>434</td>-->
		                      	<!--</tr>-->
		                       <!-- </table>-->
		<!--                        <div class="border tp-20">-->
		<!--                        	<div class="col-2"><h5 class="col-2">Division</h5></div>-->
		<!--                        	<div class="col-2"><h5 class="col-2">Division</h5></div>-->
		<!--                        	<h5>Client_type</h5>-->
		<!--                        	<h5>qty_to</h5>-->
		<!--                        	<h5>qty_from</h5>-->
		<!--                        	<h5>SE</h5>-->
		<!--                        	<h5>TM</h5>-->
		<!--                        	<h5>AM</h5>-->
		<!--                        	<h5>Rm</h5>-->
		<!--                        	<h5>ZM</h5>-->
		                        
		<!--                        </div>-->
		<!--                      </div>-->
		<!--                     </div>-->
		<!--                    </div>-->
		<!--                 </form>-->
		<!--               </div>-->
		<!--              </div>-->
		<!--            </div>  -->
		<!--            </div>-->