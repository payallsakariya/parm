<?php 
$admit_pateint=$_SESSION['admitpatient'];
include 'views/header.php'; ?>
 <style>
				.bg{
					background-color: #0fa7c9;
					color: #fff;
				}
				.bd{
				border: 1px solid #ced4da;
				}
				.form_controt{
					    /*border-radius: 0;*/
					    /*border-style: solid*/
					        font-weight: 400;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    
    box-shadow: none;
    padding: 10px;
    /*border-color: #eb666682;*/
    font-size: 14px;
    min-height: 40px;
				}
			</style>
<div class="page-wrapper">
		    <div class="content">
		        <div class="row">
		            <div class="col-lg-8 offset-lg-2">
		                <h4 class="page-title">Consultation Form</h4>
		            </div>
		        </div>
		        
		        <div class="row">
		         <div class="col-lg-8 offset-lg-2">
		          <form  method="post">
			         <div class="row">
		                  <div class="col-md-12">
		                      <div class="table-responsive">
		                      	<table id="tbl" class="table display" style="width:100%" >
		                          <!--<table class="table table-border table-striped custom-table datatable mb-0 " id="tbl">-->
		                              <thead>
		                                  <tr class="bg">
		                                      <th scope="col">Patient Name</th>
		                                      <th scope="col">Age</th>
		                                      <th scope="col">Gender</th>
		                                      <th scope="col">Contact</th>
		                                      <th scope="col">Format Date</th>
		                                  </tr>
		                              </thead>
		                              <tbody>
		                              	<tr>
		                              	<td><?php echo $admit_pateint->Name; ?></td>
                                   <td><?php echo $admit_pateint->age; ?></td>
		                              	<td><?php echo $admit_pateint->gender; ?></td>
		                              	<td><?php echo $admit_pateint->contact; ?></td>
		                              	<td><?php echo $admit_pateint->date; ?></td>
		                              	</tr>
		                              		<tr>
										                    <td><input type="text"  id="pid" name="pid" size="2" readonly 
										                    value="<?php echo $admit_pateint->pid;?>" hidden></td>
											           	       <td><input type="text"  id="caseid" name="caseid" size="2" readonly
											           	       value="<?php echo $admit_pateint->caseid;?>" hidden></td>
										                                	</tr>
		                              </tbody>
		                        </table>
					    			   </div>
				             </div>
				          </div>
				          
				       <div class="row">
			                  <div class="col-sm-6">
			                    <div class="form-group">
			                        <label for="past_history">Past History</label>
			                        <input class="form-control bd" type="text" id="past_history" name="past_history">
			                    </div>
			                </div>
			                
			                 <div class="col-sm-6">
			                    <div class="form-group">
			                        <label for="personal_history">Personal History </label>
			                        <input class="form-control bd" type="text" id="personal_history" name="personal_history" >
			                    </div>
			                </div>
			                 <div class="col-sm-6">
			                    <div class="form-group">
			                        <label for="family_history">Family History </label>
			                        <input class="form-control bd" type="text" id="family_history" name="family_history">
			                    </div>
			                </div>
			                 <div class="col-sm-6">
			                    <div class="form-group">
			                        <label for="Allergy">Allergy </label>
			                        <input class="form-control bd" type="text" id="Allergy" name="Allergy">
			                    </div>
			                </div>
			                 <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="Provisional_Diag">Provisional Diagnosis</label><span class="text-danger pl-2">*</span>
			                        <input class="form-control bd" type="text" id="Provisional_Diag" name="Provisional_Diag" >
			                    </div>
			                </div>
			                 <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="Charge">Charge </label>
			                        <input class="form-control bd" type="text" id="Charge" name="Charge">
			                    </div>
			                </div>
			                 <!--<div class="col-sm-4">-->
			                    <div class="form-group">
			                        <label for="address">Suggestion</label>
			                        <textarea class="form-control bd" id="address" name="address"rows="3"></textarea>
			                    </div>
			                <!--</div>-->
			                 <div class="col-sm-12">
			                 	 <label for="address">Observation</label>
			                   <!-- <div class="form-group">-->
			                 
	                     <!--<textarea class="form_controt bd col-8 pt-3" id="Observation" name="Observation"rows=""></textarea>-->
			                   <!-- </div>-->
			                </div>
			                 <div class="form-group col-6">
									        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="t" class="control-label">T</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="t" id="t" >&#8457;
									    </div>
									    
									     <div class="form-group col-6">
									        <label for="bp" class="control-label">BP </label>&nbsp;
									       <input class="bd form_controt" type="text"  name="bp" id="bp" >mmHg
									    </div>
									    
									    
									    <div class="form-group col-6">
									        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="p" class="control-label">P</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="p" id="p" >/min
									    </div>
									    
									     <div class="form-group col-6">
									        <label for="rs" class="control-label">RS</label>&nbsp;
									       <input class="bd form_controt" type="text"  name="rs" id="rs" >
									    </div>
			                 <div class="form-group col-6">
									        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="r" class="control-label">R</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="r" id="r" >/min
									    </div>
									     <div class="form-group col-6">
									        <label for="pa" class="control-label">P/A</label>&nbsp;
									      <input class="bd form_controt" type="text"  name="pa" id="pa" >
									    </div>
									   
									    
									    <div class="form-group col-6">
									       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="lname" class="control-label">RBS</label>&nbsp;
									      <input class="bd form_controt" type="text"  name="rbs" id="rbs" >mg/dl
									    </div>
									    <div class="form-group col-6">
									        <label for="cvs" class="control-label">CVS</label>&nbsp;
									      <input class="bd form_controt" type="text"  name="cvs" id="cvs" >
									    </div>
			                 <div class="form-group col-6">
									        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="cns" class="control-label">CNS</label>&nbsp;
									       <input class="bd form_controt" type="text"  name="cns" id="cns" >
									    </div>
									     <div class="form-group col-6">
									        <label for="spo2" class="control-label">Spo2</label>&nbsp;
                           <input class="bd form_controt" type="text"  name="spo2" id="spo2" >%
									    </div>
									    <div class="form-group col-6">
									        <label for="tounge" class="control-label">Tounge</label>&nbsp;
									        <input class="bd form_controt" type="text"  name="tounge" id="tounge" >
									    </div>
	                    <div class="form-group col-12 ">
	                        <!--<label for="address">Suggestion</label>-->
	                       <textarea class="form_controt bd col-8 pt-3" id="Observation" name="Observation"rows=""></textarea>
	                    </div>
			         </div>
			         
							    <form method="post">
		        	 <div class="form-group">
									<table align=center class="table display" id="Chiefadd" style="width:100%">
											   <thead>Chief complains of</thead>
											   		<tbody>
											         <td>C/o<input class="bd form_controt obs_type" type="text"  name="ob1" id="ob1" size="30"> 
												           	From <input class="bd form_controt obs_count" type="text"  name="obday1" id="obday1" size="10">
															    <select name="obdmy1" id="obdmy1" class="bd form_controt c_DMY" >
															    <option value="days" id="target">days</option>
															    <option value="month">month</option>
															    <option value="year">year</option>
															    </select></td>
											   			<td><input type="button" name="Chief_add"  id="Chief_add" class="add_chirf" value="Add"></td>
													 	</tbody>
										 </table>
			         </div>
		        </form>
		        <div class="row">
							                    <div class="col-md-12">
							                        <div class="table-responsive">
							                        	<table id="chiefcomplains" class="table display" style="width:100%">
							                            <!--<table class="table table-border table-striped custom-table datatable mb-0 " id="tbl">-->
							                                <thead>
							                                    <tr style="background-color:#ddd">
							                                        <th scope="col">C/O</th>
							                                        <th scope="col">Form</th>
							                                        <th scope="col">D/M/Y</th>
							                                        <th scope="col">Action</th>
							                                    </tr>
							                                </thead>
							                                <tbody id="tbl"></tbody>
							                            </table>
							                        </div>
							                    </div>
							          </div>
		      
				          
							          
			         <div class="m-t-20 text-center">
			         	<input type="submit" name="save" value="save" class="btn btn-primary submit-btn">
                <input type="button" name="cancel" value="cancel" class="btn btn-danger cancel-btn ">
			         </div>
		        </form>
		          </div>
		          
		          
		          
		        </div>
		          <div id="del_chiefcomplains" class="modal fade delete-modal" role="dialog">
						    <div class="modal-dialog modal-dialog-centered">
						        <div class="modal-content">
						            <div class="modal-body text-center">
						                <img src="../assets/img/sent.png" alt="" width="50" height="46">
						                <h3>Are you sure want to delete this ?</h3>
						                <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
						                    <button type="button" class="btn btn-danger deletecdata" data-id="" id="del_modal">Delete</button>
						                </div>
						            </div>
						        </div>
						    </div>
						</div> 
		    </div>
		  </div>
		  
		  
		  
		  
<?php include 'views/footer.php'; ?>
<script>
   $(document).ready(function() {
   	console.log("ready");
   	views_chiefcomplains();
   	
   	
   	//add complains in database
		   $(document).on('click', '.add_chirf',function(e){
				   	e.preventDefault();
				   	 var	pid = document.getElementById("pid").value;
				   	// console.log("addd");
		   	    var data ={
		   	    	'observation' : $('.obs_type').val(),
		   	    	'obs_count' : $('.obs_count').val(),
		   	    	'obs_dmy' : $('#obdmy1 :selected').text(),
		   	    	'pid' : pid,
		   	    }
		   	    
		   	    $.ajaxSetup({
							    headers: {
							        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
							    }
							});
		   	   
		   	    $.ajax({
			 	 	  		 type :'POST',
			 	 	  		 url :'add_chif',
			 	 	  		 //cache : false,
			 	 	  		 data : data,
			 	 	  		 datatype :"datatype",
			 	 	  		 success: function(response){
			 	 	  		 	console.log(response);
			 	 	  		 	 $('.obs_type').val("");
		   	           $('.obs_count').val("");
		   	           //$('#obdmy1 :selected').text();
		   	           $("#obdmy1").val($("#target option:first").val());

			 	 	  		 } 
			 	 	  	})
		   });
   
	       
   })
   
   
     function views_chiefcomplains(){
   	  	 var	pid = document.getElementById("pid").value;
   	  	  var data ={
		   	    	'pid' : pid,
		   	    }
   	  	 //console.log(pid);
   	  	   $.ajax({
			 	 	  		 type :'GET',
			 	 	  		 url :'add_chiefcop_liste',
			 	 	  		 cache : false,
			 	 	  		 data : data,
			 	 	  		 datatype :"json",
			 	 	  		 success: function(response){
			 	 	  		 	// var	resultdata = response.data;
			 	 	  		 	// console.log(resultdata);
			 	 	  		 	console.log(response);
			 	 	  		 
			 	 	 			// $.each(response,function(index,row){
			 	 	 			// 	// console.log(row);
			 	 	 			// 	var bodydata = `<tr>
			 	 	 			// 	              <td>${ row.observation}</td>
			 	 	 			// 	              <td>${ row.obs_count }</td>
			 	 	 			// 	              <td>${ row.obs_dmy }</td>
			 	 	 			// 	              <td>
          	// 						<button type="button" class="btn btn-info editdata"  data-dataid="${ row.id}">Update</button>			 	 	 	
			 	 	 			// 	    <button type="button" class="btn btn-danger deletedata" data-dataid="${ row.id}">delete</button> 
			 	 	 			// 	              </td>
			 	 	 			// 	              </tr>`;
			 	 	 			// 	              $("#chiefcomplains").append(bodydata);
			 	 	 				
			 	 	 			// })
			 	 	 		
			 	 	  		 } 
			 	 	  	})
			 	 	  	
   //       var t= $('#chiefcomplains').DataTable({
   // 		processing: true,
	  //   	serverSide : false,
	  //   	 searchable: false,
   //       orderable: false,
	  //   	ajax: {
	  //   		url: 'add_chiefcop_liste',
	  //   		type: 'POST',
	  //   		 data : data,
			// 	 	 datatype :"json",
			// 	 	 //success: function(response){
			// 	 	 // 		 	console.log(response);
			 	 	  		
			// 	 	 // 		 } 
	  //   	},
	    	
	    	
	  //   	columns: [
	  //   		// {data: 'id'},
	  //   		{data: 'observation'},
	  //   		{data: 'obs_count'},
	  //   		{data: 'obs_dmy'},
	  //   		{data: ''},
	  //   		],
	  //   		 columnDefs: [
	  //   	{
			// 		"targets": -1,
			// 		"data": "pid",
			// 		"render": function ( data, type, row, meta ) {
			// 			// console.log(row);
			// 		return "<td class='text-right'><div class='dropdown dropdown-action'><a href='#' class='action-icon dropdown-toggle' data-toggle='dropdown' aria-expanded='false'><i class='fa fa-ellipsis-v'></i></a><div class='dropdown-menu dropdown-menu-right'><a class='dropdown-item' href='DoctorEditPatient?p_id="+pid+"&c_id="+row.id+"'><i class='fa fa-pencil m-r-5'></i> Edit</a><a class='dropdown-item deletecdata' href='#' data-toggle='modal' data-target='#del_chiefcomplains' data-dataid="+row.id+"><i class='fa fa-trash-o m-r-5'></i>Delete</a></div></div></td>";
			// 		}
			// 		}
			// 		]
	    	
			// });
			 	 	  	
			 	 	  	
			 	 	  	
			 	 	  	
			 	 	  	
			 	 	  	
   	  }
   
//   $('#Chiefadd').on('click', 'td button Chief_add', function (){
//     console.log("fdsfs");
// });

// 	 	  function my_chiefcomplains(){
// 	    var	pid = document.getElementById("pid").value;
// 	    var	ob1 = document.getElementById("ob1").value;
// 	    var	obday1 = document.getElementById("obday1").value;
// 	    var	obdmy1 = document.getElementById("obdmy1").value;
// 	    const insrt_val=[pid,ob1,obday1,obdmy1];

// 	    $.ajax({
// 			 	 	  		 type :'POST',
// 			 	 	  		 url :'add_chif',
// 			 	 	  		 cache : false,
// 			 	 	  		 data : {'params':insrt_val},
// 			 	 	  		 success: function(message){
// 			 	 	  		 	views_chiefcomplains();
// 			 	 	  		 } 
// 			 	 	  	})
// 			 	 	  	// views_chiefcomplains();
// 	  }
	  // function views_chiefcomplains(){
	  // 	 var	pid = document.getElementById("pid").value;
	  // 	 	// console.log(pid);
	  // 		var t= $('#chiefcomplains').DataTable({
   // 		processing: true,
	  //   	serverSide : false,
	  //   	 searchable: false,
   //       orderable: false,
	  //   	ajax: {
	  //   		url: 'add_chiefcomplains?pid='+pid,
	  //   		type: 'POST',
	  //   	},
	    	
	    	
	  //   	columns: [
	  //   		// {data: 'id'},
	  //   		{data: 'observation'},
	  //   		{data: 'obs_count'},
	  //   		{data: 'obs_dmy'},
	  //   		{data: ''},
	  //   		],
	  //   		 columnDefs: [
	  //   	{
			// 		"targets": -1,
			// 		"data": "pid",
			// 		"render": function ( data, type, row, meta ) {
			// 			// console.log(row);
			// 		return "<td class='text-right'><div class='dropdown dropdown-action'><a href='#' class='action-icon dropdown-toggle' data-toggle='dropdown' aria-expanded='false'><i class='fa fa-ellipsis-v'></i></a><div class='dropdown-menu dropdown-menu-right'><a class='dropdown-item' href='DoctorEditPatient?p_id="+pid+"&c_id="+row.id+"'><i class='fa fa-pencil m-r-5'></i> Edit</a><a class='dropdown-item deletecdata' href='#' data-toggle='modal' data-target='#del_chiefcomplains' data-dataid="+row.id+"><i class='fa fa-trash-o m-r-5'></i>Delete</a></div></div></td>";
			// 		}
			// 		}
			// 		]
	    	
			// }); 
	  // }
// 	  //delete madicine Start
// 	  $(document).on("click","a.deletecdata",function(){
// 	  		  delete_c_id = $(this).data('dataid');
// 	  		  // console.log(delete_c_id)
// 	  });
 	  
// 	  $(document).on("click","button.deletecdata",function(){
	  	
// 	  	 var	pid = document.getElementById("pid").value;
// 	    const delet_id=[pid,delete_c_id];
// 	     var id = $(this).attr( "id" )
// 	  	 console.log(id);
// 	  	 //console.log(pid);
// 	  	  $.ajax({
// 			 	 	  		 type :'POST',
// 			 	 	  		 url :"delete_chiefcomplains",
// 			 	 	  		 cache : false,
// 			 	 	  		 data : {'id':delet_id},
// 			 	 	  		 success: function(Code){
// 			 	 	  		 	console.log(Code);
// 			 	 	  		 	 $.post( "admin_delete.php", { reqidno: id })
// 										   .done(function( data ) {
// 										    alert( data );
// 										    // find the clicked button
// 										    // take the closest 'tr' and remove it
// 										    $("#"+id).closest('tr').remove();
// 										 });
// 			 	 	  		 	  // $("#del_chiefcomplains").css("aria-hidden", "true");
// 			 	 	  		 	// $("#del_chiefcomplains").modal("hide");
// 			 	 	  		 	// views_chiefcomplains();
// 			 	 	  		 } 
// 			 	 	  	})
	  	 
// 	   //location.href = "delete_chiefcomplains?p_id="+pid+"&del_c_id="+delete_c_id;
// });






 //$("#del_modal").click(function(){
 //	console.log("deeleet");
 //   $("#del_chiefcomplains").modal("hide");
 //   // $(this).("tr",hide);
 // });
</script>