<?php 

include 'views/header.php';
?>
<style>
	.icon{
		color: #607580;
	}
</style>
 <input type="text"  id="types" name="types" size="2" readonly value="<?php echo $_SESSION['type'][0]; ?>" hidden>
<!--<body>-->
<!--    <div class="main-wrapper">-->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-8 col-6">
                        <h4 class="page-title">Admission History</h4>
                    </div>
                    
                    
                </div>
            
            <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table id="tbl_A" class="table table-border table-striped custom-table ">
                                <thead>
                                  <tr>
                                  	<th class="text-right">Action</th>
                                    <th>Pateint Name</th>
																		<th>Age</th>
																		<th>Gender</th>
																		<th>Contact</th>
																		<th>Admission Date</th>
																		<th>Dr Name</th>
																		<!--<th>Diagnosis</th>-->
                                    
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php
include 'views/footer.php';
?>

<!-- patients23:19-->

</html>
<script>
$(document).ready(function(){
	
	var t= $('#tbl_A').DataTable({
    		processing: true,
	    	serverSide : false,
	    	ordering:false,
	    	ajax: {
	    		url: 'admission_history_json',
	    		type: 'POST',
	    	},
	    
	    	columnDefs: [
            {
                searchable: false,
                orderable: true,
                targets: 0,
            },
        ],
	    	columns: [
	    		{data: 'admission_id'},
	    		{data: 'Name'},
	    		{data: 'age'},
	    		{data: 'gender'},
	    		{data: 'contact'},
	    		{data: 'date'},
	    		{data: 'referred_to'},
	    		
	    		],
	    		
	    		
	     columnDefs: [
	     	{
					"targets": 0,
					"data": "admission_id",
					"render": function ( data, type, row, meta ) {
						// console.log(row);
					// return "<td class='text-right'><div class='dropdown dropdown-action'><a href='#' class='action-icon dropdown-toggle' data-toggle='dropdown' aria-expanded='false'><i class='fa fa-ellipsis-v'></i></a><div class='dropdown-menu dropdown-menu-right'><a class='dropdown-item' href='admission?p_id="+row.pid+"&admission_id="+data+"'><i class='fa  m-r-5'></i>Edit</a><a class='dropdown-item' href='admission?p_id="+row.pid+"&admission_id_view="+data+"'><i class='fa fa-eye m-r-5'></i>View</a></div></div></td>";
					
					return "<td><a href='admission?p_id="+row.pid+"&admission_id="+data+"'><i class='fa fa-pencil m-l-5 icon' title='Edit'></i></a><a href='admission?p_id="+row.pid+"&admission_id_view="+data+"'><i class='fa fa-eye m-l-5 icon'  title='View'></i></a></td>";
						
					}
					
					}
					]
			});	
			
			
		    //delete data
		     $(document).on("click","a.deletecdata",function(e){
					     	  e.preventDefault();
				  		  delete_a_id = $(this).data('dataid');
				  		  	$('#del_a').val(delete_a_id);
				  		  console.log(delete_a_id)
	        });
	  
	  	  $(document).on("click","button.deletecdata",function(){
	  	            	var id = $('#del_a').val();
							  	 var	pid = document.getElementById("pid").value;
							    const delet_id=[pid,id];
							    // var id = $(this).attr( "id" )
							  	 //console.log(delet_id);
                    $.ajaxSetup({
									        headers: {
									                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
									             }
									    });
									    
							  	  $.ajax({
									 	 	  		 type :'POST',
									 	 	  		 //"delete_admission",
									 	 	  		 url :"delete_chiefcomplains",
									 	 	  		 cache : false,
									 	 	  		 data : {'id':delet_id},
									 	 	  		 success: function(Code){
									 	 	  		 	// console.log(Code);
									 	 	  		 	 $(".del_admission").attr('data-dismiss', 'modal');
									 	 	  		 	// $('#chiefcomplains').DataTable().ajax.reload();
									 	 	  		 	// $("#del_chiefcomplains").modal("hide");
									 	 	  		  
									 	 	  		 } 
									 	 	  	})
              });
              
	 
})
	  
</script>
				