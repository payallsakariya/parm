<?php
include 'views/header.php';
	$edit_pateint=$_SESSION['DEditpatient'];
if($_SESSION['type'][0]== 'doctor'){
		?>
		   
		  <style>
				.bg{
					background-color: #0fa7c9;
					color: #fff;
				}
			</style>
			<div class="page-wrapper">
		    <div class="content">
		      <div class="row">
		       <div class="col-lg-12 ">
		        <form  method="post">
		               <div class="row">
		                  <div class="col-md-12">
		                      <div class="table-responsive">
		                      	<table id="tbl" class="table display" style="width:100%" >
		                          <!--<table class="table table-border table-striped custom-table datatable mb-0 " id="tbl">-->
		                              <thead>
		                                  <tr class="bg">
		                                      <th scope="col">Case No.</th>
		                                      <th scope="col">Date</th>
		                                      <th scope="col">Time</th>
		                                      <th scope="col">Name</th>
		                                      <th scope="col">Age</th>
		                                      <th scope="col">Gender</th>
		                                      <th scope="col">Phone</th>
		                                  </tr>
		                              </thead>
		                              <tbody>
		                              	<tr>
		                              	<td><?php echo $edit_pateint->caseid; ?></td>
		                              	<td><?php echo $edit_pateint->date; ?></td>
		                              	<td><?php echo $edit_pateint->time; ?></td>
		                              	<td><?php echo $edit_pateint->Name; ?></td>
		                              	<td><?php echo $edit_pateint->age; ?></td>
		                              	<td><?php echo $edit_pateint->gender; ?></td>
		                              	<td><?php echo $edit_pateint->contact; ?></td></tr>
		                              </tbody>
		                                   <td><input type="text"  id="pid" name="pid" size="2" readonly 
										                    value="<?php echo $edit_pateint->pid;?>" hidden="" >
										                    <input type="text"  id="case_id" name="case_id" size="2" readonly
							           	                 value="<?php echo $edit_pateint->caseid;?>" hidden="">
										                    </td>
		                        </table>
		                        
										        <table align=center border=1 class="table display" style="width:100%">
										          <thead class="bg">
										          	<tr>
										            	<th>Charge</th>
										            	<th>Disease</th>
										            	<th>Medecine</th>
										            </tr>
										            </thead>
										            <tbody>
										            	  <?php  
													           if($_GET['caseid']){
													           	$updat = $_SESSION['update_patient_info'];
													           ?>
													            <tr>
														            <td><input type="text" name="charge" id="charge" maxlength="5" size="4"  tabindex="1" value="<?php echo $updat->charge; ?>"></td>
														            <td><input type="text" name="disease" maxlength="30" size="4" value="<?php echo $updat->disease; ?>"></td>
													              <td><input type="text" name="medicine" id="medicine" maxlength="100" size="30"  tabindex="2" value="<?php echo $updat->medicine; ?>"></td>
													            </tr>
													          
													           <?php }else{ ?>
										            	
											            <tr>
												            <td><input type="text" name="charge" id="charge" maxlength="5" size="4"  tabindex="1" value=""></td>
												            <td><input type="text" name="disease" maxlength="30" size="4"></td>
											              <td><input type="text" name="medicine" id="medicine" maxlength="100" size="30"  
											              tabindex="2" value=""></td>
											            </tr>
											            <?php } ?>
                               </tbody>
										        </table>
										       <table>
										       	<tr>
						                    <td><input type="text"  id="pid" name="pid" size="2" readonly 
						                    value="<?php echo $updat->pid;?>" hidden></td>
							           	       <td><input type="text"  id="caseid" name="caseid" size="2" readonly
							           	       value="<?php echo $updat->caseid;?>" hidden></td>
							           	       <td><input type="text"  id="u_id" name="u_id" size="2" readonly
							           	       value="<?php echo $updat->id;?>" hidden></td>
      											</tr>
										    	
								 	</table>
					    			   </div>
				             </div>
				          </div>
				     <!--</form>-->
		       <!-- <form method="post">-->
		   	<table align=center class="table display" style="width:100%">
		   <thead class="bg"><th>Medicine</th><th>Morning</th><th>Afternoon</th><th>Night</th><th>Description</th><th></th><th></th></thead>
		   		<tbody>
		    	<td><input type="text" name="med_name" id="med_name" value="" size="5">
		    	 <input class="cid" type="text"  name="cid" id="cid" value="" size="1" hidden=""></td>
		   			<td><select name="Morning" size="1" id="Morning">
						    <option value="0">0</option>
						    <option value="1">1</option>
						    <option value="1/2">1/2</option>
						    <option value="2">2</option>
						    <option value="2.5ml">2.5ml</option>
						    <option value="3">3</option>
						    <option value="3.5ml">3.5ml</option>
						    <option value="5ml">5ml</option>
						    <option value="7.5ml">7.5ml</option>
						    <option value="10ml">10ml</option>
						    </select>
						    <select name="breakfast" id="breakfast">
						    	<option>select</option>
						    	<option value="before_breakfast">before_breakfast</option>
						    <option value="after_breakfast">after_breakfast</option>
						    </select>
						    </td>
		   			<td><select name="Afternoon" size="1" id="Afternoon">
						    <option value="0">0</option>
						    <option value="1">1</option>
						    <option value="1/2">1/2</option>
						    <option value="2">2</option>
						    <option value="2.5ml">2.5ml</option>
						    <option value="3">3</option>
						    <option value="3.5ml">3.5ml</option>
						    <option value="5ml">5ml</option>
						    <option value="7.5ml">7.5ml</option>
						    <option value="10ml">10ml</option>
						    </select>
						    <select name="lunch" id="lunch">
						    	<option>select</option>
						    	<option value="before_lunch">before_lunch</option>
						    <option value="after_lunch">after_lunch</option>
						    </select></td>
		   			<td><select name="Night" size="1" id="Night">
						    <option value="0">0</option>
						    <option value="1">1</option>
						    <option value="1/2">1/2</option>
						    <option value="2">2</option>
						    <option value="2.5ml">2.5ml</option>
						    <option value="3">3</option>
						    <option value="3.5ml">3.5ml</option>
						    <option value="5ml">5ml</option>
						    <option value="7.5ml">7.5ml</option>
						    <option value="10ml">10ml</option>
						    </select>
						    <select id="dinner" name="dinner">
						    	<option>select</option>
						    	<option value="before_dinner">before_dinner</option>
						    <option value="after_dinner">after_dinner</option>
						    </select></td>
		   			<td ><input type="text" name="description" id="description" value="" size="5"></td>
		   		<td class=""><input type="button" name="Madicine_updat"  id="Madicine_updat" class="Madicine_updat" 
		   		value="Update" hidden="hidden" size="4"></td>
		   			<td><input type=submit name="m_add"  id="m_add" value="Add" class="M_Add" size="1"></td>
		   			
		          
		   		</tbody>
		   	</table>
				   </div>
				 </div>
						   
              <div class="row">
		                    <div class="col-md-12">
		                        <div class="table-responsive">
		                        	<table id="madicine" class="table display" style="width:100%">
		                            <!--<table class="table table-border table-striped custom-table datatable mb-0 " id="tbl">-->
		                                <thead>
		                                    <tr style="background-color:#ddd">
		                                        <th scope="col">Medicine</th>
		                                        <th scope="col">Morning</th>
		                                        <th scope="col">Afternoon</th>
		                                        <th scope="col">Night</th>
		                                        <th scope="col">Date</th>
		                                        <th scope="col">Description</th>
		                                        <th scope="col">Action</th>
		                                    </tr>
		                                </thead>
		                            </table>
		                        </div>
		                    </div>
		          </div>
							   <div class="m-t-20 text-center">
							   	<?php  if($_GET['caseid']){ ?>
							   	 <input type=submit name="up_date"  id="up_date" value="Update" class="btn btn-primary" tabindex="3" >
							   	 <input type="submit" name="Upd_cancel" value="cancel" id="Upd_cancel" class="btn btn-danger cancel-btn ">
							   	<?php }else { ?>
		   	 	            <input type=submit name="D_save"  id="D_save" value="Save" class="btn btn-primary" >
		   	 	            <input type="submit" name="Sv_cancel" value="cancel" id="Sv_cancel" class="btn btn-danger cancel-btn ">
		   	 	            <?php }?>
			                
			           </div>
			         </form>
				         
				     <div id="del_madicine" class="modal fade delete-modal" role="dialog">
							    <div class="modal-dialog modal-dialog-centered">
							        <div class="modal-content">
							            <div class="modal-body text-center">
							            	<input type="text" id="del_m" name="del_m" value="" hidden="">
							                <img src="../assets/img/sent.png" alt="" width="50" height="46">
							                <h3>Are you sure want to delete this madicine ?</h3>
							                <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
							                    <button type="submit" class="btn btn-danger deletemdata" id="del_modal"><a href="#"  data-dismiss="modal">Delete</a></button>
                   <!--<button type="button" class="btn btn-danger deletecdata" id="del_modal"><a href="#"  data-dismiss="modal">Delete</a></button>-->
							                </div>
							            </div>
							        </div>
							    </div>
							</div>     
		    </div>
		  </div>
		
		<?php
		}else{
			?>
			  <style>
				.bg{
					background-color: #0fa7c9;
					color: #fff;
				}
			</style>
			<div class="page-wrapper">
		    <div class="content">
		      <div class="row">
		       <div class="col-lg-12 ">
		        <form  method="post">
		               <div class="row">
		                  <div class="col-md-12">
		                      <div class="table-responsive">
		                      	<table id="tbl" class="table display" style="width:100%" >
		                          <!--<table class="table table-border table-striped custom-table datatable mb-0 " id="tbl">-->
		                              <thead>
		                                  <tr class="bg">
		                                      <th scope="col">Case No.</th>
		                                      <th scope="col">Date</th>
		                                      <th scope="col">Time</th>
		                                      <th scope="col">Name</th>
		                                      <th scope="col">Age</th>
		                                      <th scope="col">Gender</th>
		                                      <th scope="col">Phone</th>
		                                  </tr>
		                              </thead>
		                              <tbody>
		                              	<tr>
		                              	<td><?php echo $edit_pateint->caseid; ?></td>
		                              	<td><?php echo $edit_pateint->date; ?></td>
		                              	<td><?php echo $edit_pateint->time; ?></td>
		                              	<td><?php echo $edit_pateint->Name; ?></td>
		                              	<td><?php echo $edit_pateint->age; ?></td>
		                              	<td><?php echo $edit_pateint->gender; ?></td>
		                              	<td><?php echo $edit_pateint->contact; ?></td></tr>
		                              </tbody>
		                        </table>
										        <table align=center border=1 class="table display" style="width:100%">
										          <thead class="bg">
										          	<tr>
										          		<?php 
										          			$payinoff = $_SESSION['pay_inof'];
										          			// print_r($payinoff);
                                   if($payinoff['total_fee'] == 0.00){
                                   	?>
                                   	<th>Charge_today </th>
										            	<th>Paedamout</th>
                                  <th>Disease</th>
										            	<th>Medecine</th>
                                   	<?php
                                   }else{
                                   	?>
                                  <th>Actionn</th>
										          		<th>Payment</th>	
										          		<th>TotalPay</th>
										          		<th>Panding Fees</th>
										            	<th>Paedamout</th>
										            	<th>TotalAmount</th>
										            	<th>ChargeToday </th>
                                  <th>Disease</th>
										            	<th>Medecine</th>
                                   	<?php
                                   }
                                   
                                 ?>
										            </tr>
										            </thead>
										           <tbody>
													           <?php  
													           	$payinof = $_SESSION['pay_inof'];
													           	// print_r($payinof);
													           	 if($payinof['total_fee']>0){
													           		?>
													           		   <tr>
												<td><input type=submit name="pay_ments"  id="pay_ments" value="Yes"  tabindex="2" >
											       	<input type=submit name="pay_update"  id="pay_update" value="Update"  tabindex="1" hidden="">
													 <input type=submit name="pay_cancel"  id="pay_cancel" value="No"  tabindex="1" ></td>
													 <td><input type="text" name="pay" id="pay" maxlength="5" size="4"  tabindex="1" value=""></td>
														            <td><?php echo $payinof['total_fee']; ?></td>
														            <td><?php echo $payinof['payPanding']; ?></td>
														            <td><?php echo $payinof['paymoney'] ?></td>
														            <td><?php echo $payinof['totalAmount'] ?></td>
														            <td><?php echo $payinof['charge'] ?></td>
														            <td><?php echo $payinof['disease']; ?></td>
													              <td><?php echo $payinof['medicine']; ?></td>
													            </tr>
													            <tr>
													            	<td>
													            		<input type="text" name="pay_money" id="pay_money" 
													            		  value="<?php echo $payinof['paymoney']; ?>" hidden="">
													            	</td>
													            </tr>
													            
													           		<?php
													           	}else{
													           		?>
													           	 <tr>
												                <td><?php echo $payinof['charge'] ?></td>
														            <td><?php echo $payinof['paymoney'] ?></td>
														            <td><?php echo $payinof['disease']; ?></td>
													              <td><?php echo $payinof['medicine']; ?></td>
													            </tr>
													            <tr>
													            	<td>
													            		<input type="text" name="pay_money" id="pay_money" 
													            		  value="<?php echo $payinof['paymoney']; ?>" hidden="">
													            	</td>
													            </tr>
													            
													           		<?php
													           	   }
													           ?>
                           </tbody>
										        </table>
										       <table>
										                                	<tr>
										                    <td><input type="text"  id="pid" name="pid" size="2" readonly 
										                    value="<?php echo $edit_pateint->pid;?>"  hidden=""></td>
											           	       <td><input type="text"  id="caseid" name="caseid" size="2" readonly
											           	       value="<?php echo $edit_pateint->caseid;?>" hidden></td>
											           	       	<input type="text" name="payPanding" id="payPanding" 
													            		  value="<?php echo $payinof['payPanding']; ?>" hidden="">
													            		<input type="text" name="totalAmount" id="totalAmount" 
													            		  value="<?php echo $payinof['totalAmount']; ?>" hidden="">
										                                	</tr>
										    	
									</table>
					    			   </div>
				             </div>
				          </div>
				     </form>
				   </div>
				 </div>
		    </div>
		  </div>
			<?php
		}
		include 'views/footer.php'
		?>
<script>
$(document).ready(function() {
    var paymoney = $('#pay_money').val();
    var payPanding = $('#payPanding').val();
    var totalAmount = $('#totalAmount').val();
    console.log(paymoney);
    console.log(payPanding);
    console.log(totalAmount);
         if(paymoney>0 || totalAmount>0 ){
         	 $("#pay_update").removeAttr('hidden');
           $("#pay_ments").hide();
           $("#pay_cancel").hide();
         	
         }else{
         	$("#pay_update").attr('hidden', 'hidden');
         	 $("#pay_ments").show();
         	 $("#pay_cancel").show();
         }
         

         
      madicinedatatable();

	  function madicinedatatable(){
	  var	pid = document.getElementById("pid").value;  
	  // console.log(pid);
	  	var t= $('#madicine').DataTable({
		 
    		processing: true,
	    	serverSide : false,
	    	 searchable: false,
          orderable: false,
	    	ajax: {
	    		url: 'madicine_prescriptions_add?pid='+pid,
	    		type: 'POST',
	    	},
	    	
	    	
	    	columns: [
	    		// {data: 'id'},
	    		{data: 'medicine'},
	    		{data: 'morning'},
	    		{data: 'afternoon'},
	    		{data: 'night'},
	    		{data: 'Date'},
	    		{data: 'description'},
	    		{data: ''},
	    		],
	    		 columnDefs: [
	    	{
					"targets": -1,
					"data": "pid",
					"render": function ( data, type, row, meta ) {
						// console.log(row.payment);
					return "<td class='text-right'><div class='dropdown dropdown-action'><a href='#' class='action-icon dropdown-toggle' data-toggle='dropdown' aria-expanded='false'><i class='fa fa-ellipsis-v'></i></a><div class='dropdown-menu dropdown-menu-right'><button type='button' value='"+row.id+"' class='dropdown-item edit_c'><i class='fa fa-pencil m-r-5'></i> Edit</button><a class='dropdown-item deletemdata' href='#' data-toggle='modal' data-target='#del_madicine' data-dataid="+row.id+"><i class='fa fa-trash-o m-r-5'></i>Delete</a></div></div></td>";
					}
					}
					]
	    	
			});       
	  }
	  
	  //Add_madicins for patient
	    $(document).on('click', '.M_Add',function(e){
				   	e.preventDefault();
				   	 var	pid = document.getElementById("pid").value;
				   	var Morning =$('#Morning :selected').text();
				   	var breakfast =$('#breakfast :selected').text();
				   	var Afternoon =$('#Afternoon :selected').text();
				   	var lunch =$('#lunch :selected').text();
				   	var Night =$('#Night :selected').text();
				   	var dinner =$('#dinner :selected').text()
				   	 var data ={
		   	    	'med_name' : $('#med_name').val(),
		   	    	'Morning' : Morning+','+breakfast,
		   	    	'Afternoon' : Afternoon+','+lunch,
		   	    	'Night' : Night+','+dinner,
		   	    	'description' :$('#description').val(),
		   	    	'pid' : pid,
		   	    }
		   	    $.ajaxSetup({
							    headers: {
							        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
							    }
							});
		   	   
		   	    $.ajax({
				 	  		 type :'POST',
				 	  		 url :'Add_madicins',
				 	  		 data : data,
				 	  		 datatype :"datatype",
				 	  		 success: function(response){
		   	           $('#med_name').val("");
		   	           $('#description').val("");
		   	           $("#Morning").val($("#target option:first").val());
		   	           $("#breakfast").val($("#target option:first").val());
		   	           $("#Afternoon").val($("#target option:first").val());
		   	           $("#lunch").val($("#target option:first").val());
		   	           $("#Night").val($("#target option:first").val());
		   	           $("#dinner").val($("#target option:first").val());
		   	           $('#madicine').DataTable().ajax.reload();

				 	  		 } 
				 	  	})
	  
	    });
	  
	  
	  //Edit madicine for patient
	     $(document).on('click', '.edit_c',function(e){
				  	e.preventDefault();
				  	var id = $(this).val();
				  	var data ={
		   	    	           'id' : id,
		   	              }
				  	 $.ajax({
				 	  		 type :'POST',
				 	  		 url :'selecet_madicins',
				 	  		 data : data,
				 	  		 datatype :"datatype",
				 	  		 success: function(response){
				 	  		 	// console.log(response);
				 	  		 	var t = JSON.parse(response);
		   	          $('#med_name').val(t['medicine']);
		   	          $('#description').val(t['description']);
		   	          $("#Morning").val(t['morning']);
		   	          $("#breakfast").val(t['breakfast']);
		   	          $("#Afternoon").val(t['afternoon']);
		   	          $("#lunch").val(t['lunch']);
		   	          $("#Night").val(t['night']);
		   	          $("#dinner").val(t['dinner']);
		   	          $('#cid').val(t['id']);
		   	            $(".M_Add").hide();
		   	          $(".Madicine_updat").removeAttr('hidden');
		   	          $('#madicine').DataTable().ajax.reload();

				 	  		 } 
				 	  	})
		    });
	  
	   //Eidt select  resonse and  update data
		  $(document).on('click', '.Madicine_updat',function(e){
						  	e.preventDefault();
            var Morning =$('#Morning :selected').text();
				  	var breakfast =$('#breakfast :selected').text();
				  	var Afternoon =$('#Afternoon :selected').text();
				  	var lunch =$('#lunch :selected').text();
				  	var Night =$('#Night :selected').text();
				  	var dinner =$('#dinner :selected').text()
				  	var data ={
		  	    	'med_name' : $('#med_name').val(),
		  	    	'Morning' : Morning+','+breakfast,
		  	    	'Afternoon' : Afternoon+','+lunch,
		  	    	'Night' : Night+','+dinner,
		  	    	'description' :$('#description').val(),
		  	    	'id' :  $('#cid').val(),
		  	    }
				  	    $.ajax({
					 	 	  		 type :'POST',
					 	 	  		 url :'update_madicine',
					 	 	  		 data : data,
					 	 	  		 datatype :"datatype",
					 	 	  		 success: function(response){
					 	 	  		 	// console.log(response);
					 	 	  	$('#med_name').val("");
		  	          $('#description').val("");
		  	          $("#Morning").val($("#target option:first").val());
		  	          $("#breakfast").val($("#target option:first").val());
		  	          $("#Afternoon").val($("#target option:first").val());
		  	          $("#lunch").val($("#target option:first").val());
		  	          $("#Night").val($("#target option:first").val());
		  	          $("#dinner").val($("#target option:first").val());
			   	         $(".M_Add").show();
			   	         $(".Madicine_updat").attr('hidden', 'hidden');
                  $('#madicine').DataTable().ajax.reload();
		
					 	 	  		 } 
					 	 	  	})
		        });  
		        
	       
   });
   
    

//Start deleted  madcin pricrption 
      $(document).on("click","a.deletemdata",function(e){
					     	  e.preventDefault();
				  		  delete_m_id = $(this).data('dataid');
				  		  	$('#del_m').val(delete_m_id);
	        });
	  
	    $(document).on("click","button.deletemdata",function(){
	    	            var id = $('#del_m').val();
  							    const delet_id=[id];

                    $.ajaxSetup({
									        headers: {
									                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
									            }
									    });
									    
							  	  $.ajax({
									 	 	  		 type :'POST',
									 	 	  		 url :"delete_madicine",
									 	 	  		 cache : false,
									 	 	  		 data : {'id':delet_id},
									 	 	  		 success: function(Code){
									 	 	  		 	$(".deletemdata").attr('data-dismiss', 'modal');
									 	 	  		 	$('#madicine').DataTable().ajax.reload();
									 	 	  		 } 
									 	 	  	})
              });
//End
</script>