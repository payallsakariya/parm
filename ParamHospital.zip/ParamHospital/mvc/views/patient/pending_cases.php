<?php 
include 'views/header.php';
// print_r($_SESSION['type'][0]);exit;

?>
 <input type="text"  id="type" name="type" size="2" readonly value="<?php echo $_SESSION['type'][0]; ?>" hidden>
              <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-8 col-6">
                        <h4 class="page-title">Pending Cases</h4>
                    </div>
                </div>
                <div class="row filter-row">
                    <div class="col-sm-4 col-md-5">
                    	<?php 
                    if($_SESSION['type'][0]=='staff'){
                    	?>
                        <div class="form-group form-focus">
		                      <select id="month" name="month" style="width:100%" class="form-control floating select2">
		                      </select>
                            <input type="hidden" name="pid"  id="pid" />
                        </div>
                        <?php }?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                        	<table id="tbl" class="table display" style="width:100%">
                            <!--<table class="table table-border table-striped custom-table datatable mb-0 " id="tbl">-->
                                <thead>
                                    <tr>
                                    	  <th class="text-right">Action</th>
                                        <th scope="col">#</th>
                                        <th scope="col">Case No.</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Time</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Age</th>
                                        <th scope="col">Gender</th>
                                        <th scope="col">Phone</th>
                                        <?php //if($_SESSION['type'][0] == 'staff'){ ?>
                                          <th scope="col">paypending</th>
                                          <?php //} ?>
                                      
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
           </div>
        <div id="delete_patient" class="modal fade delete-modal" role="dialog">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body text-center">
                        <img src="../assets/img/sent.png" alt="" width="50" height="46">
                        <h3>Are you sure want to delete this Patient?</h3>
                        <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                            <button type="submit" class="btn btn-danger deletedata" data-id="" id="deleterec">Delete</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        
<?php include 'views/footer.php'; ?>    

<script>
    $(document).ready(function(){
	        pendding_cases();
    // start select2 pateint ajax call
				$("#month").select2({
					 placeholder: 'Select a patient', 
				    ajax: {
				      url: "patient_pending_cases",
				      type: 'POST',
				      dataType: 'json',
				      data: 
				      (params) => {
				        return {
				          q: params.term,
				        }
				      },
				      processResults: (data, params) => {
				        const results = data.data.map(data => {
				          return {
				            text: data.Name+"("+data.pmshid+")",
				            id: data.pid,
				            pmshid: data.pmshid,
				          };
				        });
				        return {
				          results: results,
				        }
				      },
				    },
				  });
				  
				 $("#month").on("change",function(){
				 var pid = document.getElementById("month").value;
				 
				 location.href = "add_pending_cases?pid="+pid;

				 })
        //End
})

   function pendding_cases(){
   	var	typeeee = document.getElementById("type").value;  
    	var t= $('#tbl').DataTable({
    		processing: true,
	    	serverSide : false,
	    	"ordering": false,
	    	ajax: {
	    		url: 'pending_cases_json',
	    		type: 'POST',
	    	},
	    
	    	columnDefs: [
            {
                searchable: false,
                orderable: false,
                targets: 0,
            },
        ],
	    	columns: [
	    		{data: 'caseid'},
	    		{data: 'caseid'},
	    		{data: 'pmshid'},
	    		{data: 'date'},
	    		{data: 'time'},
	    		{data: 'Name'},
	    		{data: 'age'},
	    		{data: 'gender'},
	    		{data: 'contact'},
	    		{data: 'paypending'},
	    	
	    		],
	    		
	    		
	     columnDefs: [
	     	{
					"targets": 0,
					"data": "caseid",
					"render": function ( data, type, row, meta ) {
						if(typeeee == 'doctor'){
					return "<td class='text-right'><div class='dropdown dropdown-action'><a href='#' class='action-icon dropdown-toggle' data-toggle='dropdown' aria-expanded='false'><i class='fa fa-ellipsis-v'></i></a><div class='dropdown-menu dropdown-menu-right'><a class='dropdown-item' href='DoctorEditPatient?case_id="+data+"'><i class='fa  m-r-5'></i>Update</a><a class='dropdown-item deletedata' href='../admission/AdmitPatient?p_id="+row.pid+"'><i class='fa m-r-5'></i>Admit</a></div></div></td>";
						}else{ 
						// return "<td><a class='dropdown-item' href='edit_patient?p_id="+row.pid+"'><i class='fa fa-pencil m-l-5' title='Edit'></i></a> <a class='deletedata' href='#' data-toggle='modal' data-target='#delete_patient' data-dataid="+row.id+"><i class='fa fa-trash m-r-5' title='Delete'></i></a></td>";
						
						return "<td class='text-right'><div class='dropdown dropdown-action'><a href='#' class='action-icon dropdown-toggle' data-toggle='dropdown' aria-expanded='false'><i class='fa fa-ellipsis-v'></i></a><div class='dropdown-menu dropdown-menu-right'><a class='dropdown-item' href='edit_patient?p_id="+row.pid+"'><i class='fa fa-pencil m-r-5'></i> Edit</a><a class='dropdown-item deletedata' href='#' data-toggle='modal' data-target='#delete_patient' data-dataid="+row.id+"><i class='fa fa-trash-o m-r-5'></i>Delete</a></div></div></td>";
						}
					}
					}
					]
			});
					
					//index # = 1,2,3..
					// t.on('order.dt search.dt', function () {
					// 		let i = 1;
					// 		t.cells(null, 0, { search: 'applied', order: 'applied' }).every(function (cell) {
					// 		  this.data(i++);
					// 		});
	    //     }).draw();
	        
   } 
    
//delete peatent Start
 	  $(document).on("click","a.deletedata",function(){
 	  		  delete_id = $(this).data('dataid');
 	  });
 	  
 	  $(document).on("click","button.deletedata",function(){
 	
 	        location.href = "delete_patient?id="+delete_id;
    });

    $(document).on("click","a.paydata",function(){
 	  		  delete_id = $(this).data('dataid');
 	  });
// End

</script>