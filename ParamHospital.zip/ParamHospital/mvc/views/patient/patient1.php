<?php 
 include 'views/header.php';
  if(empty($_GET['p_id'])){
   	$add_patient = $_SESSION['AddPatient'];
 ?>
 <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Add Patient</h4>
                        <?php 	echo $pid;?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">

                        <form  method="post">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="pmhid">PMH Card ID</label>
                                        <input class="form-control" type="text" id="pmhid" name="pmhid" value="<?php echo $add_patient['pmhid']; ?>">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="phone">Phone </label><span class="text-danger pl-2">*</span>
                                        <input class="form-control" type="text" id="phone" name="phone" value="<?php echo $add_patient['phone']; ?>">
                                         <span class="text-danger"><?php echo $Errphone; ?></span>
                                    </div>
                                </div>

                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="fname">First Name </label><span class="text-danger pl-2">*</span>
                                        <input class="form-control" type="text" id="fname" name="fname" value="<?php echo $add_patient['fname']; ?>">
                                         <span class="text-danger"><?php echo $Errfname; ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="mname">Middle Name</label><span class="text-danger pl-2">*</span>
                                        <input class="form-control" type="text" id="mname" name="mname" value="<?php echo $add_patient['mname']; ?>">
                                         <span class="text-danger"><?php echo $Errmname; ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="lname">Last Name </label><span class="text-danger pl-2">*</span>
                                        <input class="form-control" type="text" id="lname" name="lname" value="<?php echo $add_patient['lname']; ?>">
                                         <span class="text-danger"><?php echo $Errlname; ?></span>
                                    </div>
                                </div>
                                   <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Date of Birth</label><span class="text-danger pl-2">*</span>
                                        <div class="cal-icon">
                                            <input type="text" class="form-control datetimepicker" name="dob"id="dob" value="<?php echo $add_patient['dob']; ?>"                                                  onchange="mydatepicker()" >
                                        </div>
                                        <span class="text-danger"><?php echo $Errbirthdate; ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="age">Age</label>
                                        <input class="form-control" type="number" id="age" name="age" readonly=""
                                          value="<?php echo $add_patient['age']; ?>">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="bloodgroup">Blood Group</label><span class="text-danger pl-2">*</span>
                                        <select class="form-control" id="bloodgroup" name="bloodgroup">
                                            <option value="">Plase Select</option>
                                            <option value="A+"  <?php if($add_patient['bloodgroup'] == 'A+'){echo 'Selected'; } ?> >A+</option>
                                            <option value="A-" <?php if($add_patient['bloodgroup'] == 'A-'){echo 'Selected'; } ?>>A-</option>
                                            <option value="B+" <?php if($add_patient['bloodgroup'] == 'B+'){echo 'Selected'; } ?>>B+</option>
                                            <option value="B_" <?php if($add_patient['bloodgroup'] == 'B-'){echo 'Selected'; } ?>>B-</option>
                                            <option value="AB+" <?php if($add_patient['bloodgroup'] == 'AB+'){echo 'Selected'; } ?>>AB+</option>
                                            <option value="AB-" <?php if($add_patient['bloodgroup'] == 'AB-'){echo 'Selected'; } ?>>AB-</option>
                                            <option value="O+" <?php if($add_patient['bloodgroup'] == 'O+'){echo 'Selected'; } ?>>O+</option>
                                            <option value="O-" <?php if($add_patient['bloodgroup'] == 'O-'){echo 'Selected'; } ?>>O-</option>
                                        </select>
                                         <span class="text-danger"><?php echo $Errbloodgroup; ?></span>
                                    </div>
                                </div>
                               
                                <div class="col-sm-4">
                                    <div class="form-group gender-select">
                                        <label class="gen-label" for="gender">Gender: <span class="text-danger pl-2">*</span></label>
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                          <input type="radio" name="gender" id="gender" class="form-check-input" value="male" 
                                          <?php if($add_patient['gender'] == 'male'){echo 'checked';}  ?> >Male
                                            </label>
                                        </div>
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                                <input type="radio" name="gender" id="gender" class="form-check-input"  value="female"
                                                <?php if($add_patient['gender'] == 'female'){echo 'checked';}  ?>>Female
                                            </label>
                                        </div>
                                        <span class="text-danger"><?php echo $Errgender; ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="religion">Religion</label><span class="text-danger pl-2">*</span>
                                        <input class="form-control" type="text" id="religion" name="religion" value="<?php echo $add_patient['religion']; ?>">
                                        <span class="text-danger"><?php echo $Errreligion; ?></span>
                                    </div>
                                </div>


                                
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="postalcode">Postal Code</label><span class="text-danger pl-2">*</span>
                                     <input type="text" class="form-control" id="postalcode" name="postalcode" value="<?php echo $add_patient['postalcode']; ?>">
                                        <span class="text-danger"><?php echo $Errpostalcode; ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="address">Address</label><span class="text-danger pl-2">*</span>
                                        <textarea class="form-control" id="address" name="address" value=""
                                        rows="3"><?php echo $add_patient['address']; ?></textarea>
                                        <span class="text-danger"><?php echo $Erraddress; ?></span>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label for="mhistory">Medical History</label><span class="text-danger pl-2">*</span>
                                                <textarea class="form-control" id="mhistory" name="mhistory"  value=""
                                    rows="3"><?php echo $add_patient['mhistory']; ?></textarea>
                                    <span class="text-danger"><?php echo $Errmhistory; ?></span>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                <div class="m-t-20 text-center">
                    <!--<button class="btn btn-primary submit-btn mx-auto" id="" name="">Create Patient</button>-->
                     <input type="submit" name="Submit" id="Submit"  value="Create Patient" class="btn btn-primary submit-btn mx-auto">
                </div>

                </form>
                      </div>
                </div>
            </div>
   </div> 
 <?php
	
  }else{
  	$edit_patient=$_SESSION['EditPatient'];
  	// if($_SESSION['patient_edit']){
  	// 	$edit_patient =$_SESSION['patient_edit'];
  	// }
  	// echo"<pre>";
  	// print_r($edit_patient);
	?>
	<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <h4 class="page-title">Edit Patient</h4>
            </div>
        </div>
        <div class="row">
         <div class="col-lg-8 offset-lg-2">
          <form  method="post">
	            <div class="row">
	                <div class="col-sm-6">
	                    <div class="form-group">
                      <label for="pmhid">PMH Card ID</label>
                      <input class="form-control" type="text" id="pmhid" name="pmhid" 
                      value="<?php echo $edit_patient->pmhid; ?>">
	                    </div>
	                </div>
	                <div class="col-sm-6">
	                    <div class="form-group">
	                        <label for="phone">Phone </label><span class="text-danger pl-2">*</span>
	                        <input class="form-control" type="text" id="phone" name="phone" 
	                        value="<?php echo $edit_patient->contact; ?>">
	                        <span class="text-danger"><?php echo $Errphone; ?></span>
	                    </div>
	                </div>
	                <div class="col-sm-4">
	                    <div class="form-group">
	                        <label for="fname">First Name </label><span class="text-danger pl-2">*</span>
	                        <input class="form-control" type="text" id="fname" name="fname"
	                        value="<?php echo $edit_patient->pfname; ?>">
	                        <span class="text-danger"><?php echo $Errfname; ?></span>
	                    </div>
	                </div>
	                <div class="col-sm-4">
	                    <div class="form-group">
	                        <label for="mname">Middle Name</label><span class="text-danger pl-2">*</span>
	                        <input class="form-control" type="text" id="mname" name="mname" 
	                        value="<?php echo $edit_patient->pmname; ?>">
	                        <span class="text-danger"><?php echo $Errmname; ?></span>
	                    </div>
	                </div>
	                <div class="col-sm-4">
	                <div class="form-group">
	                        <label for="lname">Last Name </label><span class="text-danger pl-2">*</span>
	                        <input class="form-control" type="text" id="lname" name="lname"
	                        value="<?php echo $edit_patient->plname; ?>">
	                        <span class="text-danger"><?php echo $Errlname; ?></span>
	                    </div>
	                </div>
	                 <div class="col-sm-4">
	                    <div class="form-group">
	                        <label>Date of Birth</label><span class="text-danger pl-2">*</span>
	                        <div class="cal-icon">
	                    <input type="text" class="form-control datetimepicker" name="dob"id="dob"
	                    value="<?php echo $edit_patient->pbirth_date; ?>" onchange="mydatepicker()" >
	                        </div>
	                        <span class="text-danger"><?php echo $Errbirthdate; ?></span>
	                    </div>
	                </div>
	                <div class="col-sm-4">
	                    <div class="form-group">
	                        <label for="age">Age</label>
	                        <input class="form-control" type="number" id="age" name="age" readonly=""
	                          value="<?php echo $edit_patient->age; ?>">
	                    </div>
	                </div>
	                <div class="col-sm-4">
	                    <div class="form-group">
	                     <label for="bloodgroup">Blood Group</label><span class="text-danger pl-2">*</span>
	        <select class="form-control" id="bloodgroup" name="bloodgroup">
	          <option value="">Plase Select</option>
	          <option value="A+" <?php if($edit_patient->bloodgroup == 'A+'){echo 'Selected'; } ?> >A+</option>
	          <option value="A-" <?php if($edit_patient->bloodgroup == 'A-'){echo 'Selected'; } ?>>A-</option>
	          <option value="B+" <?php if($edit_patient->bloodgroup == 'B+'){echo 'Selected'; } ?>>B+</option>
	          <option value="B_" <?php if($edit_patient->bloodgroup == 'B-'){echo 'Selected'; } ?>>B-</option>
	          <option value="AB+" <?php if($edit_patient->bloodgroup == 'AB+'){echo 'Selected'; } ?>>AB+</option>
	          <option value="AB-" <?php if($edit_patient->bloodgroup == 'AB-'){echo 'Selected'; } ?>>AB-</option>
	          <option value="O+" <?php if($edit_patient->bloodgroup == 'O+'){echo 'Selected'; } ?>>O+</option>
	          <option value="O-" <?php if($edit_patient->bloodgroup == 'O-'){echo 'Selected'; } ?>>O-</option>
	        </select>
	                        <span class="text-danger"><?php echo $Errbloodgroup; ?></span>
	                    </div>
	                </div>
	                <div class="col-sm-4">
	                    <div class="form-group gender-select">
	                        <label class="gen-label" for="gender">Gender: <span class="text-danger pl-2">*</span></label>
	                        <div class="form-check-inline">
	                            <label class="form-check-label">
	                          <input type="radio" name="gender" id="gender" class="form-check-input" value="male" 
	                          <?php if($edit_patient->gender == 'male'){echo 'checked';}  ?> >Male
	                            </label>
	                        </div>
	                        <div class="form-check-inline">
	                            <label class="form-check-label">
	                                <input type="radio" name="gender" id="gender" class="form-check-input"  value="female"
	                                <?php if($edit_patient->gender == 'female'){echo 'checked';}  ?>>Female
	                            </label>
	                            <span class="text-danger"><?php echo $Errgender; ?></span>
	                        </div>
	                    </div>
	                </div>
	                <div class="col-sm-4">
	                    <div class="form-group">
	                        <label for="religion">Religion</label><span class="text-danger pl-2">*</span>
	                        <input class="form-control" type="text" id="religion" name="religion" 
	                        value="<?php echo $edit_patient->religion; ?>">
	                        <span class="text-danger"><?php echo $Errreligion; ?></span>
	                    </div>
	                </div>
	                <div class="col-sm-4">
	                    <div class="form-group">
	                        <label for="postalcode">Postal Code</label><span class="text-danger pl-2">*</span>
	                    <input type="text" class="form-control" id="postalcode" name="postalcode" 
	                    value="<?php echo $edit_patient->postal_code; ?>">
	                        <span class="text-danger"><?php echo $Errpostalcode; ?></span>
	                    </div>
	                </div>
	                <div class="col-sm-12">
	                    <div class="form-group">
	                        <label for="address">Address</label><span class="text-danger pl-2">*</span>
	                        <textarea class="form-control" id="address" name="address" value=""
	                        rows="3"><?php echo $edit_patient->address; ?></textarea>
	                        <span class="text-danger"><?php echo $Erraddress; ?></span>
	                    </div>
	                </div>
	                <div class="col-sm-12">
	                    <div class="row">
	                        <div class="col-sm-12">
	                            <div class="form-group">
	                                <label for="mhistory">Medical History</label><span class="text-danger pl-2">*</span>
	                                <textarea class="form-control" id="mhistory" name="mhistory" 
	                                value="" rows="3"><?php echo $edit_patient->medical_history; ?></textarea>
	                    <span class="text-danger"><?php echo $Errmhistory; ?></span>
	                            </div>
	                        </div>
	                    </div>
	
	                </div>
	            </div>
        <div class="m-t-20 text-center">
            <input type="submit" name="edit" id="edit"  value="Edit Patient" class="btn btn-primary submit-btn mx-auto">
        </div>

        </form>
          </div>
        </div>
    </div>
  </div>
	<?php
  }
include 'views/footer.php'; ?>
<script>
$(document).ready(function() {
		        var today = new Date();
		        $('#dob').datepicker({
				            dateFormat: 'dd-mm-yy ',
				            autoclose:true,
				            changeMonth: true,
				            changeYear: true,
				            endDate: "today",
				            maxDate: today
				          }).on('changeDate', function (ev) {
				                $(this).datepicker('hide');
				      });
				            
		        $('#dob').keyup(function () {
		          if (this.value.match(/[^0-9]/g)) {
		            this.value = this.value.replace(/[^0-9^-]/g, '');
		            }
		          });  
		          $(document).on("click","button.deleterec",function(){
		          })
         })
     	   
 function mydatepicker(){
    	var selectdate = document.getElementById("dob").value;  
    	//setAge function assets/js/app.js
      var age = setAge(selectdate);
			  $('#age').val(age);
      }
</script>