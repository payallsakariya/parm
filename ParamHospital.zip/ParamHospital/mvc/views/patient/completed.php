<?php 

include 'views/header.php';
?>
 <input type="text"  id="types" name="types" size="2" readonly value="<?php echo $_SESSION['type'][0]; ?>" hidden>
<!--<body>-->
<!--    <div class="main-wrapper">-->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-8 col-6">
                        <h4 class="page-title">Completed Cases</h4>
                    </div>
                    
                    
                </div>
            
            <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table id="tbl_c" class="table table-border table-striped custom-table ">
                                <thead>
                                  <tr>
                                  	  <th class="text-right">Action</th>
                                        <th>#</th>
                                        <th>Case No</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Name</th>
                                        <th>Age</th>
                                        <th>Gender</th>
                                        <th>Phone</th>
                                   	<?php if($_SESSION['type'][0]== 'doctor'){ ?>
                                        <th>Charge</th>
                                        <!--<th>Medicine</th>-->
                                    <?php }else{ ?>
                                         <!--<th>Medicine</th>-->
                                        <th>Today's Fees</th>
                                        <th>pay</th>
                                          <?php } ?>
                                      
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php
include 'views/footer.php'; ?>

<!-- patients23:19-->

</html>
<script>
$(document).ready(function(){
	
		var	types = document.getElementById("types").value;  
	if(types == 'doctor'){
		var url1 = 'completed_cases_json';
		var columns1 =   [
				  {data: 'pid'},
	    		{data: 'caseid'},
	    		{data: 'pmshid'},
	    		{data: 'date'},
	    		{data: 'time'},
	    		{data: 'Name'},
	    		{data: 'age'},
	    		{data: 'gender'},
	    		{data: 'contact'},
	    		{data: 'charge'},
	    		// {data: 'medicine'},
	    		];
	   var casetypes =	"caseid";	
	   var btn ="Update";
		
	}else{
		
			var url1 = 'completed_cases_json';
	   	var columns1 =  [
	   			{data: ''},
	    		{data: 'caseid'},
	    		{data: 'pmshid'},
	    		{data: 'date'},
	    		{data: 'time'},
	    		{data: 'Name'},
	    		{data: 'age'},
	    		{data: 'gender'},
	    		{data: 'contact'},
	    		// {data: 'medicine'},
	    		{data: 'charge'},
	    		{data: 'payment'},
	    		];
	    	var casetypes =	"Payment_id";	
	    	
	    	var btn ="Payment";
	}
	
    	var t= $('#tbl_c').DataTable({
    		processing: true,
	    	serverSide : false,
	    	"ordering": false,
	    	ajax: {
	    		url: url1,
	    		type: 'POST',
	    	},
	    
	    	columnDefs: [
            {
                searchable: false,
                orderable: false,
                targets: 0,
            },
        ],
	    	columns: columns1,
	    		
	    		
	   columnDefs: [
	    	{
					"targets": 0,
					"data": "pid",
					"render": function ( data, type, row, meta ) {
						// console.log(row);
						
						if(row['status'] == "payment"){
					return "<td class='text-right'><a  href='DoctorEditPatient?case_id="+row['caseid']+"&"+casetypes+"="+row['caseid']+"'>"+btn+"</a></td>";
					   }else{
						return "<td class='text-right'><a  href='../admission/AdmitPatient?updeta_p_id="+row['pid']+"'>Admit</a></td>";
				   	}
				   	
					}
					}
					],
			});
			
	function selectpay(){
		 $.ajax({
	 	 	  		 type :'POST',
	 	 	  		 url :"payselect",
	 	 	  		 cache : false,
	 	 	  		 data : {'id':delet_id},
	 	 	  		 success: function(Code){
	 	 	  		 	// console.log(Code);
	 	 	  		 	 $(".deletecdata").attr('data-dismiss', 'modal');
	 	 	  		 	$('#chiefcomplains').DataTable().ajax.reload();
	 	 	  		 	// $("#del_chiefcomplains").modal("hide");
	 	 	  		  
	 	 	  		 } 
	 	 	  	})
}		
})
	  
</script>
				