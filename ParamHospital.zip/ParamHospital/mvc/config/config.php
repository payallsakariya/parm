<?php
$root = (!empty($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/';
$url = $root.'ParamHospital/mvc/';
define("base_url", $url);
?>