<?php

class patient_model {
	private $Connection;

	public function __construct() {
		$this->conectar = new Conectar();
		$this->Connection = $this->conectar->Connection();
	}

	function htmlValidation($form_data) {
		$form_data = trim(stripcslashes(htmlspecialchars($form_data)));
		$form_data = mysqli_real_escape_string($this->Connection, $form_data);
		return $form_data;
	}


	function selectmaxid($tbl,$id,$where) {
		$midsql = "SELECT Max($id) as lastid FROM  $tbl";
		if(isset($where)){
			$midsql.=" WHERE ".$where;
		}
		// echo $where;
		// echo $midsql;exit;
		$midsqlEx = $this->Connection->query($midsql);
		$midData = $midsqlEx->fetch_object();
		if ($midsqlEx->num_rows > 0) {
			$response['Data'] = $midData->lastid;
			$response['Code'] = true;
		} else {
			$response['Data'] = null;
			$response['Code'] = false;
		}
		return $response;
	}


	function InsertData($tbl, $data) {
		$response = array();
		// insert into tblName (clms) values (values);
		$clms = implode(',', array_keys($data));
		$vals = implode("','", $data);
		$sql = "insert into $tbl ($clms) values ('$vals')";
		$insertEx = $this->Connection->query($sql);
		if ($insertEx) {
			$response['Data'] = null;
			$response['Code'] = true;
			$response['Message'] = 'Data inserted successfully.';
		} else {
			$response['Data'] = null;
			$response['Code'] = false;
			$response['Message'] = 'Data insertion failed.';

		}
		return $response;
	}
	
	function Select_pending_cases($sql){
		// $type=$_SESSION['type'];
	
			$pcassqlEx = $this->Connection->query($sql);
					if($pcassqlEx->num_rows > 0){
								  while($FetchData = $pcassqlEx->fetch_object()){
								  	$allData[] = $FetchData;
								  }
		
					  	  $response['Code'] = true;
	            	$response['Message'] = 'Data retrivded successfully.';
	            	$response['Data'] = $allData;
	          }else {
	            	$response['Code'] = false;
	            	$response['Message'] = 'Data not retrivded .';
	            	$response['Data'] = [];
	           	
	          }
	       return $response;
	}
	function Select_completed_cases($sql){
			$pcassqlEx = $this->Connection->query($sql);
					if($pcassqlEx->num_rows > 0){
								  while($FetchData = $pcassqlEx->fetch_object()){
								  	$allData[] = $FetchData;
								  }
		
					  	  $response['Code'] = true;
	            	$response['Message'] = 'Data retrivded successfully.';
	            	$response['Data'] = $allData;
	          }else {
	            	$response['Code'] = false;
	            	$response['Message'] = 'Data not retrivded .';
	            	$response['Data'] = [];
	           	
	          }
	        // echo "<pre>";
	        //   print_r($response);
	        //   exit;
	       return $response;
	}
	
	function Select($option,$tbl,$where,$caseid,$pid){
	         $sql= " SELECT ".$option." FROM ".$tbl;
	        if($where){
	        	$sql .= " WHERE ".$where;
	        }
	        if($caseid){
	        	$sql .= " AND caseid=".$caseid;
	        }
	        if($pid){
	        	$sql .= " AND pid=".$pid;
	        }
	        // echo $sql;exit;
			$pcassqlEx = $this->Connection->query($sql);
					if($pcassqlEx->num_rows > 0){
								  while($FetchData = $pcassqlEx->fetch_object()){
								  	$allData[] = $FetchData;
								  }
		
					  	  $response['Code'] = true;
	            	$response['Message'] = 'Data retrivded successfully.';
	            	$response['Data'] = $allData;
	          }else {
	            	$response['Code'] = false;
	            	$response['Message'] = 'Data not retrivded .';
	            	$response['Data'] = [];
	           	
	          }
	       return $response;
	}
	
 function Delete($tbl,$where){
			  		$sql="DELETE FROM ".$tbl."  WHERE ";
			  		// DELETE FROM `employee` WHERE 0
									foreach ($where as $key => $value){
										$sql.="$key = $value";
									}
								$delsqlafter =rtrim($sql);
             return $deleteEx =$this->Connection->query($delsqlafter);
			  }
	
 function SelectAllData($tblname ,array $where = [],$filedarry="",$ORDERBY=""){
	
           $selSql= "SELECT * FROM $tblname";
           
        					if(!empty($filedarry)){
        						 $selSql= "SELECT $filedarry FROM $tblname ORDER BY $ORDERBY ";
        						 	$selSql = rtrim($selSql, $filedarry);
        					}
						    	if(!empty($where)){
										$selSql .= "  WHERE  ";
										foreach ($where as $key => $value){
										  	$selSql .= "$key = '$value' AND";
										}
										$selSql = rtrim($selSql, 'AND');
									}
									$sqlEX = $this->Connection->query($selSql);
									
									if($sqlEX->num_rows > 0){
										  while($FetchData = $sqlEX->fetch_object()){
										  	$allData[] = $FetchData;
										  	
										  }
					              	$response['Code'] = true;
					              	$response['Message'] = 'Data retrivded successfully.';
					              	$response['Data'] = $allData;
					              	// $response['Pageno'] =$total_pages;
				               	
				              }else {
						            	$response['Code'] = false;
						            	$response['Message'] = 'Data not retrivded .';
						            	$response['Data'] = [];
				               	
				              }
				           return $response;	
}	
 	 

 function UpdateData ($tbl,$data,$where,$and){
 	
					  		$sql="UPDATE $tbl SET ";
					  	
								foreach ($data as $key => $value){
									$sql.="$key = '$value',";
								}
								$sql =rtrim($sql,',');
								$sql .=" WHERE ";
								
								foreach ($where as $key => $value){
									$sql.="$key = '$value'AND";
								}
								$sql =rtrim($sql,'AND');
									if($and){
									$sql.= " AND ".$and;
								}
								// echo $sql;exit;
								$updEx =$this->Connection->query($sql);
									if ($updEx) {
											$response['Data'] = null;
											$response['Code'] = true;
											$response['Message'] = 'Data update successfully.';
										} else {
											$response['Data'] = null;
											$response['Code'] = false;
											$response['Message'] = 'Data update failed.';
								
										}
							return $response;
					  }	
 function Update_Sql ($sql){
								$updEx =$this->Connection->query($sql);
									if ($updEx) {
											$response['Data'] = null;
											$response['Code'] = true;
											$response['Message'] = 'Data update successfully.';
										} else {
											$response['Data'] = null;
											$response['Code'] = false;
											$response['Message'] = 'Data pudate failed.';
								
										}
							return $response;
					  }	
					  
function select_madicine($sql){
		$mdsqlEx = $this->Connection->query($sql);

					if($mdsqlEx->num_rows > 0){
								  while($FetchData = $mdsqlEx->fetch_object()){
								  	$selallData[] = $FetchData;
								  }
					  	  $response['Code'] = true;
	            	$response['Message'] = 'Data retrivded successfully.';
	            	$response['Data'] = $selallData;
	            	// $response['type'] = $type;
	          }else {
	            	$response['Code'] = false;
	            	$response['Message'] = 'Data not retrivded .';
	            	$response['Data'] = [];
	           	
	          }
	       return $response;
}			

function select_madicine_update($sql){
		$mdsqlEx = $this->Connection->query($sql);

					if($mdsqlEx->num_rows > 0){
								  while($FetchData = $mdsqlEx->fetch_object()){
								  	$selallData[] = $FetchData;
								  }
					  	  $response['Code'] = true;
	            	$response['Message'] = 'Data retrivded successfully.';
	            	$response['Data'] = $selallData;
	            	// $response['type'] = $type;
	          }else {
	            	$response['Code'] = false;
	            	$response['Message'] = 'Data not retrivded .';
	            	$response['Data'] = [];
	           	
	          }
	          // echo "<pre>";
	          // print_r($response);
	          // exit;
	       return $response;
}	
					  
}




?>