<?php

class report_model
{
	public $table = "users";
	private $Connection;


	function __construct() {
		$this->conectar = new Conectar();
		$this->Connection = $this->conectar->Connection();
	}
	function Select($sql) {
		// echo $sql;exit;
		$pcassqlEx = $this->Connection->query($sql);
					if($pcassqlEx->num_rows > 0){
								  while($FetchData = $pcassqlEx->fetch_object()){
								  	$allData[] = $FetchData;
								  }
	
					  	  $response['Code'] = true;
	            	$response['Message'] = 'Data retrivded successfully.';
	            	$response['Data'] = $allData;
	          }else {
	            	$response['Code'] = false;
	            	$response['Message'] = 'Data not retrivded .';
	            	$response['Data'] = [];
	           	
	          }
	          // print_r($response);
		return $response;
	}


}
?>