<?php

class index_model
{
	public $table = "users";
	private $Connection;
	private $id;
	private $Name;
	private $Surname;
	private $email;
	private $phone;

	function __construct() {
		$this->conectar = new Conectar();
		$this->Connection = $this->conectar->Connection();
	}
	
		function selectmaxid($tbl,$id,$fun,$weher) {
		$midsql = "SELECT $fun($id) as lastid FROM  $tbl";
		if(!empty($weher)){
			$midsql.="  WHERE  ".$weher;
			// echo $midsql;
		}
		$midsqlEx = $this->Connection->query($midsql);
		$midData = $midsqlEx->fetch_object();
		if ($midsqlEx->num_rows > 0) {
			$response['Data'] = $midData->lastid;
			$response['Code'] = true;
		} else {
			$response['Data'] = null;
			$response['Code'] = false;
		}
		return $response;
	}
	
	function Select_pending_cases($sql){
		$pcassqlEx = $this->Connection->query($sql);

				if($pcassqlEx->num_rows > 0){
							  while($FetchData = $pcassqlEx->fetch_object()){
							  	$allData[] = $FetchData;
							  }
				  	  $response['Code'] = true;
            	$response['Message'] = 'Data retrivded successfully.';
            	$response['Data'] = $allData;
          }else {
            	$response['Code'] = false;
            	$response['Message'] = 'Data not retrivded .';
            	$response['Data'] = [];
           	
          }
       return $response;
	}
}
?>