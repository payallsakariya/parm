<?php
class index {
	 private $conectar;
   private $Connection;
   public $table = "patients";
   public $table1 = "practices";
   private $base_url;
	function __construct() {
		   
    require_once  __DIR__ . "/../core/Conectar.php";
    require_once  __DIR__ . "/../model/index_model.php";
    
    $this->conectar=new Conectar();
    $this->model=new index_model();
    $this->base_url = base_url;
    $this->Connection=$this->conectar->Connection();
    
	}
	
	function index() {
			include 'views/index/index.php';
		
	}
	function Total_Patient(){
		$mselEx= $this->model->selectmaxid($this->table,'pid','Max','');
		// print_r($mselEx);
		echo json_encode($mselEx);
	
	}
	function Total_pending_cases(){
		$weher = "DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE()";
		$mselEx= $this->model->selectmaxid($this->table1,'id','COUNT',$weher);
		// print_r($mselEx);
		echo json_encode($mselEx);
	
	}	
	function pending_cases_json(){
	
	  $sql="SELECT patients.pid,patients.pmshid,patients.contact,upper(concat (patients.pfname,' ',patients.pmname,' ',patients.plname)) as Name,patients.age,patients.gender,DATE_FORMAT(practices.date,'%Y-%m-%d')as date, DATE_FORMAT(practices.date,'%l:%i-%p ')as time FROM ".$this->table." INNER JOIN ".$this->table1." ON patients.pid = practices.pid WHERE DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE() ORDER BY practices.date DESC LIMIT 5";
	  
 	 $pcasesEx= $this->model->Select_pending_cases($sql);
 	 $data['data'] = $pcasesEx['Data'];
 	 $array = json_decode(json_encode($data), true);
 	 echo json_encode($array);
}
	
	
	
}
	?>
