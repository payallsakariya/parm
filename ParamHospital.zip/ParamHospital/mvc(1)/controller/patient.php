<?php
date_default_timezone_set('Asa/Kolkata');
session_start();
class patient {
     public $table = "patients";
     public $table1 = "practices";
     public $table2 = "prescriptions";
		 private $conectar;
     private $Connection;
     private $base_url;
		
							    function __construct() {
							        require_once  __DIR__ . "/../core/Conectar.php";
                      require_once  __DIR__ . "/../model/patient_model.php";
                      $this->conectar=new Conectar();
									    $this->model=new patient_model();
									    $this->base_url = base_url;
									    $this->Connection=$this->conectar->Connection();
						       }
						       
  //add patint data
function patient(){
		
	  	  if(isset($_POST['Submit'])){
	  	  	$type = $_SESSION['type'][0];
	  	        //pmshid makeing code
		  	       $mselEx= $this->model->selectmaxid($this->table,'pid',$where);
		              if($mselEx['Code'] == 1){
		                $lastid =	$row = $mselEx['Data'];
	                  $lastid=$lastid+1;
										$lastid = str_pad($lastid,5, '0', STR_PAD_LEFT);
										$currentyear=  date("y");
										$pmshid='PMSH'.$currentyear.$lastid;
		              }else{
		                $lastid=1;
										$lastid = str_pad($lastid,5, '0', STR_PAD_LEFT);
										$currentyear=  date("y");
										$pmshid='PMSH'.$currentyear.$lastid;
		              }
	  	  	
					//date format change DD/MM/YYYY To YYYY/MM/DD
								$orgDate = $_POST['dob'];
								$date = str_replace('-"', '/', $orgDate);
								$newDate = date("Y/m/d", strtotime($date));
					//makeing current date time
		          $t=time();
							$timetamp=date("Y-m-d h:i:sa",$t);			
								

          //creat array for insert data in database
			  			$insert_data = [
			                'pmshid' => $pmshid,
			                'contact' => $_POST['phone'],
			                'pfname' => $_POST['fname'],
			                'pmname' => $_POST['mname'],
			                'plname' => $_POST['lname'],
			                'age' => $_POST['age'],
			                'bloodgroup' => $_POST['bloodgroup'],
			                'pbirth_date ' => $newDate,
			                'gender	' => $_POST['gender'],
			                'religion	' => $_POST['religion'],
			                'postal_code' => $_POST['postalcode'],
			                'address	' => $_POST['address'],
			                'medical_history	' => $_POST['mhistory'],
			                'date	' => $timetamp
			              ];
	              // InsertData function call
						  	 $insertEx= $this->model->InsertData($this->table,$insert_data);
							     if($insertEx['Code'] == 1){
							     	  $url = $this->base_url.'index/index?type='.$type;
							 		  	header("Location: $url");
							     }else{
							     	  $url = $this->base_url.'patient/patient';
							 			header("Location: $url");
							     }
	  	}
include 'views/patient/patient.php';		
 }

function edit_patient(){
				$pid = $_GET['p_id'];
				$type= $_SESSION['type'][0];

  if($type == 'staff'){
	    $Alldata = $this->model->SelectAllData($this->table,['pid'=>$this->model->htmlValidation($pid)]);
 }
     
	    // Convert stdClass object to array in PHP [duplicate]
        $_SESSION['EditPatient'] = $Alldata['Data'][0];
       if(isset($_POST['edit'])){
      
					//date format change DD/MM/YYYY To YYYY/MM/DD
								$orgDate = $_POST['dob'];
								$date = str_replace('-"', '/', $orgDate);
								$newDate = date("Y/m/d", strtotime($date));

          //UPdate array for pudate data in database
			  			$update_data = [
			                'pmshid' => mysqli_real_escape_string($this->Connection,$_POST['pmhid']),
			                'contact' => mysqli_real_escape_string($this->Connection,$_POST['phone']),
			                'pfname' => mysqli_real_escape_string($this->Connection,$_POST['fname']),
			                'pmname' => mysqli_real_escape_string($this->Connection,$_POST['mname']),
			                'plname' => mysqli_real_escape_string($this->Connection,$_POST['lname']),
			                'age' => mysqli_real_escape_string($this->Connection,$_POST['age']),
			                'bloodgroup' => mysqli_real_escape_string($this->Connection,$_POST['bloodgroup']),
			                'pbirth_date ' => mysqli_real_escape_string($this->Connection,$newDate),
			                'gender	' => mysqli_real_escape_string($this->Connection,$_POST['gender']),
			                'religion	' => mysqli_real_escape_string($this->Connection,$_POST['religion']),
			                'postal_code' => mysqli_real_escape_string($this->Connection,$_POST['postalcode']),
			                'address	' => mysqli_real_escape_string($this->Connection,$_POST['address']),
			                'medical_history	' => mysqli_real_escape_string($this->Connection,$_POST['mhistory'])
			              ];
	         // Update function call
				$upd_data = $this->model->UpdateData($this->table,$update_data,['pid'=>$this->model->htmlValidation($pid)],$and);
						  	 	
				  //redirect page
				     if($upd_data['Code'] == 1){
					     	  unset($_SESSION['EditPatient']);
					     	  $url = $this->base_url.'patient/pending_cases';
					 		  	header("Location: $url");
				     }else{
					     	  $url = $this->base_url.'patient/edit_patient';
					 			  header("Location: $url");
				     }
	  	}
	  	
	 	
	include 'views/patient/patient.php';		
} 
   
function pending_cases(){
		include 'views/patient/pending_cases.php';
   }
   
   
function pending_cases_json(){
	$type =$_SESSION['type'];
	  $sql="SELECT patients.pid,patients.pmshid,patients.contact,upper(concat (patients.pfname,' ',patients.pmname,' ',patients.plname)) as Name,patients.age,patients.gender,patients.paypending,DATE_FORMAT(practices.date,'%d-%m-%Y')as date, DATE_FORMAT(practices.date,'%l:%i-%p ')as time,practices.caseid,practices.payment FROM ".$this->table." INNER JOIN ".$this->table1." ON patients.pid = practices.pid WHERE DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE() and practices.charge is NULL and practices.status = 'consult' ORDER BY practices.date DESC";
 	 $pcasesEx= $this->model->Select_pending_cases($sql);
 	 $data['data'] = $pcasesEx['Data'];
 	 $array = json_decode(json_encode($data), true);
 	 echo json_encode($array);
}



function DoctorEditPatient(){
	if($_GET['casetype'] == 'complet'){
		// $sqltype="SELECT practices.pid,practices.charge,practices.disease,practices.medicine FROM `practices` WHERE pid =8 AND DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE()";
		$option="practices.pid,practices.charge,practices.disease,practices.medicine";
		$pid=$_GET['p_id'];
		$where="DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE()";
		$sqltypeEx = $this->model->Select($option,$this->table1,$where,$pid);
		 $_SESSION['Edit_Charge']=$sqltypeEx['Data'][0];
		 //print_r($_SESSION['Edit_Charge']);exit;
	}
	
	if(isset($_POST['up_date'])){
		$pid=$_GET['p_id'];
	
		$updatedata = [
						         'charge' => mysqli_real_escape_string($this->Connection,$_POST['charge']),
		                'disease' => mysqli_real_escape_string($this->Connection,$_POST['disease']),
		                'medicine' => mysqli_real_escape_string($this->Connection,$_POST['medicine']),
		                'status' => mysqli_real_escape_string($this->Connection,'payment')
						      ];
						              
	      // Update function call
		        $upddata = $this->model->UpdateData($this->table1,$updatedata,['pid'=>$this->model->htmlValidation($pid)],$and);
		 
					   if($upddata['Code'] == 1){
												     	  	unset($_SESSION['Edit_Charge']);
												     	  $url = $this->base_url.'patient/completed';
												 		  	header("Location: $url");
												 		  
										     }else{
												     	  $url = $this->base_url.'patient/DoctorEditPatient?p_id='.$pid."&casetype=complet";
												 		   	header("Location: $url");
										     }
					
				}
	
						if($_GET['casetype'] == 'payments'){
							$pid=$_GET['p_id'];
							$sqlpay="SELECT practices.pid,practices.charge,practices.disease,practices.medicine,patients.paypending,SUM(patients.paypending + practices.charge) as total,practices.payment FROM patients INNER JOIN practices ON patients.pid = practices.pid WHERE practices.pid = $pid AND DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE()";
							// echo $sqlpay;exit;
							$sqltypeEx = $this->model->Select_completed_cases($sqlpay);
							
							 $_SESSION['pay_inof']=$sqltypeEx['Data'][0];
							
						}
	
	
					if(isset($_POST['pay_ments'])){
							$pid = $_GET['p_id'];
						$total=$_SESSION['pay_inof']->total;
						$paying = $_POST['pay'];
						$pay_panding = $total - $paying;
						
					$sql="UPDATE patients INNER JOIN practices ON patients.pid =practices.pid SET patients.paypending = $pay_panding, practices.payment = $paying WHERE patients.pid = $pid AND DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE()";
					$sqlEx = $this->model->Update_Sql($sql);
					
					if($sqlEx['Code'] == 1){
													     	  	unset($_SESSION['pay_inof']);
													     	  $url = $this->base_url.'patient/completed';
													 		  	header("Location: $url");
													 		  
											     }else{
													     	  $url = $this->base_url.'patient/DoctorEditPatient?p_id='.$pid."&casetype=payments";
													 		   	header("Location: $url");
											     }
						
					}
	
	
				$pid = $_GET['p_id'];
				$type= $_SESSION['type'][0];
				  	$sql="SELECT patients.pid,patients.pmshid,patients.contact,upper(concat (patients.pfname,' ',patients.pmname,' ',patients.plname)) as Name,patients.age,patients.gender,DATE_FORMAT(practices.date,'%Y-%m-%d')as date, DATE_FORMAT(practices.date,'%l:%i-%p ')as time,practices.caseid FROM patients INNER JOIN practices ON patients.pid = practices.pid WHERE DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE() && practices.pid=".$pid;
     	
    		 $Alldata = $this->model->Select_pending_cases($sql);
    		 $_SESSION['DEditpatient']=$Alldata['Data'][0];
    		 
    		 	  if(isset($_POST['m_add'])){
	  	  	$pid=$_GET['p_id'];
	  	  	 $morning=$_POST['Morning'].','.$_POST['breakfast'];
	  	  	 $afternoon=$_POST['Afternoon'].','.$_POST['lunch'];
	  	  	 $night=$_POST['Night'].','.$_POST['dinner'];
	  	  	 $t=time();
					 $timetamp=date("Y-m-d",$t);
	  	  	 
	  	  	 	$insert_data = [
			                'pid' => $pid,
			                'medicine' => $_POST['med_name'],
			                'description' => $_POST['description'],
			                'morning' => $morning,
			                'afternoon' => $afternoon,
			                'night' => $night,
			                'Date' => $timetamp
			              ];
			              $insertEx= $this->model->InsertData('prescriptions',$insert_data);
			               if($insertEx['Code'] == 1){
									     	  $url = $this->base_url.'patient/DoctorEditPatient?p_id='.$pid;
									 		  	header("Location: $url");
							     }else{
									     	  $url = $this->base_url.'patient/patient?p_id='.$pid;
									 		   	header("Location: $url");
							     }
	  	  }
	  	  
	  	  if(!empty($_GET['m_id'])){
			  	  	$mid=$_GET['m_id'];
			  	  	$sql="SELECT * FROM `prescriptions` WHERE id =$mid";
			  	  	
			  	  	$selEx= $this->model->select_madicine_update($sql);
			  	  	 $_SESSION['Editmadicine'] = $selEx['Data'][0];
	  	  }
	  	  
	  	 if(isset($_POST['m_update'])){
	  	 	// echo "m_update";exit;
				  	 	$mid=$_POST['mid'];
				  	 	$Morning = $_POST['Morning'].','.$_POST['breakfast'];
				  	  $Afternoon = $_POST['Afternoon'].','.$_POST['lunch'];
				  	 	$Night = $_POST['Night'].','.$_POST['dinner'];
				  	 			$update_m_data = [
						                'medicine' => mysqli_real_escape_string($this->Connection,$_POST['med_name']),
						                'morning' => mysqli_real_escape_string($this->Connection,$Morning),
						                'afternoon' => mysqli_real_escape_string($this->Connection,$Afternoon),
						                'night' => mysqli_real_escape_string($this->Connection,$Night),
						                'description' => mysqli_real_escape_string($this->Connection,$_POST['description'])
						              ];
						              
	         // Update function call
						 $upd_m_data = $this->model->UpdateData('prescriptions',$update_m_data,['id'=>$this->model->htmlValidation($mid)],$and);
				  //redirect page
				     if($upd_m_data['Code'] == 1){
						     	  unset($_SESSION['Editmadicine']);
						     	  print_r($_SESSION['Editmadicine']);
						     	  $url = $this->base_url.'patient/DoctorEditPatient?p_id='.$pid;
						 		  	header("Location: $url");
				     }else{
						     	  $url = $this->base_url.'patient/DoctorEditPatient?p_id='.$pid;
						 			  header("Location: $url");
				     }
	  	 } 
	  	 
	  	 
	  	 if(isset($_POST['D_Edit'])){
	  	 	$pid=$_GET['p_id'];
	  	 	$D_udate=[
	  	 		          'charge' => mysqli_real_escape_string($this->Connection,$_POST['charge']),
		                'disease' => mysqli_real_escape_string($this->Connection,$_POST['disease']),
		                'medicine' => mysqli_real_escape_string($this->Connection,$_POST['medicine']),
		                'status' => mysqli_real_escape_string($this->Connection,'payment')
		              ];
		              // print_r($D_udate);
		              $and="date_format(date,'%d-%m-%Y')=date_format(now(),'%d-%m-%Y')";
	         // Update function call
						$upd_D_data = $this->model->UpdateData($this->table1,$D_udate,['pid'=>$this->model->htmlValidation($pid)],$and);
				  //redirect page
				    if($upd_D_data['Code'] == 1){
						    	  unset($_SESSION['DEditpatient']);
						    	  $url = $this->base_url.'patient/pending_cases';
								  	header("Location: $url");
				    }else{
						    	  $url = $this->base_url.'patient/DoctorEditPatient?p_id='.$pid;
									  header("Location: $url");
				    }
	  	 }
				
	include 'views/patient/madicine.php';
}
function delete_patient(){
	
	$deleteEx= $this->model->Delete($this->table1,['pid'=>$this->model->htmlValidation($_GET['pid'])]);
	
			if($deleteEx == 1){
				?>
					        <script type="text/javascript">
					        	 //alert("Data delete ssuccessfully.");
					        	 window.location.href = 'pending_cases';
					        </script>
				<?php
				}else{
				?>
				       	<script type="text/javascript">
					        	 alert("'Somthing went!,please try again later'.");
					        	 window.location.href = 'pending_cases';
					        </script>
					<?php
				}

}
function patient_pending_cases(){
	$value = $_POST['q'];
		$sql="SELECT upper(concat(v.pfname,' ',v.pmname,' ',v.plname)) as Name,v.`pid` , v.pmshid FROM ". $this->table."  v WHERE concat(v.pfname,' ',v.pmname,' ',v.plname, '') LIKE '$value%' or v.contact like '%$value%'or pmshid like '%$value%' ORDER BY v.pfname";
		
  	 $selectEx= $this->model->Select_pending_cases($sql);
	 	 $data['data'] = $selectEx['Data'];
 	   $array = json_decode(json_encode($data), true);
 	  echo json_encode($array);
} 
//insert Data in practices table (cll selct2 ajex pending_cases.php file)
function add_pending_cases(){
    	$id = $_GET['pid'];
         if(!empty($id)){
         	$sqlsle="SELECT patients.age,patients.pmshid FROM `patients` WHERE  pid=$id";
         	$sqlsleEx= $this->model->select_madicine($sqlsle);
         	$array=$sqlsleEx['Data'];

         	//Age calculet Update age in patients table
         	  $oldage=$array[0]->age;
         	  $pmssid=substr($array[0]->pmshid,4,2);
         	 	$curr=date('Y-m-d');
            $old=$pmssid."-00-00";
         	  $diff = abs(strtotime($curr) - strtotime($old));
						$years = floor($diff / (365*60*60*24));
						$newage=$oldage+$years;
						$udatearr=[
						          'age' => mysqli_real_escape_string($this->Connection,$newage)
						          ];
						$upd_age = $this->model->UpdateData($this->table,$udatearr,['pid'=>$this->model->htmlValidation($id)],$and);
				 if($upd_age['Code'] == 1){
         	// selectmaxid of caseid
         	     $where="DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE()";
	            $mselEx= $this->model->selectmaxid($this->table1,'caseid',$where);

		              if($mselEx['Code'] == 1){
		                $caseid =	$row = $mselEx['Data'];
	                  $caseid=$caseid+1;
		              }else{
		                $caseid=1;
		              }
          //makeing current date time
		          $t=time();
							$timetamp=date("Y-m-d h:i:sa",$t);
					//InsertData array
			  			$insert_data = [
			                'pid' => $id,
			                'caseid' =>$caseid,
			                'date' => $timetamp
			              ];
        
         // InsertData function call
			  	 $insertEx= $this->model->InsertData($this->table1,$insert_data);
			  	 
				     if($insertEx['Code'] == 1){
				     	  $url = $this->base_url.'patient/pending_cases';
				 		  	header("Location: $url");
				     }else{
				     	  $url = $this->base_url.'patient/pending_cases';
				 			header("Location: $url");
				     }
         }
         }
      }
      
function madicine_prescriptions_add(){
	$pid =$_GET['pid'];
	 $sql="SELECT prescriptions.id,prescriptions.medicine,prescriptions.morning,prescriptions.afternoon,prescriptions.night,prescriptions.Date,prescriptions.description FROM prescriptions WHERE pid = $pid AND DATE_FORMAT(prescriptions.date,'%Y-%m-%d') = CURDATE()";
 	 $madicineEx= $this->model->select_madicine($sql);
 	 $data['data'] = $madicineEx['Data'];
 	 $m_array = json_decode(json_encode($data), true);
 	 echo json_encode($m_array);

}   

function delete_madicine(){
	$deleteEx= $this->model->Delete($this->table2,['id'=>$this->model->htmlValidation($_GET['del_m_id'])]);
			$pid=$_GET['p_id'];
			if($deleteEx == 1){
					      $url = $this->base_url.'patient/DoctorEditPatient?p_id='.$pid;
				 			  header("Location: $url");
				}else{
			          $url = $this->base_url.'patient/DoctorEditPatient?p_id='.$pid;
				 			  header("Location: $url");
				}
}
   
function AdmitPatient(){
	
	$pid = $_GET['p_id'];
	// echo "pay";exit;
		include 'views/patient/consultform.php';
} 


function completed(){

	include 'views/patient/completed.php';	
}
function completed_cases_json(){
	$type =$_SESSION['type'];
	  $sql="SELECT practices.pid,patients.pmshid,patients.contact,upper(concat (patients.pfname,' ',patients.pmname,' ',patients.plname)) as Name,patients.age,patients.gender,patients.paypending,DATE_FORMAT(practices.date,'%d-%m-%Y')as date, DATE_FORMAT(practices.date,'%l:%i-%p ')as time,practices.caseid,practices.charge,practices.medicine,practices.status,patients.pid,practices.payment FROM ".$this->table1." INNER JOIN ".$this->table." ON practices.pid = patients.pid WHERE DATE_FORMAT(practices.date,'%Y-%m-%d') = CURDATE() and (practices.status = 'admit' or  practices.status = 'payment') order by practices.caseid desc";
	  
 	 $pcasesEx= $this->model->Select_completed_cases($sql);
 	 $data['data'] = $pcasesEx['Data'];
 	 $array = json_decode(json_encode($data), true);
 	 echo json_encode($array);
}
  
}

?>
