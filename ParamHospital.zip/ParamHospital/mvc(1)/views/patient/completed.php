<?php 

include 'views/header.php';
?>
 <input type="text"  id="types" name="types" size="2" readonly value="<?php echo $_SESSION['type'][0]; ?>" hidden>
<!--<body>-->
<!--    <div class="main-wrapper">-->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-8 col-6">
                        <h4 class="page-title">Completed Patients</h4>
                    </div>
                    
                    
                </div>
            
            <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table id="tbl_c" class="table table-border table-striped custom-table ">
                                <thead>
                                  <tr>
                                        <th>#</th>
                                        <th>Case No</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Name</th>
                                        <th>Age</th>
                                        <th>Gender</th>
                                        <th>Phone</th>
                                   	<?php if($_SESSION['type'][0]== 'doctor'){ ?>
                                        <th>Charge</th>
                                        <th>Medicine</th>
                                    <?php }else{ ?>
                                         <th>Medicine</th>
                                        <th>Today's Fees</th>
                                        <th>payment</th>
                                          <?php } ?>
                                        <th class="text-right">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--<div id="delete_patient" class="modal fade delete-modal" role="dialog">-->
        <!--    <div class="modal-dialog modal-dialog-centered">-->
        <!--        <div class="modal-content">-->
        <!--            <div class="modal-body text-center">-->
        <!--                <img src="../assets/img/sent.png" alt="" width="50" height="46">-->
        <!--                <h3>Are you sure want to delete this Patient?</h3>-->
        <!--                <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>-->
        <!--                    <button type="submit" class="btn btn-danger">Delete</button>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>-->

        <!--</div>-->
<!--    </div>-->
<!--</body>-->
<?php
include 'views/footer.php'; ?>

<!-- patients23:19-->

</html>
<script>
$(document).ready(function(){
		var	types = document.getElementById("types").value;  
	if(types == 'doctor'){
		var url1 = 'completed_cases_json';
		var columns1 =   [
	    		{data: 'caseid'},
	    		{data: 'pmshid'},
	    		{data: 'date'},
	    		{data: 'time'},
	    		{data: 'Name'},
	    		{data: 'age'},
	    		{data: 'gender'},
	    		{data: 'contact'},
	    		{data: 'charge'},
	    		{data: 'medicine'},
	    		{data: 'pid'},
	    		];
	   var casetypes =	"complet";
	   var btn ='Update';
		
	}else{
			var url1 = 'completed_cases_json';
	   	var columns1 =  [
	    		{data: 'caseid'},
	    		{data: 'pmshid'},
	    		{data: 'date'},
	    		{data: 'time'},
	    		{data: 'Name'},
	    		{data: 'age'},
	    		{data: 'gender'},
	    		{data: 'contact'},
	    		{data: 'medicine'},
	    		{data: 'charge'},
	    		{data: 'payment'},
	    		{data: ''},
	    		];
	    	var casetypes =	"payments";	
	    	 var btn ='Pay';
	}
	
    	var t= $('#tbl_c').DataTable({
    		processing: true,
	    	serverSide : false,
	    	ajax: {
	    		url: url1,
	    		type: 'POST',
	    	},
	    
	    	columnDefs: [
            {
                searchable: false,
                orderable: false,
                targets: 0,
            },
        ],
	    	columns: columns1,
	    		
	    		
	   columnDefs: [
	    	{
					"targets": -1,
					"data": "pid",
					"render": function ( data, type, row, meta ) {
						console.log(row);
						
						if(row['status'] == "payment"){
					return "<td class='text-right'><a class='dropdown-item' href='DoctorEditPatient?p_id="+row['pid']+"&casetype="+casetypes+"'>"+btn+"</a></td>";
					   }else{
						return "<td class='text-right'><a class='dropdown-item' href='DoctorEditPatient?p_id="+data+"'>Admit</a></td>";
				   	}
				   	
					}
					}
					],
			});
})
	  
</script>
				