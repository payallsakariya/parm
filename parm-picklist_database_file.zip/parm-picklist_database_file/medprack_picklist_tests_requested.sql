-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 28, 2023 at 05:55 PM
-- Server version: 8.0.27-18
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medprack`
--

-- --------------------------------------------------------

--
-- Table structure for table `medprack_picklist_tests_requested`
--

CREATE TABLE `medprack_picklist_tests_requested` (
  `id` int NOT NULL,
  `tests_requested_name` varchar(30) NOT NULL,
  `status` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `medprack_picklist_tests_requested`
--

INSERT INTO `medprack_picklist_tests_requested` (`id`, `tests_requested_name`, `status`) VALUES
(1, 'CBC PS FOR MP', 'active'),
(2, 'CRP', 'active'),
(3, 'SGPT', 'active'),
(4, 'U-R-M', 'active'),
(5, 'sos', 'active'),
(6, 'CBC', ''),
(7, 'FBS PPBS AND HBALC', ''),
(8, 'S.CREAT. RBS', ''),
(9, 'SERUM WIDAL', ''),
(10, 'LIPID PROFILE', ''),
(11, 'NS 1 ANTIGEN', ''),
(12, 'DANGUE NS1', ''),
(13, 'SOS', ''),
(14, 'HBA1C', ''),
(15, 'USG WHOLE ABDOMEN', ''),
(16, 'ESR', ''),
(17, 'VITSMIN -B 12', ''),
(18, '2DECHO', ''),
(19, 'POTASSIUM', ''),
(20, 'S.TSH', ''),
(21, 'ANTNATAL', ''),
(22, 'CHICKENGUNIYA PCR', ''),
(23, 'ECG', ''),
(24, 'PRE OP FITNESS', ''),
(25, 'RTPCR COVID -19', ''),
(26, 'SODIUM', ''),
(27, '2D ECHO', ''),
(28, 'CBC REPEAT', ''),
(29, 'COVID-PROFILE', ''),
(30, 'CRP D-DIMER', ''),
(31, 'FBS', ''),
(32, 'HRCT THORAX', ''),
(33, 'KUB', ''),
(34, 'MR FISTULOGRAM', ''),
(35, 'NECK X-RAY', ''),
(36, 'PARAM-C AND VIT-D3', ''),
(37, 'PFT', ''),
(38, 'PPBS', ''),
(39, 'SGPR', ''),
(40, 'SUGAR AFTER FOOD', ''),
(41, 'TSH', ''),
(42, 'URINE ROUTINE MICRO', ''),
(43, 'USG KUB', ''),
(44, 'VITAMIN-D3', ''),
(45, 'X-RAY CHEST CBC ESR PS FOR MP ', ''),
(46, 'AFTER 5 DAYS', ''),
(47, 'AND PRE OPERATIVE MAJOR', ''),
(48, 'B12 210', ''),
(49, 'BLOOD UREA', ''),
(50, 'CBC .S.CREAT. SG[T. CRP. U-RR-', ''),
(51, 'CBC CRP SOS AND DO RTPCR', ''),
(52, 'CBC SGPT', ''),
(53, 'CT SCAB WHOLE ABDOMEN', ''),
(54, 'D-DIMER', ''),
(55, 'INR', ''),
(56, 'MRI L-S SPINE', ''),
(57, 'PRE-OP MAJOR', ''),
(58, 'S.CREAT.', ''),
(59, 'S. CREAT. TSH', ''),
(60, 'SERUM PSA', ''),
(61, 'SUGAR FASTING', ''),
(62, 'THYROID PROFILE', ''),
(63, 'URINE CULTIRE AND SENSTIVITY', ''),
(64, 'USG BREAT', ''),
(65, 'USG PELVIS', ''),
(66, 'X-RAY CHEST AND S.CREAT', ''),
(67, 'BLOOD COUNT', ''),
(68, 'COMPLETE FOOT EXAMINATION', ''),
(69, 'FUNDUS CAMERA', ''),
(70, 'LFT', ''),
(71, 'LIVER FITNESS TEST', ''),
(72, 'RETINAL EXAMINATION', ''),
(73, 'SUGAR RANDOM', ''),
(74, 'T3', ''),
(75, 'T4', ''),
(76, 'THYROID TECHNETIUM SCAN - TC S', ''),
(77, 'TOTAL BLOOD COUNT', ''),
(78, 'TREAD MILL TEST', ''),
(79, 'EGFR', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `medprack_picklist_tests_requested`
--
ALTER TABLE `medprack_picklist_tests_requested`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `medprack_picklist_tests_requested`
--
ALTER TABLE `medprack_picklist_tests_requested`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
