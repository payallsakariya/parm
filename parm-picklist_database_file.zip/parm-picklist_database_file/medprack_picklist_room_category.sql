-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 28, 2023 at 05:55 PM
-- Server version: 8.0.27-18
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medprack`
--

-- --------------------------------------------------------

--
-- Table structure for table `medprack_picklist_room_category`
--

CREATE TABLE `medprack_picklist_room_category` (
  `id` int NOT NULL,
  `category` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `bed_no` varchar(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(10) NOT NULL DEFAULT 'active '
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `medprack_picklist_room_category`
--

INSERT INTO `medprack_picklist_room_category` (`id`, `category`, `bed_no`, `date`, `status`) VALUES
(1, 'Casulty', '101', '2023-10-05 09:58:47', 'active '),
(2, 'Casulty', '102', '2023-10-05 09:58:47', 'active '),
(3, 'semi-Special ', '203', '2023-10-05 09:59:20', 'active '),
(4, 'semi-Special ', '204', '2023-10-05 09:59:20', 'active '),
(5, 'Delux Room ', '105', '2023-10-05 10:00:10', 'active '),
(6, 'Super Delux Room ', '205', '2023-10-05 10:00:10', 'active '),
(7, 'Special Room', '207', '2023-10-05 10:01:00', 'active '),
(8, 'General Ward', '101', '2023-10-05 10:01:00', 'active '),
(9, 'General Ward', '102', '2023-10-05 10:01:27', 'active '),
(10, 'General Ward', '103', '2023-10-05 10:01:27', 'active '),
(11, 'General Ward', '104', '2023-10-05 10:01:53', 'active '),
(12, 'General Ward', '201', '2023-10-05 10:01:53', 'active '),
(13, 'General Ward', '202', '2023-10-05 10:02:18', 'active '),
(14, 'General Ward', '206', '2023-10-05 10:02:18', 'active ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `medprack_picklist_room_category`
--
ALTER TABLE `medprack_picklist_room_category`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `medprack_picklist_room_category`
--
ALTER TABLE `medprack_picklist_room_category`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
