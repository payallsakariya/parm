
<?php echo e($emailData['body']); ?><?php /**PATH /home/excellcons-paramlv/htdocs/paramlv.excellcons.com/resources/views/text.blade.php ENDPATH**/ ?>