
<html>

<?php echo $__env->make('css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-wrapper account-wrapper">
        <div class="account-page">
			<div class="account-center ">
				<div class="account-box" style="width:40%; vertical-align:top; height:30%; ">
                  <form method="get" class="form-signin" action="<?php echo e(route('view_multiple_cities')); ?>">
                  <div class="account-logo">
                            <h2 class="card-titel text-center">Has One Through Reletionship</h2>
                        </div>	
                        <div class="form-group">
                            <label for="country">Counties:</label>
                            <select class= "form-control" name= "country" id="country">
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value = "<?php echo e($country->id); ?>"> <?php echo e($country->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                      
                        <div class="form-group text-center">
                        	<input type="submit" name="sumit_country" id="sumit_country"  value="Sumit" class="btn btn-primary account-btn">
                        </div>
                    </form>
                    <?php if(isset($cities)): ?>
                        <table class="table table-bordered mt-5">
                            <thead>
                                <tr>
                                    <td>#</td>
                                    <td>City Name</td>
                                </tr>
                            </thead> 
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($city->name); ?></td>
                                </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="2" >No Data Found</td>
                                </tr> 
                                <?php endif; ?>
                            </tbody>

                        </table>    
                    <?php endif; ?>
                </div>
			</div>
        </div>
    </div>

    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
</body>


<!-- login23:12-->
</html><?php /**PATH /home/excellcons-paramlv/htdocs/paramlv.excellcons.com/resources/views/has_many_through.blade.php ENDPATH**/ ?>