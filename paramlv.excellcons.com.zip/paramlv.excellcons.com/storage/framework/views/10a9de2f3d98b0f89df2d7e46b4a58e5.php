<!-- <html> -->
;
<style>
    .btnr {
    position: absolute;
    right: 10px;
    top: 9%;
}
</style>
<?php $__env->startSection('content'); ?>
<!-- <?php echo $__env->make('css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12 mx-auto">
        <div class="card my-3">
            <div class="card-body">
                <h4 class="card-title text-center">All Patient</h4> 
                <a class="btn btn-success " href =" <?php echo e(route('crud.create')); ?>">Register</a>
                    <div class="card-body display">
                        <form action="<?php echo e(url('/search')); ?>" method = "Get" class="btnr">
                            <input name="search" class="form-conterol w-10" type="text" >
                            <input type='submit' class="btn btn-primary" value='Search'>
                            <!-- <button type="button" class="btn btn-primary " type="submit">Search -->
                                <!-- <i class="fas fa-search"></i> -->
                            <!-- </button> -->
                        </form>
                    </div>
                <hr>
                
                <?php echo $__env->make('flash_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <table class="table tabl-bordered  mt-4">
                <head>
                    <tr>
                        <td>#</td>
                        <td>Patint Name</td>
                        <td>contact</td>
                        <td>Age</td>
                        <td>BloodGroup</td>
                        <td>Birth_date</td>
                        <td>gender</td>
                        <td>Address</td>
                        <td>Medical History</td>
                        <td>Action</td>

                    </tr>
                </head>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <!-- <td><?php echo e($loop->iteration); ?></td> -->
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->pfname.' '.$user->pmname.' '.$user->plname); ?></td>
                        <td><?php echo e($user->contact); ?></td>
                        <td><?php echo e($user->age.'/'.$user->ym); ?></td>
                        <td><?php echo e($user->bloodgroup); ?></td>
                        <td><?php echo e($user->pbirth_date); ?></td>
                        <td><?php echo e($user->gender); ?></td>
                        <td><?php echo e($user->address); ?></td>
                        <td><?php echo e($user->medical_history); ?></td>
                        <td>
                        <a class="btn btn-primary" href =" <?php echo e(route('crud.show',['crud'=>$user->id])); ?>">Show</a>
                        <a class="btn btn-warning" href =" <?php echo e(route('crud.edit',['crud'=>$user->id])); ?>">Update</a>
                           <form method='post' action="<?php echo e(route('crud.destroy',['crud'=>$user->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type='submit' class="btn btn-danger" value='Delete'>
                           </form>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td>No Data Funde</td>
                    </tr>    
                    <?php endif; ?>
                </tbody> 
                
                </table>
                <?php echo $users->links(); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
   
<?php echo $__env->make('layouts.user_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/excellcons-paramlv/htdocs/paramlv.excellcons.com/resources/views/patient/search_list.blade.php ENDPATH**/ ?>