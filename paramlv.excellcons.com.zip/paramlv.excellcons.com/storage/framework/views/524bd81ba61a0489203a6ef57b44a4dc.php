
<html>
<?php echo $__env->make('css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-wrapper account-wrapper">
        <div class="account-page">
			<div class="account-center">
				<div class="account-box">
                  <form method="post" class="form-signin" action="http_login_get">
                    <?php echo csrf_field(); ?>
                    <!-- <?php echo e(method_field('PUT')); ?> -->
						<div class="account-logo">
                            <a href=""><img src="img/logo-dark.png" alt=""></a>
                        </div>
                        <div class="form-group">
                            <label for="email">Username or Email</label>
                            <input type="text" autofocus="" class="form-control" name="email" id="email">
                        </div>
                        <div class="form-group">
                            <label for="pass">Password</label>
                            <input type="password" class="form-control" name="pass",name="pass">
                        </div>
                        <div class="form-group text-right">
                            <a href="../login/forgot_password">Forgot your password?</a>
                        </div>
                        <?php if($errors->any()): ?>
                            <div class=" alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                         <?php endif; ?>
                        <div class="form-group text-center">
                        	<input type="submit" name="login" id="login"  value="login" class="btn btn-primary account-btn">
                           
                        </div>
                       
                    </form>
                </div>
			</div>
        </div>
    </div>

    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
</body>
</html><?php /**PATH /home/excellcons-paramlv/htdocs/paramlv.excellcons.com/resources/views/Template/login.blade.php ENDPATH**/ ?>