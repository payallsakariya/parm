<!-- <html> -->
;
<?php $__env->startSection('content'); ?>
<!-- <?php echo $__env->make('css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
<div class="page-wrapper">
		    <div class="content" style = "width:80">
		        <div class="row" style="padding:30px">
		            <div class="col-lg-8 offset-lg-6">
		                <h4 class="page-title">Patient List</h4>
		            </div>
		        </div>
				<a class="btn btn-success" href =" <?php echo e(route('crud.create')); ?>">Register</a>
                <hr>
				<?php echo $__env->make('flash_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <table class="table tabl-bordered  mt-4">
                <head>
                    <tr>
                        <td>#</td>
                        <td>pmshid</td>
                        <td>pfname</td>
                        <td>pmname</td>
                        <td>plname</td>
                        <td>contact</td>
                        <td>age</td>
                        <td>Year/Month/td>
                        <td>bloodgroup</td>
                        <td>Birth_date</td>
                        <td>gender</td>
                        <td>religion</td>
                        <td>postal_code</td>
                        <td>Address</td>
                        <td>Medical History</td>

                    </tr>
                </head>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($user->Pmshid); ?></td>
                        <td><?php echo e($user->pfname); ?></td>
                        <td><?php echo e($user->pmname); ?></td>
                        <td><?php echo e($user->plname); ?></td>
                        <td><?php echo e($user->contact); ?></td>
                        <td><?php echo e($user->age); ?></td>
                        <td><?php echo e($user->ym); ?></td>
                        <td><?php echo e($user->bloodgroup); ?></td>
                        <td><?php echo e($user->pbirth_date); ?></td>
                        <td><?php echo e($user->gender); ?></td>
                        <td><?php echo e($user->religion); ?></td>
                        <td><?php echo e($user->postal_code); ?></td>
                        <td><?php echo e($user->address); ?></td>
                        <td><?php echo e($user->medical_history); ?></td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="14">No Data Funde</td>
                    </tr>    
                    <?php endif; ?>
                </tbody> 
                
                </table>
            </div>
</div>
<?php $__env->stopSection(); ?>
   
<?php echo $__env->make('layouts.user_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/excellcons-paramlv/htdocs/paramlv.excellcons.com/resources/views/patient/index.blade.php ENDPATH**/ ?>