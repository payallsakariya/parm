<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
            crossorigin="anonymous"></script>
</head>
<body>
<div class="container mt-5">
    <div class="container-fluid">
        <h1> List of Users: </h1>
        <div class="card">
            <div class="card-body">
              <?php echo $__env->make('flash_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <hr>
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">Pid</th>
                        <th scope="col">Pmshid</th>
                        <th scope="col">Contact</th>
                        <th scope="col">Name</th>
                        <th scope="col">Age</th>
                        <th scope="col">Y-M</th>
                        <th scope="col">date</th>
                        <th scope="col">last_update</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($user->pid); ?></td>
                        <td><?php echo e($user->pmshid); ?></td>
                        <td><?php echo e($user->contact); ?></td>
                        <td><?php echo e($user->pfname); ?></td>
                        <td><?php echo e($user->age); ?></td>
                        <td><?php echo e($user->ym); ?></td>
                        <td><?php echo e($user->date); ?></td>
                        <td><?php echo e($user->last_update); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td>
                                No data found.
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html><?php /**PATH /home/excellcons-paramlv/htdocs/paramlv.excellcons.com/resources/views/select_patients.blade.php ENDPATH**/ ?>