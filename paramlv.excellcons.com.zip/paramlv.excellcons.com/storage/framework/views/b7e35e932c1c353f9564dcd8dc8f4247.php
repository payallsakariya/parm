<?php if(session()->has('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session()->has('danger')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session('danger')); ?>

    </div>
<?php endif; ?>
<?php if(session()->has('warning')): ?>
    <div class="alert alert-warning" role="alert">
        <?php echo e(session('warning')); ?>

    </div>
<?php endif; ?>
<?php if(session()->has('now')): ?>
    <div class="alert alert-primary" role="alert">
        <?php echo e(session('now')); ?>

    </div>
<?php endif; ?>
<?php /**PATH /home/excellcons-paramlv/htdocs/paramlv.excellcons.com/resources/views/flash_data.blade.php ENDPATH**/ ?>