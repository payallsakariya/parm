
<html>

<?php echo $__env->make('css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-wrapper account-wrapper">
        <div class="account-page">
			<div class="account-center ">
				<div class="account-box" style="width:40%; vertical-align:top; height:30%; ">
                  <form method="get" class="form-signin" action="<?php echo e(route('view_cities')); ?>">
                  <div class="account-logo">
                            <h2 class="card-titel text-center">Has One Through Reletionship</h2>
                        </div>	
                        <div class="form-group">
                            <label for="country">Counties:</label>
                            <select class= "form-control" name= "country" id="country">
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value = "<?php echo e($country->id); ?>"> <?php echo e($country->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                      
                        <div class="form-group text-center">
                        	<input type="submit" name="sumit_country" id="sumit_country"  value="Sumit" class="btn btn-primary account-btn">
                        </div>
                    </form>
                    <?php if(isset($cities)): ?>
                        <table class="table table-bordered mt-5">
                            <thead>
                                <tr>
                                    <td>#</td>
                                    <td>City Name</td>
                                </tr>
                            </thead> 
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td><?php echo e($cities->name); ?></td>
                                </tr> 
                            </tbody>

                        </table>    
                    <?php endif; ?>
                </div>
			</div>
        </div>
    </div>

    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
</body>


<!-- login23:12-->
</html><?php /**PATH /home/excellcons-paramlv/htdocs/paramlv.excellcons.com/resources/views/reletion.blade.php ENDPATH**/ ?>