<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CarsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $data= [
            'name' => 'Octavia',
            'product' => 'Skoda',
            'description' => 'Sedan Car',
            'created_at' => '2021-12-02 12::12:00',
            'updated_at' => '2021-12-02 12::12:00',
        ];
        $insData=\DB::table('cars')->insert($data);
    }
}
