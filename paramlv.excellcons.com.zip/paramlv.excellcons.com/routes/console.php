<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Mail;
use App\Mail\WelcomeEmail;

/*
|--------------------------------------------------------------------------
| Console Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of your Closure based console
| commands. Each Closure is bound to a command instance allowing a
| simple approach to interacting with each command's IO methods.
|
*/

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

Artisan::command('user:email', function () {
    $email_add =('rahi013shah@gmail.com');
    $emailData =[
        'subject' => 'Good you try to learning lavavel',
        'body' => 'you learning lavavel email sending.this is the classic example of sending email useing laravel commad',
        'tagline' => 'LEARN ANY COURSE  FOR IN YOUR OWN LANGUAGE UPDATED.'
    ];
    Mail::to('payl@mailinator.com')
    ->send(new WelcomeEmail($emailData));
})->purpose('Sending Emails ');

Artisan::command('massege {user*}', function ($user) {
    $opt=$this->user = $user;
    print_r($opt);exit;
    // $this->comment($opt);    $name = $this->ask('What is your name?');
})->purpose('Display an inspiring quote');

Artisan::command('command:io', function () {
    //  $email = $this->ask('What is your email?');
    //  $this->comment('My email is :- '.$email);
    //  $password = $this->secret('What is the password?');
    //  $this->comment('My password is :- '.$password);
    //  $conf=$this->confirm('Do you wish to continue?');
    //  print_r($conf);
    // $name = $this->choice(
    //     'What is your name?',
    //     ['Taylor', 'Dayle'],
    //     0
    // );
    // $this->comment('My name is :- '.$name);

    $this->info('The command was successful!');
})->purpose('Display an inspiring quote');