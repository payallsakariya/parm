<?php

return [
    'en' => 'English',
    'hi' => 'Hindi',
    'gu' => 'Gujarati',
    'es' => 'Spanish',
    'fr' => 'French',
    'de' => 'German'
];
