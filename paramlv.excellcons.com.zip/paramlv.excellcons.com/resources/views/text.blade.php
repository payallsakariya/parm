
{{ $emailData['body'] }}