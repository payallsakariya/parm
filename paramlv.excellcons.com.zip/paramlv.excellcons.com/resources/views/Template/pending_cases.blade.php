@extends('layouts.user_layout_for_Auth')
@section('content')
<?php  $data = session ()->get ( 'usrs_info' ); ?>
                       
                       
<input type="text"  id="login_type" name="login_type" size="2" readonly value="{{ $data }}" hidden>
              <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-8 col-6">
                        <h4 class="page-title">Pending Cases</h4>
                    </div>
                </div>
                <div class="row filter-row">
                    <div class="col-sm-4 col-md-5">
                        <div class="form-group form-focus">
		                      <select id="month" name="month" style="width:100%" class="form-control floating select2">
		                      </select>
                            <input type="hidden" name="pid"  id="pid" />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                        	<table id="tbl" class="table display" style="width:100%">
                            <!--<table class="table table-border table-striped custom-table datatable mb-0 " id="tbl">-->
                                <thead>
                                    <tr>
                                    	  <th class="text-right">Action</th>
                                        <th scope="col">#</th>
                                        <th scope="col">Case No.</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Time</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Age</th>
                                        <th scope="col">Gender</th>
                                        <th scope="col">Phone</th>
                                        <th scope="col">paypending</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
           </div>
        <div id="delete_patient" class="modal fade delete-modal" role="dialog">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body text-center">
                        <img src="../../img/sent.png" alt="" width="50" height="46">
                        <h3>Are you sure want to delete this Patient?</h3>
                        <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                            <button type="submit" class="btn btn-danger deletedata" data-id="" id="deleterec">Delete</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>
@endsection
@section('scriptdata')
<script>
    $(document).ready(function(){
  pendding_cases();
   
        var path = "{{ route('patientpendingcases') }}";
            $('#month').select2({
                placeholder: 'Select an user',
                ajax: {
                url: path,
                dataType: 'json',
                delay: 250,
                processResults: function (data) {
                    return {
                    results:  $.map(data, function (item) {
                            return {
                                text: item.pfname+"("+item.pmshid+")",
                                id: item.pid,
                                pmshid:item.pmshid
                            }
                        })
                    };
                },
                cache: true
                }
            });
        })
        // insert prectis table
            $("#month").on("change",function(){
                        var pid = document.getElementById("month").value;
                        var base = '{!! route('add_pending_cases') !!}';
                        var url = base+'?pid='+pid ;
                        location.href = url;
            })


function pendding_cases(){
	var	login_type = document.getElementById("login_type").value;  
    var path="{{ route('pendingcases_json') }}";
    var table = $('#tbl').DataTable({
        processing: true,
        serverSide: false,
        ordering: false,
                ajax: {
	    		url: path,
	    		dataType: 'json'
	    	},

        	columnDefs: [
            {
                searchable: false,
                orderable: false,
                targets: 0,
            },
        ],
       
	    	columns: [
	    		{data: 'caseid'},
	    		{data: 'caseid'},
	    		{data: 'pmshid'},
	    		{data: 'date'},
	    		{data: 'time'},
	    		{data: 'Name'},
	    		{data: 'age'},
	    		{data: 'gender'},
	    		{data: 'contact'},
	    		{data: 'paypending'},
	    	
	    		],
	    		
	    		
	     columnDefs: [
	     	{
					"targets": 0,
					"data": "caseid",
					"render": function ( data, type, row, meta ) {
                        console.log(row);
						if(login_type == 'doctor'){
					return "<td class='text-right'><div class='dropdown dropdown-action'><a href='#' class='action-icon dropdown-toggle' data-toggle='dropdown' aria-expanded='false'><i class='fa fa-ellipsis-v'></i></a><div class='dropdown-menu dropdown-menu-right'><a class='dropdown-item' href='DoctorEditPatient?case_id="+data+"'><i class='fa  m-r-5'></i>Update</a><a class='dropdown-item deletedata' href='../admission/AdmitPatient?p_id="+row.pid+"'><i class='fa m-r-5'></i>Admit</a></div></div></td>";
						}else{ 
						return "<td class='text-right'><div class='dropdown dropdown-action'><a href='#' class='action-icon dropdown-toggle' data-toggle='dropdown' aria-expanded='false'><i class='fa fa-ellipsis-v'></i></a><div class='dropdown-menu dropdown-menu-right'><a class='dropdown-item' href='edit_patient?p_id="+row.pid+"'><i class='fa fa-pencil m-r-5'></i> Edit</a><a class='dropdown-item deletedata' href='#' data-toggle='modal' data-target='#delete_patient' data-dataid="+row.id+"><i class='fa fa-trash-o m-r-5'></i>Delete</a></div></div></td>";
						}
					}
					}
					]
    });

}

</script>
@endsection

