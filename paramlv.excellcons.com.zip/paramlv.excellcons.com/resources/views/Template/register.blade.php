@extends('layouts.user_layout_for_Auth')
@section('content')

<div class="page-wrapper hgjhg">
		    <div class="content">
		        <div class="row" style="padding:30px">
                @if($errors->any())
                            <div class=" alert alert-danger">
                                <ul>
                                    @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>  
                                @endforeach
                                </ul>
                            </div>
                         @endif
		            <div class="col-lg-8 offset-lg-2">
		                <h4 class="page-title">ADD Patient sdsafsfd</h4>
		            </div>
		        </div>
		        <div class="row">
		          <div class="col-lg-8 offset-lg-2">
		           <form  method="post"  action = "register_get">
                   @csrf
			            <div class="row">
			                  <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="pfname">First Name </label><span class="text-danger pl-2">*</span>
			                        <input class="form-control" type="text" id="pfname" name="pfname" pattern="[A-Za-z]{1,32}" required="">
			                    </div>
                              </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="pmname">Middle Name</label><span class="text-danger pl-2">*</span>
                                        <input class="form-control" type="text" id="pmname" name="pmname" pattern="[a-z A-Z]{1,32}" required="">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                <div class="form-group">
                                        <label for="plname">Last Name </label><span class="text-danger pl-2">*</span>
                                        <input class="form-control" type="text" id="plname" name="plname" pattern="[a-z A-Z]{1,32}" required="">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="pbirth_date">Date of Birth</label>
                                        <div class="cal-icon">
                                    <input type="text" class="form-control datetimepicker" name="pbirth_date" id="pbirth_date" onchange="mydatepicker()" >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label for="age">Age</label>
                                        <input class="form-control" type="number" id="age" name="age">
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label for="ym">Year/Month</label>
                                        <select class="form-control" id="ym" name="ym">
                                                    <option value="years">Year</option>
                                                    <option value="months">Month</option>
                                                    </select>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="contact">Contact </label><span class="text-danger pl-2">*</span>
                                        <input class="form-control" type="text" id="contact" name="contact" pattern="[1-9]{1}[0-9]{9}" required="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                    <label for="bloodgroup">Blood Group</label>
                                                    <select class="form-control" id="bloodgroup" name="bloodgroup">
                                                    <option value="">Plase Select</option>
                                                    <option value="A+">A+</option>
                                                    <option value="A-">A-</option>
                                                    <option value="B+">B+</option>
                                                    <option value="B-">B-</option>
                                                    <option value="AB+">AB+</option>
                                                    <option value="AB-">AB-</option>
                                                    <option value="O+">O+</option>
                                                    <option value="O-">O-</option>
                                                    </select>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group gender-select">
                                        <label class="gen-label" for="gender">Gender: <span class="text-danger pl-2">*</span></label>
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                            <input type="radio" name="gender" id="gender" class="form-check-input" value="male" required>Male
                                            </label>
                                        </div>
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                                <input type="radio" name="gender" id="gender" class="form-check-input"  value="female">Female
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="religion">Religion</label>
                                        <input class="form-control" type="text" id="religion" name="religion" pattern="[a-z A-Z]{1,32}">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="postal_code">Postal Code</label>
                                    <input type="text" class="form-control" id="postal_code" name="postal_code" pattern="[0-9]{6}">
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="address">Address</label>
                                        <textarea class="form-control" id="address" name="address" value="" 
                                        pattern="[a-z A-Z]{1,50}" rows="3"></textarea>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label for="medical_history">Medical History</label>
                                                <textarea class="form-control" id="medical_history" name="medical_history" 
                                                value="" rows="3"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
			            </div>
                        <div class="m-t-20 text-center">
                            <input type="submit" name="Submit" id="Submit"  value="Create Patient" class="btn btn-primary submit-btn mx-auto">
                        </div>
		
		            </form>
		          </div>
		        </div>
		    </div>
</div>

@endsection
@section('scriptdata')
<script>
  //datepicker future date diseble start
   $(document).ready(function() {
    var today = new Date();
		        $('#pbirth_date').datepicker({
				            dateFormat: 'dd-mm-yy ',
				            autoclose:true,
				            changeMonth: true,
				            changeYear: true,
				            yearRange: "-100:+100",
				            endDate: "today",
				            maxDate: today
				          }).on('changeDate', function (ev) {
				               $(this).datepicker('hide');
				      });
//End
				     
				    // start Datepicker all key process stops(diseble)       
				        $('#pbirth_date').keyup(function () {
				        	$('#pbirth_date').keypress(
											  function(event){
											   event.preventDefault();
											});
				          })  
		        //End datepicker 
   });


   
    //birthday to find Age and show Age  text box	start   
    function mydatepicker(){
			   	var selectdate = document.getElementById("pbirth_date").value;  
			    	//setAge function  assets/js/app.js
				      var age = setAge(selectdate);
							  $('#age').val(age);
				      }
			      //End
</script>
@endsection

