@extends('layouts.user_layout_for_Auth')
@section('content')
<div class="page-wrapper">
            <div class="content">
                <div class="row ml-3">
                    <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                        <div class="dash-widget">
                            <span class="dash-widget-bg4"><i class="fa fa-heartbeat" aria-hidden="true"></i></span>
                            <a href="../patient/pending_cases">
                                <div class="dash-widget-info text-right">
                                    <h3 id="pendingcases"></h3>
                                    <span class="widget-title4">Pending Cases
                                        <!-- <i class="fa fa-check" aria-hidden="true"></i> -->
                                    </span>
                                </div>
                            </a>


                        </div>
                    </div>

                    <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                        <div class="dash-widget">
                            <span class="dash-widget-bg1"><i class="fa fa-stethoscope" aria-hidden="true"></i></span>
                            <a href="../patient/completed">
                                <div class="dash-widget-info text-right">
                                    <h3 id="Completedcases"></h3>
                                    <span class="widget-title1">Completed Cases
                                        <!-- <i class="fa fa-check" aria-hidden="true"></i> -->
                                    </span>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                        <div class="dash-widget">
                            <span class="dash-widget-bg2"><i class="fa fa-user-o"></i></span>
                            <div class="dash-widget-info text-right">
                                <h3 id="Patients"></h3>
                                <span class="widget-title2">Patients
                                    <!-- <i class="fa fa-check" aria-hidden="true"></i> -->
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                        <div class="dash-widget">
                            <span class="dash-widget-bg3"><i class="fa fa-inr" aria-hidden="true"></i></span>
                            <div class="dash-widget-info text-right">
                            	 <h3 id="TotalAmounts"><span><i class="fa fa-inr" aria-hidden="true" style="font-size: px;"></i></span></h3>
                                <!--<h3><span><i class="fa fa-inr" aria-hidden="true" style="font-size: px;"></i></span>73-->
                                <!--</h3>-->
                                <span class="widget-title3">Total Amount
                                    <!-- <i class="fa fa-check" aria-hidden="true"></i> -->
                                </span>
                            </div>
                        </div>
                    </div>

                </div>
                <!--<div class="row">-->
                <!--    <div class="col-12 col-md-6 col-lg-6 col-xl-6">-->
                <!--        <div class="card">-->
                <!--            <div class="card-body">-->
                <!--                <div class="chart-title">-->
                <!--                    <h4>Patient Total</h4>-->
                <!--                    <span class="float-right"><i class="fa fa-caret-up" aria-hidden="true"></i> 15%-->
                <!--                        Higher than Last Month</span>-->
                <!--                </div>-->
                <!--                <canvas id="linegraph"></canvas>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--    <div class="col-12 col-md-6 col-lg-6 col-xl-6">-->
                <!--        <div class="card">-->
                <!--            <div class="card-body">-->
                <!--                <div class="chart-title">-->
                <!--                    <h4>Patients In</h4>-->
                <!--                    <div class="float-right">-->
                <!--                        <ul class="chat-user-total">-->
                <!--                            <li><i class="fa fa-circle current-users" aria-hidden="true"></i>ICU</li>-->
                <!--                            <li><i class="fa fa-circle old-users" aria-hidden="true"></i> OPD</li>-->
                <!--                        </ul>-->
                <!--                    </div>-->
                <!--                </div>-->
                <!--                <canvas id="bargraph"></canvas>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
    <!--<div class="col-12 col-md-6 col-lg-4 col-xl-4">-->
    <!--    <div class="card member-panel">-->
    <!--        <div class="card-header bg-white">-->
    <!--            <h4 class="card-title mb-0">Doctors</h4>-->
    <!--        </div>-->
    <!--        <div class="card-body">-->
    <!--            <ul class="contact-list">-->
    <!--                <li>-->
    <!--                    <div class="contact-cont">-->
    <!--                        <div class="float-left user-img m-r-10">-->
    <!--                            <a href="profile.php" title="John Doe"><img src="../assets/img/user.jpg" alt=""-->
    <!--                                    class="w-40 rounded-circle"></a>-->
    <!--                        </div>-->
    <!--                        <div class="contact-info">-->
    <!--                            <span class="contact-name text-ellipsis">John Doe</span>-->
    <!--                            <span class="contact-date">MBBS, MD</span>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                </li>-->
    <!--                <li>-->
    <!--                    <div class="contact-cont">-->
    <!--                        <div class="float-left user-img m-r-10">-->
    <!--                            <a href="profile.php" title="Richard Miles"><img src="../assets/img/user.jpg" alt=""-->
    <!--                                    class="w-40 rounded-circle"></a>-->
    <!--                        </div>-->
    <!--                        <div class="contact-info">-->
    <!--                            <span class="contact-name text-ellipsis">Richard Miles</span>-->
    <!--                            <span class="contact-date">MD</span>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                </li>-->
    <!--                <li>-->
    <!--                    <div class="contact-cont">-->
    <!--                        <div class="float-left user-img m-r-10">-->
    <!--                            <a href="profile.php" title="John Doe"><img src="../assets/img/user.jpg" alt=""-->
    <!--                                    class="w-40 rounded-circle"></a>-->
    <!--                        </div>-->
    <!--                        <div class="contact-info">-->
    <!--                            <span class="contact-name text-ellipsis">John Doe</span>-->
    <!--                            <span class="contact-date">BMBS</span>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                </li>-->
    <!--                <li>-->
    <!--                    <div class="contact-cont">-->
    <!--                        <div class="float-left user-img m-r-10">-->
    <!--                            <a href="profile.php" title="John Doe"><img src="../assets/img/user.jpg" alt=""-->
    <!--                                    class="w-40 rounded-circle"></a>-->
    <!--                        </div>-->
    <!--                        <div class="contact-info">-->
    <!--                            <span class="contact-name text-ellipsis">John Doe</span>-->
    <!--                            <span class="contact-date">BMBS</span>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                </li>-->
    <!--            </ul>-->
    <!--        </div>-->
    <!--        <div class="card-footer text-center bg-white">-->
    <!--            <a href="doctors.html" class="text-muted">View all Doctors</a>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    </div>
    </div>
    @endsection
 
  
