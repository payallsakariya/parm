
<html>
@include('css')
    <div class="main-wrapper account-wrapper">
        <div class="account-page">
			<div class="account-center">
				<div class="account-box">
                  <form method="post" class="form-signin" action="http_login_get">
                    @csrf
                    <!-- {{ method_field('PUT') }} -->
						<div class="account-logo">
                            <a href=""><img src="img/logo-dark.png" alt=""></a>
                        </div>
                        <div class="form-group">
                            <label for="email">Username or Email</label>
                            <input type="text" autofocus="" class="form-control" name="email" id="email">
                        </div>
                        <div class="form-group">
                            <label for="pass">Password</label>
                            <input type="password" class="form-control" name="pass",name="pass">
                        </div>
                        <div class="form-group text-right">
                            <a href="../login/forgot_password">Forgot your password?</a>
                        </div>
                        @if($errors->any())
                            <div class=" alert alert-danger">
                                <ul>
                                    @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>  
                                @endforeach
                                </ul>
                            </div>
                         @endif
                        <div class="form-group text-center">
                        	<input type="submit" name="login" id="login"  value="login" class="btn btn-primary account-btn">
                           
                        </div>
                       
                    </form>
                </div>
			</div>
        </div>
    </div>

    @include('footer')
 
</body>
</html>