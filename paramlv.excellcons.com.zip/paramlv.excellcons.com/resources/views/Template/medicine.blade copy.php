<?php 
// $edit_pateint = $_SESSION['DEditpatient'];
// $updat = $_SESSION['update_patient_info'];
$edit_pateint = session ()->get ( 'DEditpatient' );
foreach($edit_pateint as $value){
// echo $value->date;
$p_date = str_replace('/"', '-', $value->date);
$caseid=$value->caseid;
$pmshid=$value->pmshid;
$time=$value->time;
$Name=$value->Name;
$age=$value->age;
$gender=$value->gender;
$contact=$value->contact;
$pid=$value->pid;


}
$new_pDate = date("d-m-Y", strtotime($p_date));
$data = session ()->get ( 'usrs_info' ); 
?>

@extends('layouts.user_layout_for_Auth')
@section('content')
@if($data == 'doctor')
    <style>
		.bg {
			background-color: #0fa7c9;
			color: #fff;
		}
		.border {
			border-top: 1px solid #dee2e6;
		}
		.bt{
			margin-top: 10px;
			height: 35px;
			width: 45px;
		}
		.note{
			 overflow:scroll;
		}
		.selectbg{background-color:#e4e4e408;border:1px solid #aaa;
		}
	</style>
	<div class="page-wrapper">
		<div class="content">
			<div class="row">
				<div class="col-lg-12 ">
					<form method="post">
                       <div class="row">
							<div class="col-md-12">
								<div class="table-responsive">
									<table id="tbl" class="table display" style="width:100%">
										<thead>
											<tr class="bg">
												<th scope="col">Case No.</th>
												<th scope="col">Date</th>
												<th scope="col">Time</th>
												<th scope="col">Name</th>
												<th scope="col">Age</th>
												<th scope="col">Gender</th>
												<th scope="col">Phone</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>{{$caseid.'/'.$pmshid; }}</td>
												<td>{{$new_pDate; }} </td>
												<td>{{$time; }}</td>
												<td>{{$Name; }}</td>
												<td>{{ $age; }}</td>
												<td>{{ $gender; }}</td>
												<td>{{$contact; }}</td></tr>
										</tbody>
										
									</table>
								</div>
							</div>
						</div>
						<?php if($_GET['caseid']) 
                               {
								echo 'if';
							   }
								else{
									echo 'else';
								}
						
						?>
                        


                
            
                      
                    </form>
                </div>    
            </div>
		</div>
	</div> 
    @else
    {{'this this else' }}
 @endif   


    @endsection
@section('scriptdata')
@endsection