<?php 
// $edit_pateint = $_SESSION['DEditpatient'];
// $updat = $_SESSION['update_patient_info'];
$edit_pateint = session ()->get ('DEditpatient');
// echo "<pre>";
// print_r($edit_pateint);exit;
foreach($edit_pateint as $value){
// echo $value->date;exit;
// $p_date = str_replace('/"', '-', $value->date);
$caseid=$value->caseid;
$pmshid=$value->pmshid;
$time=$value->time;
$Name=$value->Name;
$age=$value->age;
$gender=$value->gender;
$contact=$value->contact;
$pid=$value->pid;
}
$new_pDate = date("d-m-Y", strtotime(str_replace('/"', '-', $value->date)));
$data = session ()->get ( 'usrs_info' ); 
?>

@extends('layouts.user_layout_for_Auth')
@section('content')
@if($data == 'doctor')
    <style>		
		.bg {
			background-color: #0fa7c9;
			color: #fff;
		}
		.border {
			border-top: 1px solid #dee2e6;
		}
		.bt{
			margin-top: 10px;
			height: 35px;
			width: 45px;
		}
		.note{
			 overflow:scroll;
		}
		.selectbg{background-color:#e4e4e408;border:1px solid #aaa;
		}
	</style>
	<div class="page-wrapper">
		<div class="content">
			<div class="row">
				<div class="col-lg-12 ">
					<form method="post" action="DoctorEditPatient">
					@csrf
                       <div class="row">
							<div class="col-md-12">
								<div class="table-responsive">
									<table id="tbl" class="table display" style="width:100%">
										<thead>
											<tr class="bg">
												<th scope="col">Case No.</th>
												<th scope="col">Date</th>
												<th scope="col">Time</th>
												<th scope="col">Name</th>
												<th scope="col">Age</th>
												<th scope="col">Gender</th>
												<th scope="col">Phone</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>{{$caseid.'/'.$pmshid; }}</td>
												<td>{{$new_pDate; }} </td>
												<td>{{$time; }}</td>
												<td>{{$Name; }}</td>
												<td>{{ $age; }}</td>
												<td>{{ $gender; }}</td>
												<td>{{$contact; }}</td></tr>
										</tbody>
										<td><input type="text" id="pid" name="pid" size="2" readonly
											value="{{ $pid; }}" hidden="">
											<input type="text" id="case_id" name="case_id" size="2" readonly
											value="{{ $caseid; }}" hidden="">
										</td>
									</table>
								</div>
							</div>
						</div>
						<?php 
					    if (request()->has('caseid'))  {
									$updat = $_SESSION['update_patient_info'];
									$Disease =explode(',',$updat->disease);
									$Complaints=explode(',',$updat->complaints);
									$test_requested=explode(',',$updat->test_requested);
									$ds_count=count($Disease);
									$cm_count=count($Complaints);
									$tr_count=count($test_requested);
									
									?>
										<div class="row">
														<div class="col-md-12">
														<label for="vod"><h4>Vitals</h4></label>
													</div>
														
														<div class="col-sm-10">
												<div class="form-group">
														<label for="disease_mul" class="control-label"><b>Disease</b></label>&nbsp;
																		<select class="form-select selectbg" name="disease_mul[]" id="disease_mul"
																		multiple="multiple" class="form-control border" style="width:100%"  
																		data-placeholder="Choose anything">
																		<?php 
																			for($i=0;$i<$ds_count;$i++){
																				?>
																				<option value="<?php echo $Disease[$i] ?>" selected="select"><?php echo $Disease[$i] ?></option>
																				<?php
																			}
																		
																		?>
																				</select> 
												</div>
											</div>
														<div class="col-sm-10">
												<div class="form-group">
														<label for="complaints" class="control-label"><b>Complaints</b></label>&nbsp;
																		<select class="js-example-basic-multiple" name="complaints[]" id="complaints"
																		multiple="multiple" class="form-control border" style="width:100%">
																			<?php 
																			for($i=0;$i<$cm_count;$i++){
																				?>
																				<option value="<?php echo $Complaints[$i] ?>" selected="select"><?php echo $Complaints[$i] ?></option>
																				<?php
																			}
																		
																		?>
																				</select> 
												</div>
											</div>
												<div class="col-sm-10">
													<label for="t" class="control-label">Medicines</label>&nbsp;
													<input class="border form_controt" type="text" id="medicines" name="medicines" 
													value="<?php echo $updat->medicines; ?>">
											</div>
														
													<br><br>
													<div></div>
												<div class="col-sm-3">
												<div class="form-group">
													<label for="t" class="control-label">Temperature</label>&nbsp;
																			<input class="border form_controt" type="text"  name="t" id="t"  size="10"
																			value="<?php echo $updat->t; ?>" >&#8457;
												</div>
											</div>
											
											<div class="col-sm-3">
												<div class="form-group">
													&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
													<label for="pulse" class="control-label">Pulse</label>&nbsp;
																			<input class="border form_controt" type="text"  name="pulse" id="pulse"  size="10"
																			value="<?php echo $updat->pulse; ?>" >/bpm
												</div>
											</div>
												<div class="col-sm-4">
												<div class="form-group">
													<label for="spo2" class="control-label">SPO2</label>&nbsp;
																			<input class="border form_controt" type="text"  name="spo2" id="spo2" 
																			size="10" value="<?php echo $updat->spo2; ?>" > %
												</div>
											</div>
											<div class="col-sm-3">
												<div class="form-group">
													&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
													<label for="height" class="control-label">Height</label>&nbsp;
																			<input class="border form_controt" type="text"  name="height" 
																			id="height"  size="10" value="<?php echo $updat->height; ?>" >CM
												</div>
											</div>
											<div class="col-sm-3">
												<div class="form-group">
														&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
													<label for="weight" class="control-label">Weight</label>&nbsp;
																			<input class="border form_controt" type="text"  name="weight" 
																			id="weight"  size="10" value="<?php echo $updat->weight; ?>" >/min
												</div>
											</div>
											<div class="col-sm-3">
												<div class="form-group">
													&nbsp;&nbsp;&nbsp;&nbsp;
													<label for="bp" class="control-label">BP</label>&nbsp;
																			<input class="border form_controt" type="text"  name="bp" id="bp" size="10"
																			value="<?php echo $updat->bp; ?>" >mmHg
												</div>
											</div>
											
											
											</div>
														<?php
						}else{
					     ?>
							<div class="row">
								<div class="col-md-12">
									<label for="vod"><h4>Vitals</h4></label>
								</div>
								
								<div class="col-sm-10">
									<div class="form-group">
									<label for="disease_mul" class="control-label"><b>Disease</b></label>&nbsp;
										<select class="form-select selectbg" name="disease_mul[]"  id="disease_mul"
										multiple="multiple" class="form-control border" style="width:100%"  
										data-placeholder="Choose anything">
											</select> 
									</div>
								</div>
								<div class="col-sm-10">
									<div class="form-group">
									<label for="complaints" class="control-label"><b>Complaints</b></label>&nbsp;
										<select class="js-example-basic-multiple" name="complaints[]" id="complaints"
										multiple="multiple" class="form-control border" style="width:100%">
											</select> 
									</div>
								</div>
								<div class="col-sm-10">
									<label for="t" class="control-label">Medicines</label>&nbsp;
									<input class="border form_controt" type="text" id="medicines" name="medicines" 
									value="">
								</div>
										
								<br><br>
								<div></div>
								<div class="col-sm-3">
									<div class="form-group">
										<label for="t" class="control-label">Temperature</label>&nbsp;
										<input class="border form_controt" type="text"  name="t" id="t"  size="10"
										value="" >&#8457;
									</div>
								</div>
								<div class="col-sm-3">
								<div class="form-group">
										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<label for="pulse" class="control-label">Pulse</label>&nbsp;
										<input class="border form_controt" type="text"  name="pulse" id="pulse"  size="10"
										value="" >/bpm
									</div>
								</div>
						
								<div class="col-sm-4">
									<div class="form-group">
										<label for="spo2" class="control-label">SPO2</label>&nbsp;
										<input class="border form_controt" type="text"  name="spo2" id="spo2" 
										size="10" value="" > %
									</div>
								</div>
						
								<div class="col-sm-3">
									<div class="form-group">
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<label for="height" class="control-label">Height</label>&nbsp;
											<input class="border form_controt" type="text"  name="height" 
											id="height"  size="10" value="" >CM
									</div>
								</div>
								<div class="col-sm-3">
									<div class="form-group">
											&nbsp;&nbsp;&nbsp;&nbsp;	&nbsp;&nbsp;&nbsp;&nbsp;
										<label for="weight" class="control-label">Weight</label>&nbsp;
										<input class="border form_controt" type="text"  name="weight" 
										id="weight"  size="10" value="" >/min
									</div>
								</div>
								<div class="col-sm-3">
									<div class="form-group">
										&nbsp;&nbsp;&nbsp;&nbsp;
										<label for="bp" class="control-label">BP</label>&nbsp;
											<input class="border form_controt" type="text"  name="bp" id="bp" size="10"
											value="" >mmHg
									</div>
								</div>
							</div>
							<?php
						}?>

                        <table align=center class="table display" style="width:100%">
							<thead class="bg">
								<th style="width:10%">Type</th><th style="width:25%">Medicine</th><th style="width:9%">Dosage</th><th style="width:15%">When</th><th style="width:13%">Frequency</th><th style="width:11%">Duration</th><th style="width:11%">Notes</th><th></th><th></th>
							</thead>
							<tbody>
								<td>
									<select id="m_type" name="m_type" class="form-control border" style="height:50px;width:70px;">
										<!--<option value="" >type</option>-->
									</select>
									<input class="cid" type="text"  name="cid" id="cid" value="" size="1" hidden="">
								</td>
								<td>
									<div class="form-group form-focus">
										<select id="med_name" name="med_name"  style="height:50px;width:165px;" class="form-control border floating select2">
										</select>
									</div>
								</td>
								<td><select name="dosage"id="dosage" class="form-control border" style="height:50px;width:90px;">
									<!--<option></option>-->
									<option value="1-0-1">1-0-1</option>
									<option value="1-0-0">1-0-0</option>
									<option value="1-1-0">1-1-0</option>
									<option value="1-1-1">1-1-1</option>
									<option value="0-1-0">0-1-0</option>
									<option value="0-0-1">0-0-1</option>
									<option value="0-1-1">0-1-1</option>
									<option value="0-0-0-1">0-0-0-1</option>
								</select>
								</td>
								<td><select name="when" id="when" class="form-control border" style="height:50px;width:130px">
									<option value="Before Food">Before Food</option>
									<option value="After Food">After Food</option>
									<option value="Before Breakfast">Before Breakfast</option>
									<option value="After Breakfast">After Breakfast</option>
									<option value="Before Lunch">Before Lunch</option>
									<option value="After Lunch">After Lunch</option>
									<option value="Before Dinner">Before Dinner</option>
									<option value="After Dinner">After Dinner</option>
									<option value="Empty Stomach">Empty Stomach</option>
									<option value="Bed Time">Bed Time</option>
									<option value="SoS">SoS</option>
								</select>
								</td>
								<td><select name="Frequency" id="Frequency" class="form-control border" style="height:50px;width:130px;">
									<option value="Daily">Daily</option>
									<option value="Alternate Day">Alternate Day</option>
									<option value="Weekly">Weekly</option>
									<option value="Fort Night">Fort Night</option>
									<option value="Monthly">Monthly</option>
								</select>
								</td>
								<td>
									<div class="form-group form-focus">
										<select name="duration" id="duration" class="form-control border select2"
											style="height:50px;width:100px;">
										</select>
									</div>
								</td>
								<td><textarea type="text" name="notes" id="notes" value="" class="form-control border note" rows="1"cols="4"  style="height:50px;width:100px;"></textarea></td>
								<!--<td ><input type="text" name="type_id" id="type_id" value="" class="form-control border type_id"></td>-->
								
								<td class=""><input type="button" name="Medicine_updat" id="Medicine_updat" class="Medicine_updat" value="Update" hidden="hidden" size="4"></td>
								<td><input type=submit name="m_add" id="m_add" value="Add" class="M_Add bt" size="1"></td>
							</tbody>
						</table>
						<div class="row">
							<div class="col-md-12">
								<div class="table-responsive">
									<table id="madicine" class="table display" style="width:100%">
										<!--<table class="table table-border table-striped custom-table datatable mb-0 " id="tbl">-->
										<thead class="bg">
											<tr style="background-color:#75797c">
												<th>Action</th><th style="width:10%">Type</th><th style="width:25%">Medicine</th><th style="width:9%">Dosage</th><th style="width:15%">When</th><th style="width:13%">Frequency</th><th style="width:9%">Duration</th><th>Notes</th>
											</tr>
										</thead>
									</table>
								</div>
							</div>
						</div>
						<?php 
						if (request()->has('caseid'))  {
							$updat = $_SESSION['update_patient_info'];
								$tw_date = str_replace('/"', '-', $updat->tsts_when_date);
									$new_twDate = date("d-m-Y", strtotime($tw_date));
										$nv_date = str_replace('/"', '-', $updat->next_visit_date);
									$new_nvDate = date("d-m-Y", strtotime($nv_date));
							?>
						<div class="row">
								<div class="col-sm-3">
								<div class="form-group">
									<label for="advice" class="control-label">Advice</label>&nbsp;
									<select id="advice" name="advice" class="form-control border">
									<option value="<?php echo $updat->advice_name ?>" selected="select"><?php echo $updat->advice_name ?></option>
									</select>      
									<input type="text" name="advice_name" value="<?php echo $updat->advice_name ?>" id="advice_name" hidden>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group">
									<label for="description" class="control-label">Description</label>&nbsp;
									<textarea type="text" name="description" id="description" value="" class="form-control border note" rows="4"cols="6"><?php echo $updat->description  ?></textarea>      
									</div>
								</div>
								<div class="col-sm-12">
									<div class="form-group">
									<label for="test_requested" class="control-label">Tests Requested</label>&nbsp;
									<select class="form-select selectbg" name="test_requested[]" 
											id="test_requested" multiple="multiple" class=" border" 
											style="width:10%">
											<?php 
												for($i=0;$i<$tr_count;$i++){
												?>
												<option value="<?php echo $test_requested[$i] ?>" selected="select"><?php echo $test_requested[$i] ?></option>
												<?php
												}
											?>
										</select> &nbsp;&nbsp;
										<label for="tsts_when" class="control-label">When</label>&nbsp;
										<input type="text" class=" datetimepicker border date_dt mb-4 bp-4" name="tsts_when"  style="width:10%" id="tsts_when" value="<?php echo $new_twDate; ?>" >
												
									</div>
								</div>
									
									<table width="70%" style="" cellpadding="5">
										<tr>
											<td>
													<label for="next_visit" class="control-label">Next Visit</label>&nbsp;
												<input class="border form-control" type="text"  name="next_visit" id="next_visit" 
												value="<?php echo $updat->next_visit ?>" >
											</td>
											<td>
													<button type="button" class="btn btn-secondary mt-4 day">Days</button>
													<button type="button" class="btn btn-secondary mt-4 week">Weeks</button>
													<button type="button" class="btn btn-secondary mt-4 month">Months</button>
													&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;or
											</td>
											<td>
												<label for="next_visit_date" class="control-label">Next Visit Date</label>&nbsp;
												<input type="text" class=" datetimepicker border form-control date_dt" 
												name="next_visit_date" id="next_visit_date" value="<?php echo $new_nvDate  ?>">
											</td>
												<td>
													<label for="next_visit" class="control-label">Charge</label>&nbsp;
													<input type="text" name="charge" id="charge" size="10"  
													value="<?php echo $updat->charge; ?>" class="border form-control"></td>
										</tr>
									<!--</tr>-->
									</table>
							</div>
							<?php
						}else{ 
						?>
						<div class="row">
							
							<div class="col-sm-3 ">
								<div class="form-group">
										<label for="advice" class="control-label">Advice</label>&nbsp;
										<select id="advice" name="advice" class="form-control border">
										</select>      
										<input type="text" name="advice_name" value="" id="advice_name" hidden>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group">
								<label for="description" class="control-label">Description</label>&nbsp;
								<textarea type="text" name="description" id="description" value="" class="form-control border note" rows="4"cols="6"></textarea>      
								</div>
							</div>
							<div class="col-sm-10">
								<div class="form-group">
									<label for="test_requested" class="control-label">Tests Requested</label>&nbsp;
									<select class="form-select selectbg" name="test_requested[]" 
									id="test_requested" multiple="multiple" class=" border" style="width:70%">
										</select> 
									<label for="tsts_when" class="control-label">When</label>&nbsp;
									<input type="text" class=" datetimepicker border date_dt mb-4 bp-4" name="tsts_when"  style="height:60%;width:10%" id="tsts_when" value="" >			 
								</div>
							</div>
							<table width="100%" style="" cellpadding="5">
									<tr>
										<td>
												<label for="next_visit" class="control-label">Next Visit</label>&nbsp;
											<input class="border form-control" type="text"  name="next_visit" id="next_visit" value="" >
										</td>
										<td>
										
												<button type="button" class="btn btn-secondary mt-4 day">Days</button>
												<button type="button" class="btn btn-secondary mt-4 week">Weeks</button>
												<button type="button" class="btn btn-secondary mt-4 month">Months</button>
												&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;OR
												
										</td>
										<td>
											<label for="next_visit_date" class="control-label">Next Visit Date</label>&nbsp;
											<input type="text" class=" datetimepicker border form-control date_dt" 
											name="next_visit_date" id="next_visit_date" value="<?php ?>">
										</td>
											<td>
												<label for="next_visit" class="control-label">Charge</label>&nbsp;
												<input type="text" name="charge" id="charge" size="10"  value="" class="border form-control"></td>
									</tr>
								</table>
						</div>
						<?php
						}
						?>

					  <div class="m-t-20 text-center ">
						<?php if (request()->has('caseid'))  {
							?>
							<input type=submit name="up_date" id="up_date" value="Update" class="btn btn-primary" tabindex="3">
							<input type="submit" name="Upd_cancel" value="cancel" id="Upd_cancel" class="btn btn-danger cancel-btn ">
							<!--<input type="button" name="d_pdf" value="Downloade" id="" class="btn btn-primary d_pdf cancel-btn">-->
							<?php
						} else {
							?>
							<input type=submit name="D_save" id="D_save" value="Save" class="btn btn-primary">
						<input type="button" name="Sv_cancel" value="cancel" id="Sv_cancel" class="btn btn-danger cancel-btn ">
							<!--<input type="button" name="d_pdf" value="Downloade" class="btn btn-primary d_pdf cancel-btn">-->
							<?php
						} ?>

					  </div> 
                    </form>
                </div>    
            </div>
			<div id="del_madicine" class="modal fade delete-modal" role="dialog">
				<div class="modal-dialog modal-dialog-centered">
					<div class="modal-content">
						<div class="modal-body text-center">
							<input type="text" id="del_m" name="del_m" value="" hidden="">
							<img src="../../img/sent.png" alt="" width="50" height="46">
							<h3>Are you sure want to delete this madicine ?</h3>
							<div class="m-t-20">
								<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
								<button type="submit" class="btn btn-danger deletemdata" id="del_modal"><a href="#" data-dismiss="modal">Delete</a></button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div> 
    @else
    {{'this this else' }}
 @endif   


    @endsection
@section('scriptdata')
<script>
	$(document).ready(function() {
		//doctor not patient update so back
			$('#Sv_cancel').on('click',function(){
 			   history.back()
 	          })
		
		
		
	    //paymoney reladed pay btn hide and show
			var paymoney = $('#pay_money').val();
			var payPanding = $('#payPanding').val();
			var totalAmount = $('#totalAmount').val();

			if (paymoney > 0 || totalAmount > 0) {
				$("#pay_update").removeAttr('hidden');
				$("#pay_ments").hide();
				$("#pay_cancel").hide();

			} else {
				$("#pay_update").attr('hidden', 'hidden');
				$("#pay_ments").show();
				$("#pay_cancel").show();
			}
		//END
		$(".select").select2();
	 $('.js-example-basic-multiple').select2();
            //next_visit date calculet start
							function setdate(daysum,day){
								 const days = parseFloat(daysum) + parseFloat(day);
									 var d1 = new Date();
							     d1.setDate(days);
								   var daynew = ('0' + d1.getDate()).slice(-2);
								   var mnew= ('0' + (d1.getMonth()+1)).slice(-2);
								   var ynew = d1.getFullYear(); 
					         document.getElementById("next_visit_date").defaultValue = daynew + '-'+mnew + '-' + ynew;
								
							}
		
							$(".day").on("click", function() {
								  var value=	$('#next_visit').val();
								  var d = new Date();
								  var day = d.getDate();
								  
								setdate(value,day)
								})
								
							$(".week").on("click", function() {
								  var value=	$('#next_visit').val();
								  var d = new Date();
								  var day = d.getDate();
								  var daysum = parseFloat(value) * parseFloat(7);
								  	setdate(daysum,day)
								})
								
							$(".month").on("click", function() {
								  var value=	$('#next_visit').val();
								  var d = new Date();
								  var day = d.getDate();
								  var daysum = parseFloat(value) * parseFloat(30);
								  	setdate(daysum,day)
								})
		
			//END	
	
			//datepicker future date diseble start
		        var today = new Date();
		        $('.date_dt').datepicker({
				            dateFormat: 'dd-mm-yy ',
				            autoclose:true,
				            changeMonth: true,
				            changeYear: true,
				             setDate : new Date(),
                    autoclose : true
				          })
            //End datepicker 
		
		
		Loadtype();
    


		//medicine shearing with type selected
		madicinedatatable();
		//type change on meadicin name text box blank
		$("#m_type").on("change", function() {
			$('#med_name').text("");
		})

        var path = "{{ route('getMedicineName') }}";
		    $('#med_name').select2({
                placeholder: 'Select a madicine',
                ajax: {
                url: path,
                dataType: 'json',
                delay: 250,
				data:
				(params) => {
					return {
						type_id: $('#m_type').val(),
						q: params.term,
					}
				},
                processResults: function (data) {
                    return {
                    results: $.map(data, function (data) {
                            return {
                                text: data.name,
                                id: data.id,
                            }
                        })
						
                    };
                },
                tags: true
                }
            });
			
        //Get duration
		var duration_path = "{{ route('getDuration') }}";
		$("#duration").select2({
			ajax: {
				url: duration_path,
				type: 'get',
				data:
				(params) => {
					return {
						q: params.term,
					}
				},
				dataType: 'json',
				processResults: function (data) {
                    return {
                    results: $.map(data, function (data) {
                            return {
                                text: data.name,
                                id: data.id,
                            }
                        })
						
                    };
                },
                tags: true
			},
		})
		// End


		//Get duration
		var disease_path = "{{ route('get_disease') }}";
	    $("#disease_mul").select2({
			placeholder: 'Select a disease',
			ajax: {
				url: disease_path,
				type: 'get',
				dataType: 'json',
				data:
				(params) => {
					return {
						q: params.term,
					}
				},
				processResults: function (data) {
                    return {
                    results: $.map(data, function (data) {
                            return {
                                text: data.diagnosis_name,
                                id: data.diagnosis_name,
                            }
                        })
						
                    };
                },
			},
			tags: true
		});
		// get complaints
		var complaints_path = "{{ route('get_complaints') }}";
	   $("#complaints").select2({
			placeholder: 'Select a complaints',
			ajax: {
				url: complaints_path,
				type: 'get',
				dataType: 'json',
				data:
				(params) => {
					return {
						q: params.term,
					}
				},
				processResults: function (data) {
                    return {
                    results: $.map(data, function (data) {
                            return {
                                text: data.complaints_name,
                                id: data.complaints_name,
                            }
                        })
						
                    };
                },
			},
			tags: true
		});
// End
    	$("#advice").select2({
			placeholder: 'Select a advice',
			ajax: {
				url: "get_advice",
				type: 'get',
				dataType: 'json',
				data:
				(params) => {
					return {
						q: params.term,
					}
				},
				processResults: function (data) {
                    return {
                    results: $.map(data, function (data) {
                            return {
                                text: data.advice_name,
                                id: data.id,
                            }
                        })
						
                    };
                },
			},
			tags: true
		});
		
$("#test_requested").select2({
			placeholder: 'Select a test_requested',
			ajax: {
				url: "get_test_requested",
				type: 'get',
				dataType: 'json',
				data:
				(params) => {
					return {
						q: params.term,
					}
				},
				processResults: function (data) {
                    return {
                    results: $.map(data, function (data) {
                            return {
                                text: data.tests_requested_name,
                                id: data.tests_requested_name,
                            }
                        })
						
                    };
                },
				tags: true
			},
			tags: true
		});


		function Loadtype() {
			// console.log("hjdhf");
			$.ajax({
				type: 'get',
				url: 'typesList',
				data: {},
				catch: false,
				dataType: 'text',
				success: function(data) {
					$('#m_type').append(data);
				}
			})
		}
	$("#advice").on("change", function() {
				$.ajax({
				type: 'get',
				url: 'get_description',
				data: {id:$(this).val()},
				catch: false,
				dataType: 'json',
				success: function(data) {
					console.log(data);
					$('#description').text("");
					$('#description').append(data.advice_description);
					$('#advice_name').val(data.advice_name);
				}
			})
		
	})	
	
// Downlode button on click

     $(document).on("click",".d_pdf",function(){
		var pid = document.getElementById("pid").value;
		var caseid = document.getElementById("case_id").value;
		 location.href = "pdfMedicine?pid="+pid+"&caseid="+caseid;
});	
		

  //data datatable views data
		function madicinedatatable() {
			var pid = document.getElementById("pid").value;
			var base = '{!! route('medicine_prescriptions_add') !!}';
            var url = base+'?pid='+pid ;
			// console.log(url);
			var t = $('#madicine').DataTable({
				processing: true,
				serverSide: false,
				searchable: false,
				orderable: false,
				ajax: {
					url: url,
					type: 'get',
				},
				columns: [
					// {data: 'id'},
					{
						data: ''
					},
					{
						data: 'type'
					},
					{
						data: 'medicine_name'
					},
					{
						data: 'dosage'
					},
					{
						data: 'When1'
					},
					{
						data: 'Frequency'
					},
					{
						data: 'Duration'
					},
					{
						data: 'Notes'
					},
				],
				columnDefs: [{
					"targets": 0,
					"data": "pid",
					"render": function (data, type, row, meta) {
						return "<td class='text-right'><div class='dropdown dropdown-action'><a href='#' class='action-icon dropdown-toggle' data-toggle='dropdown' aria-expanded='false'><i class='fa fa-ellipsis-v'></i></a><div class='dropdown-menu dropdown-menu-right'><button type='button' value='"+row.id+"' class='dropdown-item edit_c'><i class='fa fa-pencil m-r-5'></i> Edit</button><a class='dropdown-item deletemdata' href='#' data-toggle='modal' data-target='#del_madicine' data-dataid="+row.id+"><i class='fa fa-trash-o m-r-5'></i>Delete</a></div></div></td>";
					}
				}]

			});
		}

		//Add_madicins for patient
		$(document).on('click', '.M_Add', function(e) {
			e.preventDefault();
			var pid = document.getElementById("pid").value;
			var type = $('#m_type :selected').text();
			var type_id =$('#m_type').val();
			var med_name = $('#med_name :selected').text();
			var dosage = $('#dosage :selected').text();
			var when = $('#when :selected').text();
			var Frequency = $('#Frequency :selected').text();
			var duration = $('#duration :selected').text()

			var data = {
				'type': type,
				'type_id': type_id,
				'medicine': med_name,
				'dosage': dosage,
				'when': when,
				'Frequency': Frequency,
				'duration': duration,
				'notes': $('#notes').val(),
				'pid': pid,
			}
			// console.log(data);
			$.ajaxSetup({
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				}
			});

			$.ajax({
				type: 'POST',
				url: 'Add_medicin',
				data: data,
				datatype: "datatype",
				success: function(response) {
					$('#notes').val("");
					$("#med_name").text("");
					$("#m_type").val($("#target option:first").val());
					$("#dosage").val($("#target option:first").val());
					$("#when").val($("#target option:first").val());
					$("#Frequency").val($("#target option:first").val());
					$("#duration").text("");
					$('#madicine').DataTable().ajax.reload();

				}
			})

		});


		//Edit madicine for patient
		$(document).on('click', '.edit_c', function(e) {
			e.preventDefault();
			var id = $(this).val();
			var data = {
				'id': id,
			}
			$.ajax({
				type: 'get',
				url: 'selecet_medicins',
				data: data,
				datatype: "datatype",
				success: function(response) {
					console.log(response);
					// var t = JSON.parse(response);
					console.log(response.pid);
					$("#m_type").append('<option value = '+response.type_id+' selected>'+response.type+'</option>');
					$('#duration').append('<option value = '+response.Duration+' selected>'+response.Duration+'</option>');
					$('#med_name').append('<option value = '+response.medicine_name+' selected>'+response.medicine_name+'</option>');
					$('#notes').val(response.Notes);
					$("#dosage").val(response.dosage);
					$("#when").val(response.When1);
					$("#Frequency").val(response.Frequency);
					$('#cid').val(response.id);
					$(".M_Add").hide();
					$(".Medicine_updat").removeAttr('hidden');
					$('#madicine').DataTable().ajax.reload();

				}
			})
		});

		//Eidt select  resonse and  update data
		$(document).on('click', '.Medicine_updat', function(e) {
			e.preventDefault();
		  var type = $('#m_type :selected').text();
			var type_id =$('#m_type').val();
			var med_name = $('#med_name :selected').text();
			var dosage = $('#dosage :selected').text();
			var when = $('#when :selected').text();
			var Frequency = $('#Frequency :selected').text();
			var duration = $('#duration :selected').text()

			var data = {
				'type': type,
				'type_id': type_id,
				'medicine': med_name,
				'dosage': dosage,
				'when': when,
				'Frequency': Frequency,
				'Duration': duration,
				'notes': $('#notes').val(),
				'id': $('#cid').val(),
			}
			$.ajax({
				type: 'post',
				url: 'update_medicine',
				data: data,
				datatype: "datatype",
				success: function(response) {
				$('#notes').val("");
					$("#med_name").text("");
					$("#m_type").val($("#target option:first").val());
					$("#dosage").val($("#target option:first").val());
					$("#when").val($("#target option:first").val());
					$("#Frequency").val($("#target option:first").val());
					$("#duration").text("");
					$(".M_Add").show();
					$(".Medicine_updat").attr('hidden', 'hidden');
					$('#madicine').DataTable().ajax.reload();

				}
			})
		});


	});

	//Start deleted  madcin pricrption
	$(document).on("click", "a.deletemdata", function(e) {
		e.preventDefault();
		delete_m_id = $(this).data('dataid');
		$('#del_m').val(delete_m_id);
	});

	$(document).on("click", "button.deletemdata", function() {
		var id = $('#del_m').val();
		const delet_id = id;

		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		$.ajax({
			type: 'get',
			url: "delete_medicine",
			cache: false,
			data: {
				'id': delet_id
			},
			success: function(Code) {
				$(".deletemdata").attr('data-dismiss', 'modal');
				$('#madicine').DataTable().ajax.reload();
			}
		})
	});
	//End
	
	
	
	
</script>
@endsection