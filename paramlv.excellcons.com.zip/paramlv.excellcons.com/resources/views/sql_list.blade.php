
<html>

@include('css')
    <div class="main-wrapper account-wrapper">
        <div class="account-page">
			<div class="account-center">
				<div class="account-box">
        <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                    </tr>
                    </thead>
                    <tbody>
                    @forelse($users1 as $user)
                    <tr>
                        <th scope="row">{{ $user->id }}</th>
                        <td>{{ $user->firstname }}</td>
                        <td>{{ $user->email }}</td>
                    </tr>
                    @empty
                        <tr>
                            <td>
                                No data found.
                            </td>
                        </tr>
                    @endforelse
                    </tbody>
                </table>
                </div>
			</div>
        </div>
    </div>

    @include('footer')
 
</body>


<!-- login23:12-->
</html>