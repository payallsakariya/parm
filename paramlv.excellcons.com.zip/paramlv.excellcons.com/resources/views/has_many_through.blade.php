
<html>

@include('css')
    <div class="main-wrapper account-wrapper">
        <div class="account-page">
			<div class="account-center ">
				<div class="account-box" style="width:40%; vertical-align:top; height:30%; ">
                  <form method="get" class="form-signin" action="{{ route('view_multiple_cities')}}">
                  <div class="account-logo">
                            <h2 class="card-titel text-center">Has One Through Reletionship</h2>
                        </div>	
                        <div class="form-group">
                            <label for="country">Counties:</label>
                            <select class= "form-control" name= "country" id="country">
                                @foreach($countries as $country)
                                <option value = "{{$country->id }}"> {{$country->name }} </option>
                                @endforeach
                            </select>
                        </div>
                      
                        <div class="form-group text-center">
                        	<input type="submit" name="sumit_country" id="sumit_country"  value="Sumit" class="btn btn-primary account-btn">
                        </div>
                    </form>
                    @isset($cities)
                        <table class="table table-bordered mt-5">
                            <thead>
                                <tr>
                                    <td>#</td>
                                    <td>City Name</td>
                                </tr>
                            </thead> 
                            <tbody>
                                @forelse($cities as $city)
                                <tr>
                                    <td>{{$loop->iteration }}</td>
                                    <td>{{$city->name}}</td>
                                </tr> 
                                @empty
                                <tr>
                                    <td colspan="2" >No Data Found</td>
                                </tr> 
                                @endforelse
                            </tbody>

                        </table>    
                    @endisset
                </div>
			</div>
        </div>
    </div>

    @include('footer')
 
</body>


<!-- login23:12-->
</html>