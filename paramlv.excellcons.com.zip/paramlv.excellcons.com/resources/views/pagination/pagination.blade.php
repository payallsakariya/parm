
<!-- <html> -->
@extends('layouts.user_layout')
<style>
    .btnr {
    position: absolute;
    right: 10px;
    top: 9%;
}
</style>
@section('content')
<!-- @include('css') -->
<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12 mx-auto">
        <div class="card my-3">
            <div class="card-body">
                <h4 class="card-title text-center">All Patient</h4> 
                <a class="btn btn-success " href =" {{route('crud.create')}}">Register</a>
                    <div class="card-body display">
                        <form action="{{ url('/search') }}" method = "Get" class="btnr">
                            <input name="search" id="search" class="form-conterol w-10" type="text" >
                            <input type='submit' class="btn btn-primary" value='Search'>
                            <!-- <button type="button" class="btn btn-primary " type="submit">Search -->
                                <!-- <i class="fas fa-search"></i> -->
                            <!-- </button> -->
                        </form>
                    </div>
                <hr>
                
                @include('flash_data')
                <table class="table tabl-bordered  mt-4">
                <head>
                    <tr>
                        <th class="sorting" data-sorting_type="asc" data-column_name="id" >DI
                            <span id="id_icon"></span>
                        </th>
                        <th class="sorting" data-sorting_type="asc" data-column_name="post_title">Patint Name
                        <span id="post_title_icon"></span>
                        </th>
                        <th>contact</th>
                        <th>Age</th>
                        <th>BloodGroup</th>
                        <th>Birth_date</th>
                        <th>gender</th>
                        <th>Address</th>
                        <th>Medical History</th>
                        <th>Action</th>

                    </tr>
                </head>
                <tbody>
                    @include('pagination.pagination_data')
                </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
   <script type="text/javascript">
       $('#search').on('keyup',function(){
        $value=$(this).val(); 
        if($value){
            $('.alldata').hide();
            $('.searchdata').show();
        }else{
            $('.alldata').show();
            $('.searchdata').hide();
        }
        // alert($value);
            $.ajax({
                type:'get',
                url:'{{URL::to('search')}}',
                data:{'search':$value },
                success:function(data){
                    console.log(data);
                    $('#content').html(data);
                }
            });
       });
    </script>
@endsection
   