@forelse($users as $user)
                    <tr>
                        <!-- <td>{{ $loop->iteration}}</td> -->
                        <td>{{$user->id}}</td>
                        <td>{{$user->pfname.' '.$user->pmname.' '.$user->plname}}</td>
                        <td>{{$user->contact}}</td>
                        <td>{{$user->age.'/'.$user->ym}}</td>
                        <td>{{$user->bloodgroup}}</td>
                        <td>{{$user->pbirth_date}}</td>
                        <td>{{$user->gender}}</td>
                        <td>{{$user->address}}</td>
                        <td>{{$user->medical_history}}</td>
                        <td>
                         <form method='post' action="{{route('crud.destroy',['crud'=>$user->id])}}">
                            @csrf
                            @method('DELETE')
                            <input type='submit' class="btn btn-danger" value='Delete'>
                           </form>
                        </td>

                    </tr>
                    @empty
                    <tr>
                        <td>No Data Funde</td>
                    </tr>    
                    @endforelse    
                        <a class="btn btn-primary" href =" {{route('crud.show',['crud'=>$user->id])}}">Show</a>
                        <a class="btn btn-warning" href =" {{route('crud.edit',['crud'=>$user->id])}}">Update</a>
                      <tr><td>
                      {!! $users->links() !!}</td>
                      </tr>
