<html>
@include('css') 
<body class="mini-sidebar">
	<div class="main-wrapper">
		<div class="header">
			<div class="header-left">
				<a href="index.html" class="logo">
					<img src="../img/logo.png" width="35" height="35" alt=""> <span> PARAM MULTISPECIALITY HOSPITAL
					</span>
				</a>
			</div>
			<a id="toggle_btn" href="javascript:void(0)"><i class="fa fa-bars"></i></a>
			<a id="mobile_btn" class="mobile_btn float-left" href="#sidebar"><i class="fa fa-bars"></i></a>
			<ul class="nav user-menu float-right">
				<li class="nav-item dropdown has-arrow">
					<!--<a href="#" class="dropdown-toggle nav-link user-link" data-toggle="dropdown">-->
						<!--<span class="user-img">-->
						<!--	<img class="rounded-circle" src="../assets/img/user.jpg" width="24" alt="Admin">-->
						<!--	<span class="status online"></span>-->
						<!--</span>-->
					<!--	<span>Admin</span>-->
					<!--</a>-->
					<a class="dropdown-item" href="../login/Logout">Logout</a>
					<!--<div class="dropdown-menu">-->
						<!--<a class="dropdown-item" href="profile.html">My Profile</a>-->
						<!--<a class="dropdown-item" href="edit-profile.html">Edit Profile</a>-->
					<!--	<a class="dropdown-item" href="../login/Logout">Logout</a>-->
					<!--</div>-->
				</li>
			</ul>
			<div class="dropdown mobile-user-menu float-right">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i
					class="fa fa-ellipsis-v"></i></a>
				<div class="dropdown-menu dropdown-menu-right">
					<!--<a class="dropdown-item" href="profile.html">My Profile</a>-->
					<!--<a class="dropdown-item" href="edit-profile.html">Edit Profile</a>-->

					<a class="dropdown-item" href="../login/Logout">Logout</a>
				</div>
			</div>
		</div>
		<div class="sidebar" id="sidebar">
			<div class="sidebar-inner slimscroll">
				<div id="sidebar-menu" class="sidebar-menu">
					<ul>
						<li class="menu-title">Main</li>
						<li class="active">
							<a href="../index/index"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
						</li>
						<!--<li>-->
						<!--	<a href="doctors.html"><i class="fa fa-user-md"></i> <span>Doctors</span></a>-->
						<!--</li>-->
						<li class="submenu">
							<a href="#"><i class="fa fa-wheelchair"></i> <span> Patients </span> <span
								class="menu-arrow"></span></a>
							<ul style="display: none;">
								<?php
								if($_SESSION['type'][0]== 'staff'){
								?>
								<li><a href="../patient/patient">Add Patient</a></li>
								<?php
								}?>
								
								<li><a href="../patient/pending_cases">Pending Cases</a></li>
								<li><a href="../patient/completed">Completed Cases</a></li>


							</ul>
						</li>

						<li class="submenu">
							<a href="#"><i class="fa fa-plus"></i> <span>Admission</span><span
								class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a href="../admission/admission_pending">Pending Admission</a></li>
								<li><a href="../admission/admission_history">Admission History</a></li>

							</ul>

						</li>
						<li class="submenu">
							<a href="#"><i class="fa fa-calendar-check-o"></i> <span>Discharge</span><span
								class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a href="../discharge/discharge_pending">Pending Discharge</a></li>
								<li><a href="../discharge/discharge_history">Discharge History</a></li>
							</ul>

						</li>
								<li class="submenu">
							<a href="#"><i class="fa fa-flag-o"></i> <span> Reports </span> <span
								class="menu-arrow"></span></a>
							<ul style="display:none;">
								<li><a href="../report/All_report?report_type=daily"> Daily Report </a></li>
								<li><a href="../report/All_report?report_type=consultation"> Consultation Report</a></li>
								<li><a href="../report/All_report?report_type=discharge"> Discharge Report </a></li>
							</ul>
						</li>
							<li>
							<a href="../advice/advice_name"><i class="fa fa-medkit"></i> <span>Medicine Add</span></a>
						</li>
						<!--<li>-->
						<!--	<a href="schedule.html"><i class="fa fa-user-md"></i> <span>Doctor-->
						<!--		Schedule</span></a>-->
						<!--</li>-->
						<!--<li>-->
						<!--	<a href="departments.html"><i class="fa fa-hospital-o"></i> <span>Departments</span></a>-->
						<!--</li>-->
						<!--<li class="submenu">-->
						<!--	<a href="#"><i class="fa fa-medkit"></i> <span> Medicine Add </span> <span-->
						<!--		class="menu-arrow"></span></a>-->
						<!--	<ul style="display: none;">-->
						<!--		<li><a href="employees.html">Advice Add</a></li>-->
						<!--		<li><a href="leaves.html">Leaves</a></li>-->
						<!--		<li><a href="holidays.html">Holidays</a></li>-->
						<!--		<li><a href="attendance.html">Attendance</a></li>-->
						<!--	</ul>-->
						<!--</li>-->
						<!--<li class="submenu">-->
						<!--	<a href="#"><i class="fa fa-money"></i> <span> Accounts </span> <span-->
						<!--		class="menu-arrow"></span></a>-->
						<!--	<ul style="display: none;">-->
						<!--		<li><a href="invoices.html">Invoices</a></li>-->
						<!--		<li><a href="payments.html">Payments</a></li>-->
						<!--		<li><a href="expenses.html">Expenses</a></li>-->
						<!--	</ul>-->
						<!--</li>-->


						<!--<li>-->
						<!--	<a href="../assets.html"><i class="fa fa-cube"></i> <span>Assets</span></a>-->
						<!--</li>-->

				

					</li>
				</ul>

			</div>
		</div>
	</div>
	