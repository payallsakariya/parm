
<!-- <html> -->
@extends('layouts.user_layout');
<style>
    .btnr {
    position: absolute;
    right: 10px;
    top: 9%;
}
</style>
@section('content')
<!-- @include('css') -->
<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12 mx-auto">
        <div class="card my-3">
            <div class="card-body">
                <h4 class="card-title text-center">All Patient</h4> 
                <a class="btn btn-success " href =" {{route('crud.create')}}">Register</a>
                    <div class="card-body display">
                        <form action="{{ url('/search') }}" method = "Get" class="btnr">
                            <input name="search" class="form-conterol w-10" type="text" >
                            <input type='submit' class="btn btn-primary" value='Search'>
                            <!-- <button type="button" class="btn btn-primary " type="submit">Search -->
                                <!-- <i class="fas fa-search"></i> -->
                            <!-- </button> -->
                        </form>
                    </div>
                <hr>
                
                @include('flash_data')
                <table class="table tabl-bordered  mt-4">
                <head>
                    <tr>
                        <td>#</td>
                        <td>Patint Name</td>
                        <td>contact</td>
                        <td>Age</td>
                        <td>BloodGroup</td>
                        <td>Birth_date</td>
                        <td>gender</td>
                        <td>Address</td>
                        <td>Medical History</td>
                        <td>Action</td>

                    </tr>
                </head>
                <tbody>
                    @forelse($users as $user)
                    <tr>
                        <!-- <td>{{ $loop->iteration}}</td> -->
                        <td>{{$user->id}}</td>
                        <td>{{$user->pfname.' '.$user->pmname.' '.$user->plname}}</td>
                        <td>{{$user->contact}}</td>
                        <td>{{$user->age.'/'.$user->ym}}</td>
                        <td>{{$user->bloodgroup}}</td>
                        <td>{{$user->pbirth_date}}</td>
                        <td>{{$user->gender}}</td>
                        <td>{{$user->address}}</td>
                        <td>{{$user->medical_history}}</td>
                        <td>
                        <a class="btn btn-primary" href =" {{route('crud.show',['crud'=>$user->id])}}">Show</a>
                        <a class="btn btn-warning" href =" {{route('crud.edit',['crud'=>$user->id])}}">Update</a>
                           <form method='post' action="{{route('crud.destroy',['crud'=>$user->id])}}">
                            @csrf
                            @method('DELETE')
                            <input type='submit' class="btn btn-danger" value='Delete'>
                           </form>
                        </td>

                    </tr>
                    @empty
                    <tr>
                        <td>No Data Funde</td>
                    </tr>    
                    @endforelse
                </tbody> 
                
                </table>
                {!! $users->links() !!}
            </div>
        </div>
    </div>
</div>

@endsection
   