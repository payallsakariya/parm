
@extends('layouts.user_layout');
@section('content')



<!-- @include('css') -->
<div class="page-wrapper">
		    <div class="content">
		        <div class="row" style="padding:30px">
		            <div class="col-lg-8 offset-lg-2">
		                <h4 class="page-title">Patient {{$F_Type}}</h4>
		            </div>
		        </div>
		        <div class="row">
		          <div class="col-lg-8 offset-lg-2">
                  <form  method="post"  action = "{{route('crud.update',['crud'=>$crud->id])}}">
                      @csrf
                      @method('PUT')
			            <div class="row">
			                  <div class="col-sm-4">
			                    <div class="form-group">
			                        <label for="pfname">First Name </label><span class="text-danger pl-2">*</span>
			                        <input class="form-control" type="text" id="pfname" name="pfname" value ="{{$crud->pfname}}" {{$disabled}}>
			                    </div>
                              </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="pmname">Middle Name</label><span class="text-danger pl-2">*</span>
                                        <input class="form-control" type="text" id="pmname" name="pmname"value ="{{$crud->pmname}}" {{$disabled}}>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                <div class="form-group">
                                        <label for="plname">Last Name </label><span class="text-danger pl-2">*</span>
                                        <input class="form-control" type="text" id="plname" name="plname" value ="{{$crud->plname}}" {{$disabled}}>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Date of Birth</label>
                                        <div class="cal-icon">
                                    <input type="text" class="form-control datetimepicker" name="pbirth_date" id="pbirth_date" onchange="mydatepicker()" value ="{{$crud->pbirth_date}}" {{$disabled}} >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label for="age">Age</label>
                                        <input class="form-control" type="number" id="age" name="age" value ="{{$crud->age}}" {{$disabled}}>
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label for="ym">Year/Month</label>
                                        <select class="form-control" id="ym" name="ym" {{$disabled}}>
                                                    <option value="Year">Year</option>
                                                    <option value="Month">Month</option>
                                                    </select>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="contact">Contact </label><span class="text-danger pl-2">*</span>
                                        <input class="form-control" type="text" id="contact" name="contact" value ="{{$crud->contact}}" {{$disabled}}>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                    <label for="bloodgroup">Blood Group</label>
                                                    <select class="form-control" id="bloodgroup" name="bloodgroup" {{$disabled}}>
                                                    <option value="">Plase Select</option>
                                                    <option value="A+" @if($crud->bloodgroup == 'A+') selected @endif>A+</option>
                                                    <option value="A-" @if($crud->bloodgroup == 'A-') selected @endif>A-</option>
                                                    <option value="B+" @if($crud->bloodgroup == 'B+') selected @endif>B+</option>
                                                    <option value="B-" @if($crud->bloodgroup == 'B-') selected @endif>AB+</option>
                                                    <option value="AB-" @if($crud->bloodgroup == 'AB-') selected @endif>AB-</option>
                                                    <option value="O+" @if($crud->bloodgroup == 'O+') selected @endif>O+</option>
                                                    <option value="O-" @if($crud->bloodgroup == 'O-') selected @endif>O-</option>
                                                    </select>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group gender-select">
                                        <label class="gen-label" for="gender">Gender: <span class="text-danger pl-2">*</span></label>
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                            <input type="radio" name="gender" id="gender" class="form-check-input" value="male" @if($crud->gender == 'male') checked @endif {{$disabled}} >Male
                                            </label>
                                        </div>
                                        <div class="form-check-inline">
                                            <label class="form-check-label">
                                                <input type="radio" name="gender" id="gender" class="form-check-input"  value="female" @if($crud->gender == 'female') checked @endif {{$disabled}} >Female
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="religion">Religion</label>
                                        <input class="form-control" type="text" id="religion" name="religion" value ="{{$crud->religion}}" {{$disabled}}>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="postal_code">Postal Code</label>
                                    <input type="text" class="form-control" id="postal_code" name="postal_code" value ="{{$crud->postal_code}}" {{$disabled}}>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="address">Address</label>
                                        <textarea class="form-control" id="address" name="address" value ="" {{$disabled}} rows="3">{{$crud->address}}</textarea>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label for="medical_history">Medical History</label>
                                                <textarea class="form-control" id="medical_history" name="medical_history" 
                                                value ="" {{$disabled}} rows="3">{{$crud->medical_history}}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
			            </div>
                        <div class="m-t-20 text-center" {{$hidden}}>
                            <input type="submit" name="Update" id="Update"  value="Edit Patient" class="btn btn-primary submit-btn mx-auto">
                        </div>

		            </form>
		          </div>
		        </div>
		    </div>
</div>
@endsection
   