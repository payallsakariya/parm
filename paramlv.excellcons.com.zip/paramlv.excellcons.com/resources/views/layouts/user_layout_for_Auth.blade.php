<html>
@include('css')
<style>
	.page-wrapper {
		margin-left: 60px
	}
	.container-max-width {
			max-width: 11220px;
		}
</style>
<body class="mini-sidebar">
	<div class="main-wrapper container-max-width">
		<div class="header">
			<div class="header-left">
				<a href="index.html" class="logo">
					<img src="img/logo.png" width="35" height="35" alt=""> <span> PARAM MULTISPECIALITY HOSPITAL
					</span>
				</a>
		    </div>
			<a id="toggle_btn" href="javascript:void(0);"><i class="fa fa-bars"></i></a>
			<a id="mobile_btn" class="mobile_btn float-left" href="#sidebar"><i class="fa fa-bars"></i></a>
			<ul class="nav user-menu float-right">
				<li class="nav-item dropdown has-arrow">
					<!--<a href="#" class="dropdown-toggle nav-link user-link" data-toggle="dropdown">-->
						<!--<span class="user-img">-->
						<!--	<img class="rounded-circle" src="../assets/img/user.jpg" width="24" alt="Admin">-->
						<!--	<span class="status online"></span>-->
						<!--</span>-->
					<!--	<span>Admin</span>-->
					<!--</a>-->
					<a class="dropdown-item" href="{{ Route('logout') }}">Logout</a>
					<!--<div class="dropdown-menu">-->
						<!--<a class="dropdown-item" href="profile.html">My Profile</a>-->
						<!--<a class="dropdown-item" href="edit-profile.html">Edit Profile</a>-->
					<!--	<a class="dropdown-item" href="../login/Logout">Logout</a>-->
					<!--</div>-->
				</li>
			</ul>
			<div class="dropdown mobile-user-menu float-right">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i
					class="fa fa-ellipsis-v"></i></a>
			   <div class="dropdown-menu dropdown-menu-right">
					<!--<a class="dropdown-item" href="profile.html">My Profile</a>-->
					<!--<a class="dropdown-item" href="edit-profile.html">Edit Profile</a>-->

					<a class="dropdown-item" href="{{ Route('logout') }}">Logout</a>
			   </div>
			</div>
		</div>
		<div class="sidebar" id="sidebar">
			<div class="sidebar-inner slimscroll">
				<div id="sidebar-menu" class="sidebar-menu">
					<ul>
						<li class="menu-title">Main</li>
						<li class="active">
							<a href="{{ Route('index') }}"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
						</li>
						
						<li class="submenu">
							<a href="#"><i class="fa fa-wheelchair"></i> <span> Patients </span> 
							<span class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a href="{{ Route('Register') }}">Add Patient</a></li>
								<li><a href="{{ Route('pendingcases') }}">Pending Cases</a></li>
								<li><a href="{{ Route('logout') }}completed">Completed Cases</a></li>


							</ul>
						</li>

						<li class="submenu">
							<a href="#"><i class="fa fa-plus"></i> <span>Admission</span><span
								class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a href="{{ Route('logout') }}admission_pending">Pending Admission</a></li>
								<li><a href="{{ Route('logout') }}admission_history">Admission History</a></li>

							</ul>

						</li>
						<li class="submenu">
							<a href="#"><i class="fa fa-calendar-check-o"></i> <span>Discharge</span><span
								class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a href="{{ Route('logout') }}discharge_pending">Pending Discharge</a></li>
								<li><a href="{{ Route('logout') }}discharge_history">Discharge History</a></li>
							</ul>

						</li>
						<li class="submenu">
							<a href="#"><i class="fa fa-flag-o"></i> <span> Reports </span> <span
								class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a href="{{ Route('logout') }}/report/All_report?report_type=daily"> Daily Report </a></li>
								<li><a href="../report/All_report?report_type=consultation"> Consultation Report</a></li>
								<li><a href="../report/All_report?report_type=discharge"> Discharge Report </a></li>
							</ul>
						</li>
							<li>
							<a href="../advice/advice_name"><i class="fa fa-medkit"></i> <span>Medicine Add</span></a>
						</li>
					
				    </ul>

			    </div>
            </div>
        </div>
    </div>


    <div class ="container">
      @yield('content')
    </div>    


    <script src="../../js/jquery-3.2.1.min.js"></script>
    <script src="../../js/popper.min.js"></script>
    <script src="../../js/bootstrap.min.js"></script>
    <script src="../../js/jquery.slimscroll.js"></script>
    <script src="../../js/moment.min.js"></script>
    <script src="../js/app.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.2.1/moment.min.js"></script>
      	<!--//datepicker-->
   <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
   <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<!--//dataTables Export and csv downlode use 3 js-->
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
    <!--Export-->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
	<div class ="container">
      @yield('scriptdata')
    </div> 
	</body>
<!-- login23:12-->
</html>