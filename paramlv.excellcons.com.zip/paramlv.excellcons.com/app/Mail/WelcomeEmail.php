<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class WelcomeEmail extends Mailable
{
    use Queueable, SerializesModels;
      protected $emailData; 
    /**
     * Create a new message instance.
     */
    public function __construct($emailData)
    {
        // echo"<pre>";
        // print_r($emailData);exit;
        $this->emailData = $emailData;
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Welcome Email',
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            // view: 'view.name',
        );
    }
    public function build(){
        return $this
        ->from('pvyadav2909@gmail.com','payal')
        ->replyTo('pvyadav2909@gmail.com')
        ->subject($this->emailData['subject'])
        ->with('emailData')
        ->view('login')
        ->attach(public_path('/profiles/demo.pdf'),[
            'as' => 'Demo PDF File.pdf',
            'mime' => 'application/pdf'
        ]);
        // ->text('text');
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
