<?php

namespace App\Http\Controllers\Pagination;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\CrudOperations;

class PaginationController extends Controller
{
  public function index(){
    echo"jfjf";exit;
        $data = DB::table('post')->orderBy('id','asc')->paginate(5);
        return view('pagination.pagination',compact('data'));
   }
   public function get_index()
   {
    echo"jfjf";exit;
   }

}
