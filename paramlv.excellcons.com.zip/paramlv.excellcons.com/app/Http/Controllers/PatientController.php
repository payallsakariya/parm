<?php

namespace App\Http\Controllers;

use App\Http\Requests\StorepatientRequest;
use App\Http\Requests\UpdatepatientRequest;
use App\Models\patient;
use App\Models\doctor;
use Illuminate\Http\Request;

class PatientController extends Controller
{
  public function register(Request $request){
    return view('Template.register');
}

public function store(Request $request){
  //   echo "<pre>";
  //  print_r($request->all());exit;
   $this->validate($request,[
      'fname' =>'required|min:5|max:5|string ',
      'mname' => 'required|string',
      'lname' =>'required|string',
      'dob' => 'date|nullable',
      'age' =>'numeric|nullable',
      'ym' => 'string',
      'phone' =>'required|numeric|nullable',
      'bloodgroup' => 'string|nullable',
      'gender' =>'required|in:male,fmale',
      'religion' => 'string|nullable',
      'postalcode' =>'numeric|nullable',
      'address' => 'string|nullable',
      'mhistory' => 'string|nullable',

   ]);
   // 'email' => 'email|required|unique:crud_opretion(table name),email(fild name)'
    


}


    public function getPatientData(Request $request){
            $data =  doctor::with('doctor')->get()->toArray();
            echo "<pre>";
            print_r($data);
            exit;

        return doctor::get();
   }

   public function belogsToManyPatient(Request $request){
            $data =  doctor::with('belogsToManypatient')->get()->toArray();
            echo "<pre>";
            print_r($data);
            exit;

          return doctor::get();
    }

    public function belogsToManyDoctor(Request $request){
        $data =  patient::with('belogsToManydoctor')->get()->toArray();
        echo "<pre>";
        print_r($data);
        exit;

      return patient::get();
} 

}
