<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Arr;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use App\Models\Login;
use Illuminate\Support\Facades\DB;

class LoginController extends Controller
{


   public function login(Request $request) {
    $getdata =$request->all();
   //   echo "<pre>";
   //   print_r($request->email);
   //   print_r($getdata);exit;
     $this->validate($request,[
        'email' =>'required|email|exists:users,email',
        'pass' => 'required|exists:users,password',
     ]);
      //   $response= Http::post('https://reqres.in/api/register',[
      //       'email' =>$getdata['email'],
      //       'password'=>$getdata['pass']
      //   ]);
      //   $data = Login::where('email', $request->email)->with('type')->first();
      $email=$request->email;
      echo $email;
        $query =  DB::table('users')->where('email',"$email")->get();
        session(['usrs_info'=>$query]);
      //   $allsession=$request->session()->all();
      //   echo "<pre>";
      //   print_r($allsession);
      //   exit;

   return redirect()->route('index')->with('success','User Login success Full');


  }

  public function store(Request $request){
      echo "<pre>";
     print_r($request->all());exit;
     $this->validate($request,[
        'fname' =>'required|min:5|max:5|string ',
        'mname' => 'required|string',
        'lname' =>'required|string',
        'dob' => 'date|nullable',
        'age' =>'numeric|nullable',
        'ym' => 'string',
        'phone' =>'required|numeric|nullable',
        'bloodgroup' => 'string|nullable',
        'gender' =>'required|in:male,fmale',
        'religion' => 'string|nullable',
        'postalcode' =>'numeric|nullable',
        'address' => 'string|nullable',
        'mhistory' => 'string|nullable',

     ]);
     // 'email' => 'email|required|unique:crud_opretion(table name),email(fild name)'
      


  }
}
