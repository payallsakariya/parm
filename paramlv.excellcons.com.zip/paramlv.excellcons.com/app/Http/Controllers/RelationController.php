<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Counties;
use App\Models\City;
use App\Models\Cares;



class RelationController extends Controller
{
    public function viewCities(Request $request){
            $cities = new \stdClass();
            $countries = Counties::get();
        if (isset($request->country)) {
            // $cities = Counties::where('id',$request->county)->with('cities')->get();
            $cities = Counties::where('id', $request->country)->with('cities')->first();
            $cities = $cities->cities;
        }
        return view('reletion', compact('countries', 'cities'));
    }

    public function viewMultipleCities(Request $request){
        $cities = new \stdClass();
            $countries = Counties::get();
        if (isset($request->country)) {
            // $cities = Counties::where('id',$request->county)->with('cities')->get();
            $cities = Counties::where('id', $request->country)->with('multiplecities')->first();
            // echo"<pre>";
            // print_r($cities);
            // exit;
            $cities = $cities->multiplecities;
        }
        return view('has_many_through', compact('countries', 'cities'));
    }

    public function oneToOnePolymorphic(Request $request){
         $car=Cares::with('image')->first()->toArray();
         echo "<pre>";
         print_r($car);
         exit;
    }
    
    public function oneToManyPolymorphic(Request $request){
        
        $car=Cares::with('image')->first()->toArray();
        $customer=Cares::with('images')->first()->toArray();

        echo "<pre>";
        print_r($customer);
        exit;
   }
}
