<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\User_Informetion;
use Illuminate\Support\Arr;
use Illuminate\View\View;
use Illuminate\Support\Str;
use Illuminate\Http\JsonResponse;
use Carbon\Carbon;
class AuthentionController extends Controller
{
    public function login(Request $request){
        return view('Template.login');
    }
    public function logout(Request $request){
        session()->forget('usrs_info');
        return view('Template.login');
    }

    public function login_http(Request $request) {
        $getdata =$request->all();
         $this->validate($request,[
            'email' =>'required|email|exists:users,email',
            'pass' => 'required|exists:users,password',
         ]);
        
          $email=$request->email;
            $login_user =  DB::table('users')->where('email',"$email")->get();
            foreach ($login_user as $value) 
            $type = $value->type;
            session(['usrs_info'=>$type]);
       return redirect()->route('index')->with('success','User Login success Full');
    }

    public function index(Request $request){
        return view('Template.index');
    }

    public function register(Request $request){
        // echo "register";exit;
        return view('Template.register');
     }

    
    public function register_store(Request $request){
        // echo "<pre>";
        // print_r($request->all());exit;
         $this->validate($request,[
            'pfname' =>'required|string ',
            'pmname' => 'required|string',
            'plname' =>'required|string',
            'pbirth_date' => 'date|nullable',
            'contact' =>'required|numeric|nullable',
            'age' =>'required|numeric|nullable',
            'ym' => 'string',
            'bloodgroup' => 'string|nullable',
            'gender' => 'required|in:male,female', 
            'religion' => 'string|nullable',
            'postal_code' =>'numeric|nullable',
            'address' => 'string|nullable',
            'medical_history' => 'string|nullable',
      
         ]);

    
        // date formet change d-m-Y to Y/m/d
            $orgDate = $request['pbirth_date'];
            $date = str_replace('-"', '/', $orgDate);
            $newDate = date("Y-m-d", strtotime($date));
            // echo "<br>orgDate".$orgDate;
            // echo "<br>date".$date;
            // echo "<br>newDate".$newDate;



            $requestData =$request->except(['_token','Submit','pbirth_date']);
        //  SELECT Max(id) as lastid FROM patients;
                $last_id = DB::table('patients')->latest('pid')->first();
                $lastid =$last_id->pid;
                // echo $lastid;
                   if(!empty($lastid)){
                            $lastid=$lastid+1;
                            // $lastid = str_pad($lastid,5, '0', STR_PAD_LEFT);
                            $lastid = Str::padLeft($lastid, 5, '0');
                            $currentyear=  date("y");
                            // echo $lastid;
                            $pmshid='PMSH'.$currentyear.$lastid;
                        }else{
                            $lastid=1;
                            // $lastid = str_pad($lastid,5, '0', STR_PAD_LEFT);
                            $lastid = Str::padLeft($lastid, 5, '0');
                            $currentyear=  date("y");
                            // echo $lastid;
                            $pmshid='PMSH'.$currentyear.$lastid;
                    }

                // echo $pmshid;exit;
                $tbl ='patients';
                $requestData1 = Arr::add($requestData, 'PMSHID' , $pmshid);
                $requestData = Arr::add($requestData1, 'pbirth_date' , $newDate);

                $insert=DB::table('patients')->insert(
                    array($requestData)
                );
                // dd($insert);exit;
               
                // $clms = implode(',', array_keys($requestData));
                // $vals = implode('","', $requestData);
                // $cout = count($requestData);
                // foreach ($requestData as $value)
                //     $q[]='?';
                // $qution = implode(",", $q);
                // echo $sql = 'insert into patients('.$clms.') values  ('.$qution.')';
                // echo '"'.$vals.'"';
                // exit;
                // $insert = DB::insert('insert into patients('.$clms.') values  ('.$qution.')',['"'.$vals.'"']);
                // dd($insert);
         return redirect()->route('index')->with('success','User Insert Successfully');
         
      }

      public function pendingcases(Request $request)
      {
        return view('Template.pending_cases');
     }

    
     public function patient_pending_cases(Request $request): JsonResponse
    {
        // echo $request->filled('q');exit;
        $data = [];
    
        if($request->filled('q')){
            $data = User_Informetion::select("pfname", "pid","pmshid")
                        ->where('pfname', 'LIKE', '%'. $request->get('q'). '%')
                        ->orWhere('pmshid', 'LIKE', '%'. $request->get('q'). '%')
                        ->get();
        }      
        return response()->json($data);
    }

    public function addpendingcases()
    {
        $pid = $_GET['pid'];
       //update Age
        // $sqlsle = DB::table('patients as patients')->select("patients.age","patients.ym",
        // "patients.pbirth_date","patients.updated_at")
        // ->where("pid","=","$pid")->get();
        // foreach ($sqlsle as $value) 
        // $nage = $value->age.'-'.$value->ym;
        // $pbirth_date =$value->pbirth_date;
        // $updated_at =$value->updated_at;
       
         $select_caseid = DB::table('practices')->whereDate('date', date('Y-m-d'))->latest('caseid')->limit(1)->get();
       
            foreach ($select_caseid as $value) 
              $caseid = $value->caseid;

           if(!empty($caseid)){
                    $caseid=$caseid+1;
            }else{
                    $caseid=1;
                }  
                //makeing current date time
                $t=time();
                $timetamp=date("Y-m-d H:i:s",$t);
                $in_data =[
                    'pid' => $pid,
                    'caseid' => $caseid,
                    'date' => $timetamp
                ];
                $insert =DB::table('practices')->insert($in_data);
                header("Location: pendingcases");
    }

    public function pendingcases_json(Request $request): JsonResponse
     {      
                $results = DB::table('patients')
                ->join('practices', 'patients.pid', '=', 'practices.pid')
                ->select(
                    'practices.id',
                    'patients.pid',
                    'patients.pmshid',
                    'patients.contact',
                    DB::raw('upper(concat(patients.pfname, " ", patients.pmname, " ", patients.plname)) as Name'),
                    DB::raw('concat(patients.age, "-", patients.ym) as age'),
                    'patients.gender',
                    'patients.paypending',
                    DB::raw('DATE_FORMAT(practices.date, "%d-%m-%Y") as date'),
                    DB::raw('DATE_FORMAT(practices.date, "%l:%i-%p") as time'),
                    'practices.caseid',
                    'practices.payment'
                )
                ->whereDate(DB::raw('practices.date'), '=', now()->toDateString())
                ->whereNull('practices.charge')
                ->where('practices.status', '=', 'consult')
                ->orderByDesc('practices.date')
                ->get();
                $data['data'] =$results;
          
                return response()->json($data);
    }
    public function medicine_view(Request $request){
        return view('Template.medicine');
    }

    public function Doctor_EditPatient(Request $request)
     {
        $case_id = $_POST['case_id'];
        $data = session ()->get ( 'usrs_info' );
        $results = DB::table('patients')
            ->join('practices', 'patients.pid', '=', 'practices.pid')
            ->select(
                'patients.pid',
                'patients.pmshid',
                'patients.contact',
                DB::raw('upper(concat(patients.pfname, " ", patients.pmname, " ", patients.plname)) as Name'),
                DB::raw('concat(patients.age, "-", patients.ym) as age'),
                'patients.gender',
                DB::raw('DATE_FORMAT(practices.date, "%Y-%m-%d") as date'),
                DB::raw('DATE_FORMAT(practices.date, "%l:%i-%p") as time'),
                'practices.caseid'
            )
            ->whereDate(DB::raw('practices.date'), '=', now()->toDateString())
            ->where('practices.caseid', '=', $case_id)
            ->get();
        session(['DEditpatient'=>$results]);
        if($_POST['D_save']){
        //             echo "<pre>";
        // print_r($request->all());
        
         $imp_disease = implode(',',$request['disease_mul']);
         $imp_complaint = implode(',',$request['complaints']);
         $imp_test_requested = implode(',',$request['test_requested']);
         $tsts_when_date = str_replace('-"', '/', $request['tsts_when']);
         $new_tsts_when_Date = date("Y/m/d", strtotime($tsts_when_date));
         $next_visit_date = str_replace('-"', '/', $request['next_visit_date']);
         $new_next_visit_date = date("Y/m/d", strtotime($next_visit_date));
         $pid=$request['pid'];
         $caseid=$request['case_id'];

         echo "<pre>";
        //  print_r($imp_disease);
        //  echo"<br>";
        //  print_r($imp_complaint);
        //  echo"<br>";
        //  print_r($imp_test_requested);
        //  echo"<br>";
        //  echo $new_tsts_when_Date;
        //  echo"<br>";
        //  echo $new_next_visit_date;
        //  echo"<br>";
        //  echo $pid;
        //  echo"<br>";
        //  echo $caseid;

         $D_udate=[
            'charge' => $request['charge'],
            'medicines' => $request['medicines'],
            'disease' => $imp_disease,
            'complaints' =>$imp_complaint,
            't' => $request['t'],
            'height' => $request['height'],
            'weight' => $request['weight'],
            'bp' => $request['bp'],
            'pulse' => $request['pulse'],
            'bmi' => $request['bmi'],
            'wh' => $request['wh'],
            'spo2' => $request['spo2'],
            'advice_name' => $request['advice_name'],
            'description' => $request['description'],
            'test_requested' => $imp_test_requested,
            'tsts_when_date' => $new_tsts_when_Date,
            'next_visit_date' => $new_next_visit_date,
            'next_visit' => $request['next_visit'],
            'status' => 'payment'
            ];
// print_r($D_udate);
        
$up_data=DB::table('practices')
->where('caseid', $caseid) 
->whereDate(DB::raw('practices.date'), '=', now()->toDateString())
->update($D_udate);
// dd($up_data);
// echo"jhdjhf";
// $data = session ()->get ( 'DEditpatient' ); 
// echo"<pre>";
// print_r($data);
if($up_data == '0'){
    $data = session ()->get ( 'DEditpatient' ); 
    foreach($data as $vals)
    $name= $vals->Name;
    $caseid= $vals->caseid;


}
        exit;
        }

        return redirect()->route('medicine_view');
     }

       
     public function typesList(Request $request)
     {
        // echo "typesList";
        $medicineTypes =DB::table('medprack_picklist_medicine_types')->select('*')->get();
        $html ='';
        foreach ($medicineTypes as $value){
            
            $html .="<option value='".$value->id ."'>". $value->name ."</option>";
            
        }
        echo $html;
        
     }
     
     public function getMedicineName(Request $request): JsonResponse
     {
        $stateData = DB::table('medprack_picklist_madicin_name')->select("*")
        ->where('name', 'LIKE', '%'. $request->get('q'). '%')
        ->where('type_id', '=', $request->get('type_id'))
        ->get();
        return response()->json($stateData);
     }

     public function getDuration(Request $request): JsonResponse
     {
        
        $value = $request->get('q');
        // echo $value;exit;
        $name=['Day','Weeks','Months','Years'];
        for($i=0;$i<=3;$i++){
            $arr[]= ['id'=> $value.' '.$name[$i],'name' => $value.' '.$name[$i]];
        }
        // echo"<pre>";
        // print_r($arr);exit;
        return response()->json($arr);

     }
     public function Add_medicin(Request $request): JsonResponse
     {
            $t=time();
            $timetamp=date("Y-m-d",$t);
        $insert_data = [
            'pid' => $request->get('pid'),
            'type' => $request->get('type'),
            'type_id' => $request->get('type_id'),
            'medicine_name' => $request->get('medicine'),
            'dosage' => $request->get('dosage'),
            'When1' => $request->get('when'),
            'Frequency' => $request->get('Frequency'),
            'Duration' => $request->get('duration'),
            'Notes' => $request->get('notes'),
            'Date' => $timetamp
          ];
        //  echo "<pre>";
        //  print_r($insert_data);exit;
        $insert=DB::table('prescriptions')->insert(
        array($insert_data)
        );
            // dd($insert);exit;
        
            return response()->json($insert);
     }
     public function medicine_prescriptions_add(Request $request): JsonResponse
    { 
        $pid=$_GET['pid'];

        $prescriptions = DB::table('prescriptions')->where('pid', $pid)
        ->whereDate('date', now()->toDateString())
        ->get();
        $data['data'] =$prescriptions;
          
        return response()->json($data);
    }
    public function selecet_medicins(Request $request): JsonResponse
    {
        $mid=$request->get('id');
        $medicine_update = DB::table('prescriptions')->where('id', $mid)
        ->get();

        $data=$medicine_update[0];
        // echo "<pre>";
        // print_r($medicine_update);

        return response()->json($data);
      
    }
    
    public function update_medicine(Request $request): JsonResponse
    {

        $mid=$request->get('id');
     

        $upd_m_data=DB::table('prescriptions')
        ->where('id', $mid) 
        ->update(array('type' => $request->get('type'),
                'type_id' => $request->get('type_id'),
                'medicine_name' => $request->get('medicine'),
                'dosage' =>$request->get('dosage'),
                'When1' => $request->get('when'),
                'Frequency' => $request->get('Frequency'),
                'Duration' => $request->get('Duration'),
                'Notes' => $request->get('notes'))
            );
            return response()->json($upd_m_data);
                                   

    }
    
    public function delete_medicine(Request $request): JsonResponse
    {
        $mid=$request->get('id'); 
        // echo $mid;exit;
       $delete= DB::table('prescriptions')->where('id', $mid)->delete();
        return response()->json($delete);
    }

    public function get_disease(Request $request): JsonResponse
    {
        $value=$request->get('q');
        $diseaseData = DB::table('medprack_picklist_diagnosis')
        ->select('*')
        ->where('diagnosis_name', 'LIKE', '%'.$value. '%')
        ->get();
       return response()->json($diseaseData);
 	 
    }
    public function get_complaints(Request $request): JsonResponse
    {

        $value=$request->get('q');
        $complaintsData = DB::table('medprack_picklist_complaints')
        ->select('*')
        ->where('complaints_name', 'LIKE', '%'.$value. '%')
        ->get();
       return response()->json($complaintsData);
    }
    public function get_advice(Request $request): JsonResponse
    {

        $complaintsData = DB::table('medprack_picklist_advice')
        ->select('*')
        ->where('advice_name', 'LIKE', '%'.$request->get('q'). '%')
        ->get();
       return response()->json($complaintsData);
    }
    public function get_description(Request $request): JsonResponse
    {
        $adviceData = DB::table('medprack_picklist_advice')
        ->select('*')
        ->where('id',$request->get('id'))->get();

        // print_r($adviceData);exit;
       return response()->json($adviceData[0]);
    }

    public function get_test_requested(Request $request): JsonResponse
    {
        $tests_requestedData = DB::table('medprack_picklist_tests_requested')
        ->select('*')
        ->where('tests_requested_name', 'LIKE', '%'.$request->get('q'). '%')
        ->get();

       return response()->json($tests_requestedData);
    }

}
