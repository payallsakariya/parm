<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class QueryBuilderController extends Controller
{
 public function retrieveMethods(Request $request){
    //get method
    // $users1= DB::table('users')->get();
    // return view('sql_queries', compact('users1'));
    $users1= DB::table('users')
    ->where('id','=','2')
    ->first();
    //get id=1 value
    $users1= DB::table('users')->find('1');
    //key value per data
    $users1= DB::table('users')
    ->where('id','>','0')
    ->pluck('email','firstname');
    echo"<pre>";
    print_r($users1);
    exit;
 }

 public function aggregateMethods(){
   $pen= DB::table('test_method')
   ->where('prod_code','PEN')
   ->count();
   echo"Total PEN Is :-".$pen."<hr>";

   $Max = DB::table('test_method')-> Max('quantity');
     echo" Max  quantity Is :-".$Max."<hr>";

     $Min = DB::table('test_method')-> min('quantity');
     echo" Min  quantity Is :-".$Min."<hr>";
//SUM Method 
     $sum = DB::table('test_method')-> sum('quantity');
     echo"SUM Method <br> quantity sum  Is :-".$sum."<hr>";

     $AVG= DB::table('test_method')-> avg('quantity');
     echo"AVGS Method <br> quantity avg  Is :-".$AVG."<hr>";

     $exist= DB::table('test_method')-> where('quantity','>','100')->exists();
         if($exist){
            echo "Condition Ture";
         }else{
            echo "Condtion False";
         }

      $noexist= DB::table('test_method')-> where('quantity','>','100')->doesntExist();
         if($noexist){
            echo "<hr><br>Condition Ture";
         }else{
            echo "<hr><br>Condtion False";
         }
   }


   public function selectStatements(){
     $users1= DB::table('users')->select('email','firstname')->get();
   //   session()->now('data get success full');
    return view('select_statement',compact('users1'));
        
   }

   public function distinct(){
      $code= DB::table('test_method')
      ->distinct()
      ->get(['prod_code']);
      return view('distince_method',compact('code'));
      // echo"<pre>";
      // print_r($code);
      // exit;
   }
   public function joinStatements(Request $request){
      $datajon= DB::table('orders')->select('name','e_name');
      $datajon =$datajon->join('employee','employee.order_id','=','orders.order_id');
      $datajon=$datajon->get();
      // $datajon=$datajon->toSql();


      $data= DB::table('orders')->select('name','e_name');
      $data =$data->rightJoin('employee','employee.order_id','=','orders.order_id');
      $data=$data->get();
      // $data=$data->toSql();


      $dataleft= DB::table('orders')->select('name','e_name');
      $dataleft =$dataleft->leftJoin('employee','employee.order_id','=','orders.order_id');
      $dataleft=$dataleft->get();
      // $data=$data->toSql();


      $data= DB::table('orders');
      $data =$data->crossJoin('employee');
      $data=$data->get();
      // $data=$data->toSql();
//MULTIJOIN
      // $data= DB::table('orders')->select('name','e_name');
      // $data =$data->leftJoin('employee','employee.order_id','=','orders.order_id');
      // $data =$data->rightJoin('employee','employee.order_id','=','orders.order_id');
      // $data=$data->get();
      // $data=$data->toSql();

// $prod=DB::table('orders');
// $employee=DB::table('employee')->union($prod)->toSql();

      // echo"<pre>";
      // print_r($datajon);
      // echo "<hr><br>";
      // print_r($data);
      // echo "<hr><br>";
      // print_r($dataleft);
      echo "<hr><br>";
      print_r($employee);

      exit;
      
   }
   public function whereStatement(Request $request){

      $patients=DB::table('patients')->where('pid',1)->get();
      $patients=DB::table('patients')->where('pid','<>',1)->get();
      $patients=DB::table('patients')->where('pfname','like','d%')->get();
//AND
      $patients=DB::table('patients')
      ->where('pid','>',10)
      ->where('pfname','like','d%')
      ->get();
//OR
      $patients=DB::table('patients')
      ->where('pid','>',10)
      ->orwhere('pfname','like','rishi%')
      ->get();
//where between
      $patients=DB::table('patients')
      ->where('pid','>',10)
      ->whereBetween('date',[""])
      ->get();
session()->now('now','success');

      return view('select_patients',compact('patients'));

   }


 }

