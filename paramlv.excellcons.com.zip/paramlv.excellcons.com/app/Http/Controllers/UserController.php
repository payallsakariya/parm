<?php

namespace App\Http\Controllers;

use Illuminate\Support\Arr;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Str;
use App\Models\User;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Mail;
use App\Mail\WelcomeEmail;
use Illuminate\Support\Facades\Artisan;
// use App\Http\Controllers\WelcomeEmail;

class UserController extends Controller
{

   

    public function arrayHelpers()
    {
        $arr = [
            'Core PHP',
            'Advanced PHP',
            'React JS',
            'Laravel',
            'Wordpress',
            'Angular JS'
        ];

        $second_arr = [
            'S90',
            '5 series',
            'Octavia',
            'Superb',
            'V90'
        ];

        $str = 'Welcome to LearnVern.';
        $obj = new \stdClass();
        $collection = new Collection;
        $accessible = Arr::accessible($collection);
        $arr_add = Arr::add($arr, '6' , 'CodeIgniter');
        $arr_collapse = Arr::collapse([$arr, $second_arr]);
        $arr_cross_join = Arr::crossJoin($arr, $second_arr);
        $array = ['products' => ['desk' => ['price' => 100]]];

        $isAccessible = Arr::accessible(['a' => 1, 'b' => 2]);
        $flattened = Arr::dot($array);
        $undot_arr = Arr::undot($flattened);
        // echo "<pre>";
        //var_dump($accessible);
        // print_r($undot_arr);

    }
    public function pathHelpers(){
                $path=app_path('/Http/Controllers');
                echo "<pre>";
                print_r($path);exit;


                $str="this is laravel";
                $str=str::of($str)->lower()->upper()->ucfirst();
                // echo $str;
        $action=action([UserController::class,'arrayHelpers']);
        echo $action;
    }

public function customHelpers(){
   //helper 1     
        $date= "2023-12-25 13:03:23";
        $format ='d-m-Y';
        $data = formatDate($date,$format);
  //helper 2
        $filename='attachment.php';
        $url=getFileUrl($filename);

   //helper 3
   $startdate ='2020-01-01';
   $enddate='2020-01-15';
   $startdate ='2020-01-01';
   $dareArr=getdateBetween($startdate,$enddate);
//    $dareArr = ;
        echo "<pre>";
        print_r($dareArr);


    }

    public function urlHelper(){
        // $action =action(UserController::class,'create');
        $url = action([UserController::class, 'customHelpers']);
        echo"<pre>";
        print_r($url);exit;
    }

 function httpClient(){
    $respons=Http::get("https://reqres.in/api/users");
    return $respons;
 }  
 public function sessionMethod(Request $request){
    //stor data in session
    //request instance 
    $request->session()->put('name','payal');
    //glober helper
    session(['sub'=>'php']);
    //retriv data
    $data=$request->session()->get('name','NULL DATA');
    $sub=session('sub','No data');
    $allsession=$request->session()->all();
    echo "<pre>";
    print_r($allsession);
    echo "<br>";
    print_r($sub);
    exit;
 }

 public function getUsers(User $users){
    echo "<pre>";
    print_r($users);exit;

 }

 public function localization(Request $request){
   $setlocale = App::setlocale('hi');
   // echo $setlocale;
    echo __('welcome');

    echo "<hr>";
    echo __('messages.discription',['language' => 'PHP']);
    echo "<hr>";
    echo trans_choice('messages.courses',3);
 }

 public function changeLanguage(Request $request, $language)
    {
// echo "<pre>";
// print_r($language);
// print_r(Config::get('languages'));
// exit;
// Arr::exists($language, Config::get('languages'))
        if (Arr::exists(Config::get('languages'),$language)) {
            session(['appLanguage' => $language]);
            $allsession=$request->session()->all();
    // echo "<pre>";
    // print_r($allsession);
    // echo "<br>";
    // print_r($sub);
    // exit;
        }
        return redirect()->back();
    }

    // Email

    public function sendEmail(Request $request){
        $emailData =[
            'subject' => 'Good you try to learning lavavel',
            'body' => 'you learning lavavel email sending.this is the classic example of sending email useing laravel commad',
            'tagline' => 'LEARN ANY COURSE  FOR IN YOUR OWN LANGUAGE UPDATED.'
        ];
        // echo "hgfjsg";exit;
        Mail::to('payalsakariya1721@gmail.com')
        // ->cc('rahi013shah@gmail.com')
        ->send(new WelcomeEmail($emailData));
    }

    public function exceuteCommand(Request $request){
      $data =  Artisan::call('send:ind_email');
      return $data;
    }

}
