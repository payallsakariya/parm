<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class databascontroller extends Controller
{
    

    public function checkconnection(Request $request){
        try{
            DB::connection()->getPDO();
            echo 'connction successfully :- '.DB::connection()->getDatabaseName();
        }catch(\Exceptoin $ex){
            echo 'databse connecton failed.'.$ex->getMessage();
    
        }
    }

    public function sqlQueries(Request $request){
        try {
            $useres1= DB::select('SELECT * FROM `users`');
            return view('sql_list',compact(useres1));
            // echo "<pre>";
            // print_r($users);
            // exit;
        } catch (\Throwable $th) {
          echo $th->getMessage();
        }
    }
}

    

