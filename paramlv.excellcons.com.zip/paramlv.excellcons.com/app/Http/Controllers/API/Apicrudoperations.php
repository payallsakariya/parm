<?php

namespace App\Http\Controllers\API;

use App\Models\CrudOperations;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\View;
use App\Events\WelcomeEmail;


class Apicrudoperations extends Controller
{
    public function index(Request $request) :JsonResponse
    {
        $requestData = $request->all();
        // echo"<pre>";
        // print_r($requestData);
        // exit;
        $users =CrudOperations::paginate('2');
       
        return response()->json(['status' => 200,'message' => 'Data successfull.','data' => $users]);
    }

    public function create()
    {

        return view('patient.register');
    }

    public function store(Request $request)
    {
        try {
            $requestData =$request->all();
            // echo "<pre>";
            // print_r($requestData);exit;
         
          $store =CrudOperations::create($requestData);
          event(new WelcomeEmail($store));
        return response()->json(['status' => 200,'message' => 'Data successfull.','data' => $store]);

        } catch (\Exception $ex) {
            return response()->json(['status' => 500,'message' => $ex->getMessage(),'data' => null]);

        }

    }
    public function edit(CrudOperations $apicrud)
    {
        try {
            $disabled='';
            $hidden='';
            $F_Type= 'Edit';

        return response()->json(['status' => 200,'message' => 'Data successfull.','data' => ['user_data' => $apicrud,'disabled' => $disabled,'hidden' => $hidden,'F_Type' => $F_Type]]);

        } catch (\Exception $ex) {
            return response()->json(['status' => 500,'message' => $ex->getMessage(),'data' => null]);

        }

    }

    public function update(Request $request, CrudOperations $apicrud)
    {
        try {
        // echo"<pre>";
        // print_r($request->all());
        // exit;
        $apicrud->pfname = $request->pfname ?? $apicrud->pfname ;
        $apicrud->pmname = $request->pmname ?? $apicrud->pmname ;
        $apicrud->plname = $request->plname ?? $apicrud->plname ;
        $apicrud->pbirth_date = $request->pbirth_date ?? $apicrud->pbirth_date ;
        $apicrud->age = $request->age ?? $apicrud->age ;
        $apicrud->ym = $request->ym ?? $apicrud->ym ;
        $apicrud->contact = $request->contact ?? $apicrud->contact ;
        $apicrud->bloodgroup = $request->bloodgroup ?? $apicrud->bloodgroup ;
        $apicrud->gender = $request->gender ?? $apicrud->gender ;
        $apicrud->religion = $request->religion ?? $apicrud->religion ;
        $apicrud->postal_code = $request->postal_code ?? $apicrud->postal_code ;
        $apicrud->address = $request->address ?? $apicrud->address ;
        $apicrud->medical_history = $request->medical_history ?? $apicrud->medical_history ;
        $apicrud->save();
        return response()->json(['status' => 200,'message' => 'Data update successfull.','data' => ['user_data' => $apicrud]]);

    } catch (\Exception $ex) {
        return response()->json(['status' => 500,'message' => $ex->getMessage(),'data' => null]);

    }

    }

    public function destroy(CrudOperations $apicrud)
    {
        try{
        //  echo"<pre>";
        // print_r($crud);
        // exit;
        $apicrud->delete();
        // return redirect()->route('crud.index')->with('danger','User Delete Successfully');
        return response()->json(['status' => 200,'message' => 'Data Delete successfull.','data' => ['user_data' => $apicrud]]);

        } catch (\Exception $ex) {
            return response()->json(['status' => 500,'message' => $ex->getMessage(),'data' => null]);

         }
    }

}
