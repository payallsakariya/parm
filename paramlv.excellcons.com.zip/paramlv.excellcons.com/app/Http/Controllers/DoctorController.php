<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoredoctorRequest;
use App\Http\Requests\UpdatedoctorRequest;
use App\Models\doctor;
use Illuminate\Http\Request;

class DoctorController extends Controller
{
    public function getDoctorData(Request $request){
        $data =  doctor::with('patient')->get()->toArray();
        echo "<pre>";
        print_r($data);
        exit;
        
                return doctor::get();
           }

         
}
