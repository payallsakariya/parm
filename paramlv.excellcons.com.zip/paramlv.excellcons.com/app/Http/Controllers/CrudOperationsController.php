<?php

namespace App\Http\Controllers;

use App\Models\CrudOperations;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\View;
use App\Events\WelcomeEmail;
use Illuminate\Support\Facades\DB;

class CrudOperationsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        
        // $users =CrudOperations::Paginate('5');
        $users =CrudOperations::Paginate('5');
        //   if(request()->has('search')){
        //     $users= $users->where('pfname','like', '%'. request()->get('search','').'%');
        //   }
        
        // $users =CrudOperations::cursorPaginate('5');

        // echo"<pre>";
        // print_r($users);
        // exit;
       return view('patient.patint_list',compact('users'));
    //    return view('patient.index',compact('users'));

    }

    public function search(Request $request){
    //       echo"<pre>";
    //   print_r($request->all());exit;
    //   $search_tex=$_GET['search'];
    //   $users=CrudOperations::where('pfname','like', '%'. $search_tex.'%')->simplePaginate('5');

    $output="";
      $users=CrudOperations::where('pfname','like', '%'. $request->search.'%')->simplePaginate();
    //   echo"<pre>";
    //     print_r($users);exit;
          foreach($users as $user){
            $output .=
             '<tr>
             <td>'.$user->id.'</td>
             <td>'.$user->pfname.' '.$user->pmname.' '.$user->plname.'</td>
            <td>'.$user->contact.'</td>
            <td>'.$user->age.'/'.$user->ym.'</td>
            <td>'.$user->bloodgroup.'</td>
            <td>'.$user->pbirth_date.'</td>
            <td>'.$user->gender.'</td>
            <td>'.$user->address.'</td>
            <td>'.$user->medical_history.'</td>
            <td>'.
            // '<a class="btn btn-primary" href ="{{route("crud.destroy",["crud"=>$user->id])}}">Delete</a>'
            '<a class="btn btn-primary" href ="/delete?delete='.$user->id.'">'.'Delete</a>'
            // '<a class="btn btn-primary" href ="/crud/'.$user->id.'">'.'destroy</a>'

            .'</td>
            </tr>';
          }
          $output.='<tr><td>
          {!! '.$users->links() .'!!}
          </td></tr>';

        //   '<a class="btn btn-primary" href ="{{route("crud.destroy",["crud"=>$user->id])}}">Delete</a>'
          
         
          return response($output);
    //   return view('patient.patint_list',compact('users'));
     
    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {

        return view('patient.register');
    }



    // public function urlHelper(){
    //     $action1 =action([CrudOperationsController::class,'create']);
    //     // $url = action([CrudOperationsController::class, 'create']);
    //     echo"<pre>";
    //     print_r($action1);exit;
    // }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $requestData =$request->except(['_token','Submit']);
        $store =CrudOperations::create($requestData);
        // event(new WelcomeEmail($store));
        return redirect()->route('crud.index')->with('success','User Insert Successfully');
        //  echo "<pre>";
        //   print_r($store);exit;

    }

    /**
     * Display the specified resource.
     */
    public function show(CrudOperations $crud)
    {
        $disabled='disabled';
        $hidden='hidden';
        $F_Type= 'Show';
         return view('patient.show_patient',compact('crud','disabled','hidden','F_Type'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(CrudOperations $crud)
    {
        $disabled='';
        $hidden='';
        $F_Type= 'Edit';
        return view('patient.show_patient',compact('crud','disabled','hidden','F_Type'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, CrudOperations $crud)
    {
        // echo"<pre>";
        // print_r($request->all());
        // exit;
        $crud->pfname = $request->pfname ?? $crud->pfname ;
        $crud->pmname = $request->pmname ?? $crud->pmname ;
        $crud->plname = $request->plname ?? $crud->plname ;
        $crud->pbirth_date = $request->pbirth_date ?? $crud->pbirth_date ;
        $crud->age = $request->age ?? $crud->age ;
        $crud->ym = $request->ym ?? $crud->ym ;
        $crud->contact = $request->contact ?? $crud->contact ;
        $crud->bloodgroup = $request->bloodgroup ?? $crud->bloodgroup ;
        $crud->gender = $request->gender ?? $crud->gender ;
        $crud->religion = $request->religion ?? $crud->religion ;
        $crud->postal_code = $request->postal_code ?? $crud->postal_code ;
        $crud->address = $request->address ?? $crud->address ;
        $crud->medical_history = $request->medical_history ?? $crud->medical_history ;
        $crud->save();

        return redirect()->route('crud.index')->with('success','User Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CrudOperations $crud)
    {
        //  echo"<pre>";
        // print_r($crud);
        // exit;
        $crud->delete();
        return redirect()->route('crud.index')->with('danger','User Delete Successfully');
    }

    public function Delete( Request $request)
    {
        // echo "kjfkjf";
        //  echo"<pre>";
        // print_r($request->delete);
        // exit;
        $crud=$request->delete;
        DB::table('crud_operations')->where('id', $crud)->delete();
        // $crud->delete();
        return redirect()->route('crud.index')->with('danger','User Delete Successfully');
    }
}
