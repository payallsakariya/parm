<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DatabaseController extends Controller
{
    public function checkDbConnection(Request $request)
    {
        try {
            DB::connection()->getPDO();
            echo 'Database Name:- ' . DB::connection()->getDatabaseName();
        } catch (\Exception $ex) {
            echo 'Database connection failed. Error:- ' . $ex->getMessage();
        }
    }

    public function sqlQueries(Request $request)
    {
        try{

            // Insert Method
            //$insUser = DB::insert("INSERT INTO customers (name, email) values (?, ?)", ['Vicky', 'vicky@mail.com']);
            //session()->flash('success', 'User data inserted successfully!');

            // Update Method
            //$updUser = DB::update('UPDATE customers set email = "vicky_updated@mail.com" WHERE id = ?', [14]);
            //session()->flash('warning', 'User data updated successfully!');

            // Delete Method
            //session()->flash('danger', 'User data deleted successfully!');
            //$delUser = DB::delete('DELETE FROM customers  WHERE id = ?', [16]);

            // Statement Method
            //$statement = DB::statement('ALTER TABLE customers ADD designation varchar(40) NOT NULL');

            // Unprepared Method
            // $unprepStatement = DB::unprepared('INSERT INTO customers (name, email, designation) values ("Komal","komal@mail.com", "Senior HR")');
            // session()->flash('success', 'User data inserted successfully!');

            // Select Method
            //session()->now('now', 'Users data retrieved successfully!');
            $users1 = DB::select('SELECT * FROM users');
            return view('sql_queries', compact('users1'));
        } catch (\Exception $ex) {
            return $ex->getMessage();
        }
    }

}
