<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\App;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Arr;

class setlanguage
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        
        // if (session()->has('appLanguage') && Arr::exists(Config::get('languages'),session()->get('appLanguage'))) {
        //     App::setLocale(session()->get('appLanguage')); 
        // } else {
        //     // echo "bhdgfh";exit;
        //     App::setLocale('en');
        // }
        return $next($request);
    }
}
