<?php 
function formatDate($date, $format ='d-m-Y h:i:A'){
    if(!empty($date)){
        return Carbon\Carbon::parse($date)->format($format);
    }
    return NULL;
}
function getFileUrl($filename,$directory='profile'){
    return url('Storage/'.$directory.'/'.$filename);
}

function getdateBetween($startdate,$enddate){
    $period= new \DatePeriod(
        new \DateTime($startdate),
        new \DateInterval('P1D'),
        new \DateTime($enddate)
    );
    $dates=[];
    foreach($period as $key =>$value){
        $dates []=$value->format('d-m-Y');
    }
    return $dates;

    
}
?>