<?php

namespace App\Listeners;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use App\Mail\WelcomeEmail;
use App\Models\User;

class SendWelcomeEmail
{
    /**
     * Create the event listener.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     */
    public function handle(object $event): void
    {
        $user =$event->store;
        $email_add = ((string) $user->address);
        // echo $email_add;exit;
        $emailData =[
            'subject' => 'Good you try to learning lavavel',
            'body' => 'you learning lavavel email sending.this is the classic example of sending email useing laravel commad',
            'tagline' => 'LEARN ANY COURSE  FOR IN YOUR OWN LANGUAGE UPDATED.'
        ];
        Mail::to($email_add)
        // ->cc('rahi013shah@gmail.com')
        ->send(new WelcomeEmail($emailData));
        // echo "hgfjsg";exit;
        // Mail::to((string) $user->address)
    //    echo "<pre>";
    //    print_r($email_add);
    //    exit;
    }
}
