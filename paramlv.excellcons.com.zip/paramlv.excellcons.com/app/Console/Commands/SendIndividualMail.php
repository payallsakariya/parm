<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use App\Mail\WelcomeEmail;
use App\Models\User;

class SendIndividualMail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'send:ind_email';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'For sending individual email';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $emailData =[
            'subject' => 'Good you try to learning lavavel',
            'body' => 'you learning lavavel email sending.this is the classic example of sending email useing laravel commad',
            'tagline' => 'LEARN ANY COURSE  FOR IN YOUR OWN LANGUAGE UPDATED.'
        ];
        Mail::to('pvyadav2909@gmail.com')
        ->send(new WelcomeEmail($emailData));
    }
}
