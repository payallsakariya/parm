<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use App\Mail\WelcomeEmail;
use App\Models\User;

use Illuminate\Support\Arr;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Config;
class SendEmail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'send:emails';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'For Sending Email To Users';

    /**
     * Execute the console command.
     */
    public function handle()
    {
       $emailData =[
            'subject' => 'Good you try to learning lavavel',
            'body' => 'you learning lavavel email sending.this is the classic example of sending email useing laravel commad',
            'tagline' => 'LEARN ANY COURSE  FOR IN YOUR OWN LANGUAGE UPDATED.'
        ];
        // echo "hgfjsg";exit;
        Mail::to('payalsakariya1721@gmail.com')
        // ->cc('rahi013shah@gmail.com')
        ->send(new WelcomeEmail($emailData));
    }
}
