<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MCRModel extends Model
{
    use HasFactory;
    protected $table = 'mcr';
    protected $primariyKer = 'mcr_key';
    public $incrimenting = 'false';
    protected $KeyType = 'string';
    public const CREATED_AT ='new_created_at';
    public const UPDATEED_AT ='new_updateed_at';
    protected $attributes = [
        'car_type' => 'sedan'
    ];
    protected $fillable = [
        'user_id',
        'car_type',
        'type'
    ];
    

}
