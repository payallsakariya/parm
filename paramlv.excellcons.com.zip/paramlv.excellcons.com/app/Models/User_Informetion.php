<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class User_Informetion extends Model
{
    use HasFactory;
    protected $table = 'patients';
    // protected $table1 = 'practices';

    protected $fillable = ['pfname','pmname','plname','pbirth_date','contact','age','ym','bloodgroup','gender','religion','postal_code','address','medical_history'];

}
