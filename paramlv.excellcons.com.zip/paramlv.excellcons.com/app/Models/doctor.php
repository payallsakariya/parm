<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class doctor extends Model
{
    use HasFactory;
    public function patient()
    {
        return $this->belongsTo(patient::class);
    }
    public function belogsToManypatient(){
        return $this->belongsToMany(patient::class,'doctors_patients_mul');   
    }
    }

    
   

