<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CrudOperations extends Model
{
    use HasFactory;
    protected $table = 'crud_operations';
    
    protected $fillable =[
                'pmshid',
                'contact',
                'pfname',
                'pmname',
                'plname',
                'age',
                'ym',
                'paypending',
                'bloodgroup',
                'pbirth_date',
                'gender',
                'religion',
                'postal_code',
                'address',
                'medical_history',
                'status',
    ];
    // public function setEmailAttribute(){
    //     $this->attribute['email']
    // }
}
