<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class patient extends Model
{
    use HasFactory;
    protected $table = 'user_patients';

    public function doctor()
    {
        // return $this->hasOne(doctor::class);
        return $this->hasMany(doctor::class, 'patient_id', 'id');
    }

    public function belogsToManydoctor(){
        return $this->belongsToMany(doctor::class,'doctors_patients_mul');   
    }

  
}
