<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Counties extends Model
{
    use HasFactory;
    protected $table = 'country';

    public function cities(){
      // "countries.id = states.county_id"
        // "states.id = cities.state_id"
        return $this->hasOneThrough(
            City::class,
            State::class,
            'contry_id', // Foreign key on the states table
            'state_id', // Foreign key on the cities table
            'id', // Local key on the countries table
            'id' // Local key on the states table...
        );
    }

    // Has Many Through
    public function multiplecities(){
        // "countries.id = states.county_id"
          // "states.id = cities.state_id"
          return $this->hasManyThrough(
              City::class,
              State::class,
              'contry_id', // Foreign key on the states table
              'state_id', // Foreign key on the cities table
              'id', // Local key on the countries table
              'id' // Local key on the states table...
          )->take(5);
      }

}
