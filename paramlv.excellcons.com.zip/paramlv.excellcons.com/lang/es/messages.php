<?php

return [
    'welcome' => 'Bienvenido a LearnVern',
    'tagline' => '¡¡APRENDE CUALQUIER CURSO GRATIS EN TU PROPIO IDIOMA!!',
];
