<?php

return [
    'welcome' => 'Bienvenue sur LearnVern',
    'tagline' => 'APPRENEZ N\'IMPORTE QUEL COURS GRATUITEMENT DANS VOTRE PROPRE LANGUE !!',
];
