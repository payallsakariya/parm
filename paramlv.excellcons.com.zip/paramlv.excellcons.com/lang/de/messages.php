<?php

return [
    'welcome' => 'Willkommen bei LearnVern!',
    'tagline' => 'LERNEN SIE JEDEN KURS KOSTENLOS IN IHRER EIGENEN SPRACHE!!',
];