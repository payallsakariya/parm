<?php 
return [
    'welcome' => 'Welcome to LearnVern',
    'tagline' => 'LEARN ANY COURSE FOR FREE IN YOUR OWN LANGUAGE!!',
    'discription'=> 'Hi is a:language developer',
    'courses'=> 'I Learning Laravel|I Learning PHP'

];
// echo __('messages.welcome');